import React, { useState } from "react";
import { CalculatorTool } from "../types";
import { generateGenericCalculator } from "../data/calculatorGenerator";
import { 
  DollarSign, 
  Activity, 
  Percent, 
  Cpu, 
  Search, 
  Sparkles
} from "lucide-react";

interface GhostPreviewsProps {
  onSelectGhost: (tool: CalculatorTool) => void;
  searchTerm?: string;
  theme: "light" | "dark";
}

// Complete Category Structure fully standardized in English (Cleaned of redundancies)
const CALCULATOR_GROUPS = [
  {
    id: "finance",
    label: "💰 Finance & Investment",
    icon: DollarSign,
    color: "text-emerald-500 border-emerald-500/20 bg-emerald-500/5",
    subgroups: [
      {
        title: "Mortgage & Property",
        items: [
          "Home Mortgage Estimator", "Amortization Schedule", "Rent vs. Buy Evaluation", "Home Affordability Calculator"
        ]
      },
      {
        title: "Investment & Wealth Goals",
        items: [
          "Compound Interest Engine", "Wealth Goal Projector", "Certificate of Deposit (CD) Return", "Return on Investment (ROI)"
        ]
      },
      {
        title: "Income & Budgeting",
        items: [
          "Annual Gross Salary", "Take-Home Pay Estimation", "50/30/20 Smart Lifestyle Splitter"
        ]
      },
      {
        title: "Loans & Debt Control",
        items: [
          "Credit Card Debt Payoff Planner", "Car Auto Loan Calculator"
        ]
      }
    ]
  },
  {
    id: "health",
    label: "🏃 Health & Fitness",
    icon: Activity,
    color: "text-rose-500 border-rose-500/20 bg-rose-500/5",
    subgroups: [
      {
        title: "Fitness & Body Indexes",
        items: [
          "Body Mass Index (BMI)", "Daily Calorie Requirement", "Basal Metabolic Rate (BMR)", "US Navy Body Fat Estimator"
        ]
      },
      {
        title: "Nutrition & Diet",
        items: [
          "Macronutrient Splitter", "Protein Intake Estimator"
        ]
      }
    ]
  },
  {
    id: "math",
    label: "🔢 Mathematics",
    icon: Percent,
    color: "text-blue-500 border-blue-500/20 bg-blue-500/5",
    subgroups: [
      {
        title: "General Calculations",
        items: [
          "General Percentage Wizard", "Ratio Proportion Tool"
        ]
      },
      {
        title: "Geometry Formulas",
        items: [
          "Sphere Volume Calculator", "Circle Area & Perimeter"
        ]
      }
    ]
  },
  {
    id: "others",
    label: "🔧 Daily Utilities",
    icon: Cpu,
    color: "text-violet-500 border-violet-500/20 bg-violet-500/5",
    subgroups: [
      {
        title: "Dates & Life Milestones",
        items: [
          "Date Duration Calculator", "Age and Days Counter"
        ]
      },
      {
        title: "Measurement & Fuel",
        items: [
          "Weight & Metric Conversion", "Ohm's Law Solver", "Appreciation Tip Calculator"
        ]
      }
    ]
  }
];

export default function GhostPreviews({ onSelectGhost, searchTerm = "", theme }: GhostPreviewsProps) {
  const [filterText, setFilterText] = useState<string>("");

  const activeSearch = searchTerm || filterText;
  const isDark = theme === "dark";

  // Handles building and passing the clicked dynamic tool representation
  const handleItemClick = (itemName: string) => {
    const formattedTool = generateGenericCalculator(itemName);
    onSelectGhost(formattedTool);
  };

  return (
    <div className="w-full flex flex-col gap-6" id="calculator-catalog-root">
      
      {/* Tab navigation is removed. All categories are displayed directly vertically */}

      {/* Render catalog matching search filters, or based on active tab */}
      <div className="w-full flex flex-col gap-8" id="catalog-lists-container">
        {CALCULATOR_GROUPS.map((group) => {
          // Always show all groups/categories, filtering only happens on activeSearch
          const isGroupVisible = true;
          if (!isGroupVisible) return null;

          // Filter groups and subgroups
          const matchedSubgroups = group.subgroups.map((sub) => {
            const matchedItems = sub.items.filter((item) =>
              item.toLowerCase().includes(activeSearch.toLowerCase())
            );
            return { ...sub, items: matchedItems };
          }).filter((sub) => sub.items.length > 0);

          if (matchedSubgroups.length === 0) return null;

          return (
            <div key={group.id} className="mb-8 font-sans animate-fade-in" id={`catalog-group-${group.id}`}>
              {/* Group Title */}
              <div className="flex items-center gap-2 mb-4 justify-center md:justify-start" id="catalog-group-title">
                <span className={`px-3.5 py-1.5 rounded-full text-xs font-bold border flex items-center gap-2 ${
                  isDark 
                    ? "bg-[#25252A]/40 border-[#2C2C35] " + group.color
                    : "bg-white border-slate-200 shadow-xs " + group.color
                }`}>
                  <group.icon className="w-4 h-4" />
                  {group.label}
                </span>
                <span className={`h-[1px] flex-grow hidden md:block ${isDark ? "bg-[#2C2C35]" : "bg-slate-200"}`}></span>
              </div>

              {/* Grid of Sub-groups */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="catalog-subgroups-grid">
                {matchedSubgroups.map((sub, sIdx) => (
                  <div 
                    key={sIdx} 
                    className={`p-5 rounded-3xl border transition-all ${
                      isDark 
                        ? "bg-[#1E1E22]/50 border-[#2C2C35] hover:border-[#2E2E36]" 
                        : "bg-white border-slate-200 hover:border-slate-350 shadow-xs hover:shadow-xs"
                    }`}
                  >
                    <h4 className={`text-[11px] font-mono font-bold uppercase tracking-widest mb-3.5 border-b pb-2 ${
                      isDark ? "text-gray-400 border-[#2E2E36]" : "text-slate-500 border-slate-200"
                    }`}>
                      {sub.title}
                    </h4>
                    
                    <div className="flex flex-wrap gap-1.5">
                      {sub.items.map((item, itemIdx) => (
                        <button
                          key={itemIdx}
                          onClick={() => handleItemClick(item)}
                          className={`text-xs font-medium px-3 py-2 rounded-xl transition-all border ${
                            isDark 
                              ? "bg-[#25252A] border-[#2E2E36] text-gray-300 hover:border-[#00FF87]/60 hover:text-[#00FF87]" 
                              : "bg-slate-50 border-slate-200 text-slate-700 hover:border-[#10B981] hover:text-[#10B981] hover:bg-white"
                          }`}
                        >
                          {item}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* No results placeholder */}
        {activeSearch && CALCULATOR_GROUPS.every((g) => 
          g.subgroups.every((s) => s.items.filter((item) => item.toLowerCase().includes(activeSearch.toLowerCase())).length === 0)
        ) && (
          <div className={`text-center py-10 px-4 rounded-3xl border border-dashed ${
            isDark ? "bg-[#1E1E22]/30 border-[#2C2C35]" : "bg-slate-50 border-slate-250 text-slate-800"
          }`} id="catalog-empty-search">
            <Sparkles className={`w-8 h-8 mx-auto mb-3 animate-bounce ${isDark ? "text-[#00FF87]" : "text-[#10B981]"}`} />
            <h4 className="text-sm font-bold mb-1">Discover Custom Calculator</h4>
            <p className={`text-xs max-w-sm mx-auto ${isDark ? "text-gray-400" : "text-slate-500"}`}>
              We don't have a preinstalled "{activeSearch}" tool, but our powerful <strong className="underline">Generative AI Engine</strong> can construct it for you in seconds. Simply hit enter on the search bar above to generate it!
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
