import { CalculatorTool, ProjectionData } from "./types";

/**
 * Safely evaluates a math formula utilizing a scoped sandboxed execution.
 */
export function calculateFormula(
  formulaString: string,
  inputsState: Record<string, any>
): number {
  try {
    const keys = Object.keys(inputsState);
    const values = keys.map((k) => {
      const v = inputsState[k];
      return typeof v === "string" ? (isNaN(Number(v)) ? v : Number(v)) : v;
    });

    // Provide safety mappings and general math functions inside the formula context
    const fn = new Function(
      ...keys,
      `
      const pow = Math.pow;
      const log = Math.log;
      const exp = Math.exp;
      const sqrt = Math.sqrt;
      const round = Math.round;
      const floor = Math.floor;
      const ceil = Math.ceil;
      const min = Math.min;
      const max = Math.max;
      return (${formulaString});
      `
    );
    const result = fn(...values);
    return typeof result === "number" && !isNaN(result) && isFinite(result)
      ? result
      : 0;
  } catch (error) {
    console.warn("Formula evaluation failed:", error, formulaString);
    return 0;
  }
}

/**
 * Searches inputsState for a key with semantic keywords or returns fallback.
 */
function findValue(
  state: Record<string, any>,
  keywords: string[],
  fallback: number
): number {
  for (const k of Object.keys(state)) {
    const lowerKey = k.toLowerCase();
    if (keywords.some((kw) => lowerKey.includes(kw))) {
      const val = Number(state[k]);
      if (!isNaN(val)) return val;
    }
  }
  return fallback;
}

/**
 * Generates structural projections for drawing iOS-style charts dynamically.
 */
export function generateProjections(
  tool: CalculatorTool,
  inputsState: Record<string, any>
): ProjectionData[] {
  const type = tool.tool_type;

  if (type === "compound_interest" || type === "investment") {
    const principal = findValue(inputsState, ["principal", "init", "start", "balance", "amount"], 5000);
    const rate = findValue(inputsState, ["rate", "apr", "interest", "return", "yield"], 8);
    const years = Math.min(Math.max(findValue(inputsState, ["years", "time", "period", "term", "duration"], 10), 1), 50);
    const monthly = findValue(inputsState, ["monthly", "contrib", "dep", "save", "addition"], 200);

    const data: ProjectionData[] = [];
    let currentBalance = principal;
    let totalInvested = principal;
    const r = rate / 100 / 12;

    // Year-by-year coordinates
    data.push({
      label: "Start",
      value: Math.round(principal),
      secondaryValue: Math.round(principal),
      secondaryLabel: "Contributions",
    });

    for (let yr = 1; yr <= years; yr++) {
      // Simulate 12 months for this year
      for (let m = 0; m < 12; m++) {
        currentBalance = (currentBalance + monthly) * (1 + r);
        totalInvested += monthly;
      }
      data.push({
        label: `Yr ${yr}`,
        value: Math.round(currentBalance),
        secondaryValue: Math.round(totalInvested),
        secondaryLabel: "Contributions",
      });
    }
    return data;
  }

  if (type === "debt_payoff") {
    const balance = findValue(inputsState, ["balance", "debt", "principal", "amount"], 10000);
    const apr = findValue(inputsState, ["apr", "rate", "interest"], 22);
    const payment = findValue(inputsState, ["payment", "pay", "monthly"], 350);

    const data: ProjectionData[] = [];
    const monthlyRate = apr / 100 / 12;
    let currBalance = balance;
    let month = 0;
    let cumulativeInterest = 0;

    data.push({
      label: "Start",
      value: Math.round(balance),
      secondaryValue: 0,
      secondaryLabel: "Interest Paid",
    });

    // Safely simulate up to 120 months max
    while (currBalance > 0 && month < 120) {
      const interest = currBalance * monthlyRate;
      cumulativeInterest += interest;
      
      const pPay = payment - interest;
      if (pPay <= 0 && interest > 0) {
        // Payment doesn't cover interest, loop would be infinite
        // Increase step or stop
        month = 120; // force end
        break;
      }

      currBalance -= pPay;
      if (currBalance < 0) currBalance = 0;
      month++;

      // Record coordinates quarterly or ending
      if (month % 3 === 0 || currBalance === 0) {
        data.push({
          label: `Mo ${month}`,
          value: Math.round(currBalance),
          secondaryValue: Math.round(cumulativeInterest),
          secondaryLabel: "Interest Paid",
        });
      }
    }
    
    // If interest is extremely high and payments too small, provide custom warning curve
    if (month >= 120 && currBalance > 0) {
      // Add standard illustrative elements
      data.push({
        label: "Warning",
        value: Math.round(currBalance),
        secondaryValue: Math.round(cumulativeInterest),
        secondaryLabel: "Interest Paid",
      });
    }

    return data;
  }

  if (type === "mortgage") {
    const price = findValue(inputsState, ["price", "home", "property", "value"], 350000);
    let downPercent = findValue(inputsState, ["down", "percent", "down_payment"], 20);
    // If down payment is large, treat it as currency, otherwise percent
    if (downPercent > 100) {
      downPercent = (downPercent / price) * 100;
    }
    const rate = findValue(inputsState, ["rate", "apr", "interest"], 6.5);
    const years = Math.min(Math.max(findValue(inputsState, ["years", "term", "period"], 30), 5), 40);

    const loanAmount = price * (1 - downPercent / 100);
    const monthlyRate = rate / 100 / 12;
    const totalMonths = years * 12;
    
    // Calculate Monthly Amortization
    // P = L * [c * (1 + c)^n] / [(1 + c)^n - 1]
    const monthlyPayment =
      monthlyRate === 0
        ? loanAmount / totalMonths
        : (loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, totalMonths))) /
          (Math.pow(1 + monthlyRate, totalMonths) - 1);

    const data: ProjectionData[] = [];
    let currBalance = loanAmount;
    let cumulativeInterest = 0;

    data.push({
      label: "Start",
      value: Math.round(loanAmount),
      secondaryValue: 0,
      secondaryLabel: "Interest Paid",
    });

    const yearlyStep = Math.max(Math.floor(years / 5), 1);

    for (let yr = 1; yr <= years; yr++) {
      for (let m = 0; m < 12; m++) {
        const interest = currBalance * monthlyRate;
        cumulativeInterest += interest;
        const main = monthlyPayment - interest;
        currBalance -= main;
        if (currBalance < 0) currBalance = 0;
      }
      
      if (yr % yearlyStep === 0 || yr === years) {
        data.push({
          label: `Yr ${yr}`,
          value: Math.round(currBalance),
          secondaryValue: Math.round(cumulativeInterest),
          secondaryLabel: "Interest Paid",
        });
      }
    }
    return data;
  }

  if (type === "budget" || tool.chart_type === "distribution") {
    // Generates a distribution comparisons bar chart
    const income = findValue(inputsState, ["income", "salary", "take_home", "earnings"], 4000);
    
    // 50/30/20 standard budget or custom allocation ratio
    const needsPct = findValue(inputsState, ["needs", "fixed", "essential"], 50);
    const wantsPct = findValue(inputsState, ["wants", "fun", "discretionary"], 30);
    const savingsPct = findValue(inputsState, ["savings", "investing", "future"], 20);

    const totalPct = needsPct + wantsPct + savingsPct;
    const normalizer = totalPct > 0 ? totalPct : 100;

    return [
      {
        label: "Fixed Needs",
        value: Math.round((income * needsPct) / normalizer),
        secondaryValue: 50,
        secondaryLabel: "Rule %",
      },
      {
        label: "Flexible Wants",
        value: Math.round((income * wantsPct) / normalizer),
        secondaryValue: 30,
        secondaryLabel: "Rule %",
      },
      {
        label: "Growth Savings",
        value: Math.round((income * savingsPct) / normalizer),
        secondaryValue: 20,
        secondaryLabel: "Rule %",
      },
    ];
  }

  if (tool.chart_type === "gauge") {
    const computedVal = calculateFormula(tool.formula, inputsState);
    return [
      {
        label: tool.output_label || "Score Index",
        value: computedVal,
      }
    ];
  }

  if (tool.chart_type === "comparison") {
    const rentVal = findValue(inputsState, ["rent"], 1500);
    const pVal = findValue(inputsState, ["price", "msrp", "value"], 300000);
    const yrs = findValue(inputsState, ["years", "months", "term"], 10);
    
    // Check if Rent vs Buy or Rebate vs Low Interest
    if (tool.formula.includes("rebate")) {
      const rebate = findValue(inputsState, ["rebate"], 2000);
      const promoRate = findValue(inputsState, ["promo_rate"], 1.9);
      const withRebateRate = findValue(inputsState, ["with_rebate", "rate_with_rebate"], 6.0);
      
      const scenario1Cost = (pVal - rebate) * (withRebateRate / 100) * 5 + (pVal - rebate);
      const scenario2Cost = pVal * (promoRate / 100) * 5 + pVal;
      return [
        { label: "With Cash Back Rebate Option", value: Math.round(scenario1Cost) },
        { label: "With Low Promotional APR Option", value: Math.round(scenario2Cost) }
      ];
    } else {
      // Rent vs Buy comparison estimate
      const months = yrs > 35 ? yrs : yrs * 12;
      const totalRentPaid = rentVal * months;
      // Buy cost estimate with 20% down payment simulated
      const totalBuyPaid = pVal * 0.20 + (pVal * 0.05 * (months / 12)); 
      return [
        { label: "Scenario A: Buying Cumulative Expense", value: Math.round(totalBuyPaid) },
        { label: "Scenario B: Renting Cumulative Expense", value: Math.round(totalRentPaid) }
      ];
    }
  }

  if (type === "salary") {
    const rawSalary = findValue(inputsState, ["salary", "wage", "income", "earnings"], 75000);
    
    // Standard tax breakdown approximation
    const federalTax = Math.round(rawSalary * 0.12);
    const stateTax = Math.round(rawSalary * 0.05);
    const ficaTax = Math.round(rawSalary * 0.0765);
    const netPay = Math.round(rawSalary - (federalTax + stateTax + ficaTax));

    return [
      { label: "Net Take-Home", value: netPay },
      { label: "Federal Tax (Est)", value: federalTax },
      { label: "State Tax (Est)", value: stateTax },
      { label: "FICA / Social Security", value: ficaTax },
    ];
  }

  if (type === "macronutrient") {
    const calories = findValue(inputsState, ["calories", "kcal", "energy"], 2000);
    const proteinRatio = findValue(inputsState, ["protein_ratio", "protein"], 30);
    const fatsRatio = findValue(inputsState, ["fats_ratio", "fats"], 30);
    // Leftover is Carb ratio
    const carbsRatio = Math.max(100 - (proteinRatio + fatsRatio), 0);

    const proteinGrams = (calories * (proteinRatio / 100)) / 4;
    const carbsGrams = (calories * (carbsRatio / 100)) / 4;
    const fatsGrams = (calories * (fatsRatio / 100)) / 9;

    return [
      {
        label: "Protein grams",
        value: Math.round(proteinGrams),
        secondaryValue: proteinRatio,
        secondaryLabel: "Protein %",
      },
      {
        label: "Carbohydrates grams",
        value: Math.round(carbsGrams),
        secondaryValue: carbsRatio,
        secondaryLabel: "Carbs %",
      },
      {
        label: "Healthy Fats grams",
        value: Math.round(fatsGrams),
        secondaryValue: fatsRatio,
        secondaryLabel: "Fats %",
      },
    ];
  }

  if (type === "freelancer_allocator") {
    const rev = findValue(inputsState, ["monthly_rev", "revenue", "monthly_revenue"], 8000);
    const taxRate = findValue(inputsState, ["tax_ratio", "tax"], 25);
    const expRate = findValue(inputsState, ["exp_ratio", "expenses"], 15);
    const invRate = findValue(inputsState, ["inv_ratio", "investments"], 20);

    const taxAmount = Math.round(rev * (taxRate / 100));
    const expAmount = Math.round(rev * (expRate / 100));
    const invAmount = Math.round(rev * (invRate / 100));
    const personalAmount = Math.max(rev - (taxAmount + expAmount + invAmount), 0);

    return [
      { label: "Net Owner Salary Draw", value: personalAmount, secondaryValue: Math.max(100 - taxRate - expRate - invRate, 0), secondaryLabel: "Share %" },
      { label: "Tax Buffer Reserves", value: taxAmount, secondaryValue: taxRate, secondaryLabel: "Tax %" },
      { label: "Business Overheads & SaaS", value: expAmount, secondaryValue: expRate, secondaryLabel: "Expenses %" },
      { label: "Compound Wealth Investments", value: invAmount, secondaryValue: invRate, secondaryLabel: "Invest %" }
    ];
  }

  if (type === "freelancer_wealth_multiplying_tracker") {
    const initVal = findValue(inputsState, ["init_reserve", "principal"], 1000);
    const monthlyDep = findValue(inputsState, ["monthly_dep", "monthly"], 500);
    const returnRate = findValue(inputsState, ["annual_return", "rate"], 20) / 100;
    const years = findValue(inputsState, ["growth_years", "years"], 10);

    const projectionsList: ProjectionData[] = [];
    
    // Create compounding points
    for (let i = 0; i <= 5; i++) {
      const currentYear = Math.max(Math.round((years / 5) * i), 1);
      
      const fvPrincipal = initVal * Math.pow(1 + returnRate, currentYear);
      const fvAnnuity = returnRate === 0 
        ? (monthlyDep * 12 * currentYear)
        : (monthlyDep * 12 * (Math.pow(1 + returnRate, currentYear) - 1)) / returnRate;
      
      const totalAccumulated = Math.round(fvPrincipal + fvAnnuity);
      const totalDeposited = Math.round(initVal + (monthlyDep * 12 * currentYear));

      projectionsList.push({
        label: `Year ${currentYear}`,
        value: totalAccumulated,
        secondaryValue: totalDeposited,
        secondaryLabel: "Deposited Principal"
      });
    }
    return projectionsList;
  }

  if (type === "age" || tool.chart_type === "countdown") {
    const day = findValue(inputsState, ["birth_day", "day"], 15);
    const month = findValue(inputsState, ["birth_month", "month"], 6);
    const year = findValue(inputsState, ["birth_year", "year"], 2000);

    const now = new Date();
    // Default fallback to 2026/06/02 if Date parses empty relative to system testing
    const birthDate = new Date(year, month - 1, day);
    
    // Total days lived
    const diffTime = Math.abs(now.getTime() - birthDate.getTime());
    const totalDaysLived = Math.floor(diffTime / (1000 * 60 * 60 * 24)) || 1;
    
    // Days until next birthday
    let nextBday = new Date(now.getFullYear(), month - 1, day);
    if (nextBday.getTime() < now.getTime()) {
      nextBday.setFullYear(now.getFullYear() + 1);
    }
    const daysToBday = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    
    // Percentage milestone through current year (from last birthday to next birthday)
    const lastBday = new Date(nextBday.getFullYear() - 1, month - 1, day);
    const totalYearMs = nextBday.getTime() - lastBday.getTime();
    const elapsedSinceLast = now.getTime() - lastBday.getTime();
    const pctYear = Math.min(Math.max(Math.round((elapsedSinceLast / totalYearMs) * 100), 0), 100);

    // Current exact age
    let currentAge = now.getFullYear() - year;
    const hasHadBdayThisYear = now.getMonth() > (month - 1) || (now.getMonth() === (month - 1) && now.getDate() >= day);
    if (!hasHadBdayThisYear) {
      currentAge -= 1;
    }

    // Days to key decade milestone (30, 40, etc)
    const nextDecade = Math.ceil((currentAge + 1) / 10) * 10;
    const decadeDate = new Date(year + nextDecade, month - 1, day);
    const daysToDecade = Math.ceil((decadeDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    return [
      {
        label: "Days Lived",
        value: totalDaysLived,
        secondaryValue: pctYear,
        secondaryLabel: "Year Progress %"
      },
      {
        label: "Days to Next Birthday",
        value: daysToBday,
        secondaryValue: currentAge,
        secondaryLabel: "Years Old Lived"
      },
      {
        label: "Days to Next Decade",
        value: daysToDecade,
        secondaryValue: nextDecade,
        secondaryLabel: "Target Decade"
      },
      {
        label: "Est. Lived Hours Sleept",
        value: Math.round(totalDaysLived * 8), // assuming 8 hours sleep per day
        secondaryValue: Math.round(totalDaysLived * 3), // eaten meals
        secondaryLabel: "Meals Consumed"
      }
    ];
  }

  if (type === "date_difference" || tool.tool_type === "date_difference") {
    const day = findValue(inputsState, ["start_day", "day"], 15);
    const month = findValue(inputsState, ["start_month", "month"], 12);
    const year = findValue(inputsState, ["start_year", "year"], 2026);

    const now = new Date(); // Current date e.g. June 2, 2026
    const targetDate = new Date(year, month - 1, day);

    // Calculate straight millisecond difference
    const diffTime = targetDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const absDays = Math.abs(diffDays);

    const labelDirection = diffDays >= 0 ? "Days Remaining" : "Days Elapsed";
    const statusLabel = diffDays >= 0 ? "Future Countdown" : "Past Duration";

    return [
      {
        label: labelDirection,
        value: absDays,
        secondaryValue: absDays * 24,
        secondaryLabel: "Total Hours"
      },
      {
        label: "Weeks Distance",
        value: Math.round(absDays / 7),
        secondaryValue: absDays * 1440,
        secondaryLabel: "Total Minutes"
      },
      {
        label: "Months Distance",
        value: Math.round(absDays / 30.4),
        secondaryValue: Math.round((absDays / 365) * 100),
        secondaryLabel: "Year Percentage"
      }
    ];
  }

  if (type === "boy_kilo" || tool.tool_type === "boy_kilo") {
    const weightKg = findValue(inputsState, ["weight_kg", "weight", "kilo"], 70);
    const heightCm = findValue(inputsState, ["height_cm", "height", "boy"], 175);

    const weightLbs = Math.round(weightKg * 2.20462 * 10) / 10;
    const heightInches = Math.round(heightCm * 0.393701 * 10) / 10;
    const bmi = heightCm === 0 ? 0 : Math.round((weightKg / Math.pow(heightCm / 100, 2)) * 10) / 10;

    return [
      {
        label: "Weight (Kg vs Lbs)",
        value: weightKg,
        secondaryValue: weightLbs,
        secondaryLabel: "Pounds (lbs)",
      },
      {
        label: "Height (Cm vs Inches)",
        value: heightCm,
        secondaryValue: heightInches,
        secondaryLabel: "Inches (in)",
      },
      {
        label: "Body Mass Index (BMI)",
        value: bmi,
        secondaryValue: 21.7,
        secondaryLabel: "Ideal Median Ref",
      }
    ];
  }

  // Fallback Custom calculator coordinates - creates an illustrative 5-step growth / reduction curve
  const amount = findValue(inputsState, ["principal", "amount", "budget", "salary", "balance", "cost", "target", "input_a"], 1000);
  const factor = findValue(inputsState, ["rate", "apr", "interest", "multiplier", "factor", "input_b"], 10);
  
  const data: ProjectionData[] = [];
  for (let i = 0; i <= 4; i++) {
    const multiplier = 1 + (factor / 100) * i;
    data.push({
      label: `Point ${i + 1}`,
      value: Math.round(amount * multiplier),
    });
  }
  return data;
}

/**
 * Format currency numbers correctly (e.g. $10,420.50 or $5,420)
 */
export function formatValue(val: number, prefix = "", suffix = ""): string {
  if (isNaN(val) || !isFinite(val)) return prefix + "0" + suffix;
  
  // Format based on standard scale
  let formatted = "";
  if (Math.abs(val) >= 1_000_000) {
    formatted = (val / 1_000_000).toFixed(2).replace(/\.00$/, "") + "M";
  } else if (Math.abs(val) >= 1_000) {
    formatted = val.toLocaleString(undefined, { maximumFractionDigits: 0 });
  } else {
    formatted = val.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }

  // Double symbol check - if prefix is $ and some string already has $, avoid duplicates
  const actualPrefix = prefix.trim();
  const actualSuffix = suffix.trim();

  return `${actualPrefix}${formatted}${actualSuffix}`;
}
