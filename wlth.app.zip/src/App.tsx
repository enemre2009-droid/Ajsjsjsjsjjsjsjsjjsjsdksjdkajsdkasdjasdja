import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, 
  HelpCircle, 
  Sparkles, 
  RotateCcw, 
  TrendingUp, 
  ArrowRight,
  Sun,
  Moon,
  Info,
  Command,
  ArrowUpRight,
  BarChart2,
  Check
} from "lucide-react";
import { CalculatorTool } from "./types";
import { calculateFormula, generateProjections, formatValue } from "./utils";
import CustomChart from "./components/CustomChart";
import GhostPreviews from "./components/GhostPreviews";
import { findMatchingPredefinedCalculator, PREDEFINED_CALCULATORS } from "./data/predefinedCalcs";

// Selection suggest chips for quick onboarding in English
const SUGGESTIONS = [
  "What if I save $400/mo for 15 years with 10% returns?",
  "I have $8,000 credit card debt at 22% APR, paying $350/mo?",
  "Is it better to take cash back or promotional low APR?",
  "Calculate my Body Mass Index (BMI)",
  "Estimate my home mortgage payment"
];

export default function App() {
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTool, setActiveTool] = useState<CalculatorTool | null>(null);

  const setSanitizedActiveTool = (tool: CalculatorTool | null) => {
    if (tool) {
      const q = (tool.title || "").toLowerCase() + " " + (tool.description || "").toLowerCase() + " " + (tool.tool_type || "").toLowerCase();
      if (
        q.includes("50/30/20") ||
        q.includes("20/30/50") ||
        q.includes("50-30-20") ||
        q.includes("20-30-50") ||
        q.includes("splitter") ||
        q.includes("budget") ||
        q.includes("bütçe") ||
        q.includes("lifestyle") ||
        q.includes("daire") ||
        q.includes("pasta") ||
        q.includes("çember")
      ) {
        const modifiedTool: CalculatorTool = {
          tool_type: "budget",
          title: "50/30/20 Smart Lifestyle Splitter",
          description: "Secure savings automatically while balancing your wants and needs",
          inputs: [
            {
              id: "income",
              label: "Monthly Net Take-Home Pay (Bakiye / Gelir)",
              type: "slider",
              default: 5000,
              prefix: "$",
              min: 0,
              max: 30000,
              step: 100
            }
          ],
          formula: "income * 0.20",
          output_label: "Target Monthly Automated Future Savings Portion (20%)",
          output_prefix: "$",
          chart_type: "bar",
          insight: "Automate financial transfers to split allocations straight from payday so you never struggle with willpower."
        };
        setActiveTool(modifiedTool);
        return;
      }
    }
    setActiveTool(tool);
  };

  const [inputsState, setInputsState] = useState<Record<string, any>>({});
  const [hasInteracted, setHasInteracted] = useState(false);
  const [isWaveActive, setIsWaveActive] = useState(false);

  // Day/Night Light mode state
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("wlth-theme");
      if (saved === "dark" || saved === "light") return saved;
      
      // Check device theme preference
      if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
        return "dark";
      }
      return "light";
    }
    return "dark";
  });

  useEffect(() => {
    document.documentElement.className = theme;
    localStorage.setItem("wlth-theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    if (isWaveActive) return;
    setIsWaveActive(true);
    
    // Switch the theme halfway through the soft fade-in transition
    setTimeout(() => {
      setTheme((prev) => (prev === "dark" ? "light" : "dark"));
    }, 180);

    // Conclude transition and clear backdrop overlay
    setTimeout(() => {
      setIsWaveActive(false);
    }, 400);
  };

  // Sync inputs details into state whenever an active tool is loaded
  useEffect(() => {
    if (activeTool) {
      const initialState: Record<string, any> = {};
      activeTool.inputs.forEach((input) => {
        initialState[input.id] = input.default;
      });
      setInputsState(initialState);
    }
  }, [activeTool]);

  // Submit search query directly or using Gemini 2.5 Flash
  const handleSubmitPrompt = async (searchPrompt: string) => {
    if (!searchPrompt.trim()) return;
    setIsLoading(true);
    setError(null);
    setHasInteracted(true);

    // 1. Direct Predefined Match Lookups (Instant routing to avoid unnecessary LLM calls)
    const localMatch = findMatchingPredefinedCalculator(searchPrompt);
    if (localMatch) {
      setTimeout(() => {
        setSanitizedActiveTool(localMatch);
        setIsLoading(false);
      }, 300); // Small fluid transition effect
      return;
    }

    // 2. Fall back to AI Model for unique custom generation
    try {
      const response = await fetch("/api/parse-query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchPrompt }),
      });

      if (!response.ok) {
        throw new Error("Server responded with error status");
      }

      const toolData = await response.json();
      if (toolData && toolData.title && toolData.formula) {
        setSanitizedActiveTool(toolData);
      } else {
        throw new Error("Invalid tool definition returned");
      }
    } catch (err: any) {
      console.error("Failed to parse tool prompt, adopting smart template client-side fallback:", err);
      // Safe, intelligent user-centric template activation
      const q = searchPrompt.toLowerCase();
      let match = PREDEFINED_CALCULATORS[0]; // Compound interest as standard fallback
      if (q.includes("debt") || q.includes("payoff") || q.includes("borrow") || q.includes("card") || q.includes("cc") || q.includes("borç") || q.includes("kredi")) {
        match = PREDEFINED_CALCULATORS[1]; // Debt payoff
      } else if (q.includes("mortgage") || q.includes("home") || q.includes("house") || q.includes("ev") || q.includes("mülk")) {
        match = PREDEFINED_CALCULATORS[2]; // Mortgage
      } else if (q.includes("budget") || q.includes("bütçe") || q.includes("rule") || q.includes("split")) {
        match = PREDEFINED_CALCULATORS[3]; // Budget splitter
      } else if (q.includes("salary") || q.includes("maaş") || q.includes("tax") || q.includes("income") || q.includes("take home")) {
        match = PREDEFINED_CALCULATORS[4]; // Salary tax
      } else if (q.includes("macro") || q.includes("protein") || q.includes("nutrition") || q.includes("diyet") || q.includes("kcal") || q.includes("calorie")) {
        match = PREDEFINED_CALCULATORS[5]; // Macronutrient
      }
      setSanitizedActiveTool({
        ...match,
        title: `${searchPrompt.charAt(0).toUpperCase() + searchPrompt.slice(1)} Tracker`,
        description: `Custom configured dynamic tool modeled after "${searchPrompt}"`
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleChipClick = (suggestion: string) => {
    setQuery(suggestion);
    handleSubmitPrompt(suggestion);
  };

  const handleGhostSelect = (tool: CalculatorTool) => {
    setHasInteracted(true);
    setSanitizedActiveTool(tool);
    // Bind search query bar text to selected tool title
    setQuery(tool.title);
  };

  const handleReset = () => {
    setSanitizedActiveTool(null);
    setQuery("");
    setHasInteracted(false);
    setError(null);
  };

  // Live calculations
  const calculatedOutput = activeTool 
    ? calculateFormula(activeTool.formula, inputsState) 
    : 0;

  const projectionsData = activeTool 
    ? generateProjections(activeTool, inputsState) 
    : [];

  // Dynamic Date Input grouping & helpers
  const datePrefixes = ["start", "end", "birth"];
  const activePrefixes = activeTool ? datePrefixes.filter(prefix => 
    activeTool.inputs.some(i => i.id === `${prefix}_day`) &&
    activeTool.inputs.some(i => i.id === `${prefix}_month`) &&
    activeTool.inputs.some(i => i.id === `${prefix}_year`)
  ) : [];

  const isGroupedInput = (inputId: string) => {
    if (!activeTool) return false;
    return activePrefixes.some(prefix => 
      inputId === `${prefix}_day` || 
      inputId === `${prefix}_month` || 
      inputId === `${prefix}_year`
    );
  };

  const monthsList = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const getExactTimeDifferenceText = (day: number, month: number, year: number): string => {
    if (!day || !month || !year) return "No date selected";
    
    const now = new Date(); // e.g. 2026-06-02
    const targetDate = new Date(year, month - 1, day);

    let isPast = true;
    let d1 = targetDate;
    let d2 = now;
    if (targetDate.getTime() > now.getTime()) {
      isPast = false;
      d1 = now;
      d2 = targetDate;
    }

    let years = d2.getFullYear() - d1.getFullYear();
    let months = d2.getMonth() - d1.getMonth();
    let days = d2.getDate() - d1.getDate();

    if (days < 0) {
      months--;
      const prevMonth = new Date(d2.getFullYear(), d2.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    const parts: string[] = [];
    if (years > 0) parts.push(`${years} ${years === 1 ? "year" : "years"}`);
    if (months > 0) parts.push(`${months} ${months === 1 ? "month" : "months"}`);
    if (days > 0 || parts.length === 0) parts.push(`${days} ${days === 1 ? "day" : "days"}`);

    return parts.join(", ") + (isPast ? " elapsed" : " remaining");
  };

  // Theme-sensitive constant classes
  const isDark = theme === "dark";
  const rootBg = isDark ? "bg-[#121214] text-[#F3F4F6]" : "bg-[#F8FAFC] text-[#1E293B]";
  const headerBg = isDark ? "bg-[#18181C]/90 border-[#27272C]" : "bg-white/95 border-slate-200/80";
  const textTitle = isDark ? "text-white font-semibold" : "text-slate-900 font-medium";
  const textMuted = isDark ? "text-gray-400" : "text-slate-500";
  const cardBg = isDark ? "bg-[#1E1E22] border-[#2C2C35] shadow-[0_4px_30px_rgba(0,0,0,0.45)]" : "bg-white border-slate-200 shadow-sm";
  const boxBg = isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/80";
  const selectBg = isDark ? "bg-[#1E1E22] border-[#2E2E36] text-gray-200" : "bg-white border-slate-300 text-slate-800";
  const accentColor = isDark ? "#00FF87" : "#10B981"; // Electric green vs deep emerald
  const accentBorder = isDark ? "border-[#00FF87]/30" : "border-[#10B981]/30";
  
  return (
    <div className={`min-h-screen ${rootBg} font-sans selection:bg-emerald-500/20 selection:text-emerald-400 flex flex-col justify-between transition-colors duration-300`} id="wlth-app-root">
      
      {/* 1. Header Navigation Bar */}
      <header className={`border-b ${headerBg} backdrop-blur-md sticky top-0 z-50 px-5 py-3 flex justify-between items-center transition-colors duration-200`} id="nav-header">
        <div className="flex items-center gap-2 cursor-pointer" onClick={handleReset} id="logo-container">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-400 to-[#10B981] flex items-center justify-center shadow-md">
            <span className="text-xs font-black text-white">$</span>
          </div>
          <span className={`text-xl font-bold tracking-tight ${textTitle} font-sans flex items-center`}>
            wlth<span className="text-emerald-500 font-extrabold">.</span>app
          </span>
        </div>
        
        <div className="flex items-center gap-2 sm:gap-3.5">
          {/* Theme Switcher Button */}
          <button
            onClick={toggleTheme}
            className={`p-1.5 sm:p-2 rounded-xl border ${
              isDark 
                ? "bg-[#25252A] border-[#2C2C35] text-[#00FF87] hover:bg-[#2B2B32]" 
                : "bg-white border-slate-200 text-[#10B981] hover:bg-slate-50 shadow-xs"
            } transition-all`}
            aria-label="Toggle Theme Mode"
            id="theme-toggler-btn"
          >
            {isDark ? (
              <Sun className="w-3.5 h-3.5" />
            ) : (
              <Moon className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </header>

      {/* 2. Main Content Canvas */}
      <main className="flex-grow flex flex-col px-4 md:px-8 py-8 items-center max-w-5xl mx-auto w-full relative z-10" id="main-canvas">
        
        {/* Hero Title Section */}
        <motion.div 
          layout
          className="w-full text-center max-w-2xl mx-auto"
          animate={{ 
            marginBottom: hasInteracted ? "1.5rem" : "2.5rem",
            transformOrigin: "center top"
          }}
          transition={{ duration: 0.4, ease: "easeInOut" }}
          id="hero-header-box"
        >
          <motion.h1 
            layout 
            className={`text-3xl md:text-5xl font-extrabold tracking-tight ${textTitle} mt-1 mb-2`}
            style={{ fontSize: hasInteracted ? "1.75rem" : undefined }}
            transition={{ duration: 0.3 }}
          >
            Ask Anything<span className="text-emerald-550 font-bold">.</span> Compute Instantly<span className="text-emerald-550 font-bold">.</span>
          </motion.h1>
          
          <motion.p 
            layout 
            className={`text-sm ${textMuted} max-w-md mx-auto leading-relaxed`}
            style={{ display: hasInteracted ? "none" : "block" }}
          >
            Select from our 100+ precision calculation tools below, or type any custom query in the box above to generate your dynamic hub.
          </motion.p>
        </motion.div>

        {/* 3. Central AI Prompter Bar */}
        <div className="w-full max-w-2xl mx-auto mb-6 relative z-30" id="search-inputs-area">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSubmitPrompt(query);
            }}
            className="relative"
          >
            <div className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400">
              <Search className="w-5 h-5" />
            </div>
            
            <input
              type="text"
              id="main-calculator-prompt-input"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Type your question or query here (e.g. mortgage pay down)..."
              disabled={isLoading}
              className={`w-full pl-12 pr-16 py-4 rounded-full border focus:outline-none transition-all font-sans text-sm ${
                isDark 
                  ? "bg-[#1E1E22] text-gray-100 border-[#2C2C35] placeholder:text-gray-600 focus:border-[#00FF87] focus:ring-1 focus:ring-[#00FF87]"
                  : "bg-white text-slate-950 border-slate-250 placeholder:text-sky-950/30 focus:border-[#10B981] focus:ring-1 focus:ring-[#10B981] shadow-xs"
              }`}
            />

            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className={`absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                isDark 
                  ? "bg-[#00FF87] text-black hover:opacity-90 disabled:bg-[#25252A] disabled:text-gray-750 shadow-md"
                  : "bg-[#10B981] text-white hover:opacity-95 disabled:bg-slate-200 disabled:text-slate-400 shadow-sm"
              }`}
              id="prompt-submit-btn"
            >
              {isLoading ? (
                <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
              ) : (
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              )}
            </button>
          </form>

          {/* Quick interactive Suggestion Chips */}
          <AnimatePresence>
            {!hasInteracted && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-4 flex flex-wrap gap-1.5 justify-center"
                id="suggestion-chips-container"
              >
                {SUGGESTIONS.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleChipClick(s)}
                    disabled={isLoading}
                    className={`text-[10.5px] font-sans font-medium tracking-wide border px-3.5 py-1.5 rounded-full transition-all focus:outline-none ${
                      isDark
                        ? "bg-[#0E0E10] hover:bg-[#151518] border-neutral-850 hover:border-[#00FF87]/30 text-gray-400 hover:text-[#00FF87]"
                        : "bg-white hover:bg-slate-50 border-slate-200 text-slate-600 hover:text-[#10B981] shadow-xs"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* 4. Display Loading State / Error Messages */}
        <div className="w-full max-w-2xl mx-auto animate-fade-in">
          {isLoading && !activeTool && (
            <div className="flex flex-col items-center justify-center p-12 text-center" id="global-loading">
              <div className="relative mb-4">
                <div className={`w-12 h-12 rounded-full border-2 border-neutral-300 animate-spin border-t-[${accentColor}]`} />
                <Sparkles className="w-5 h-5 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 animate-pulse text-emerald-500" />
              </div>
              <p className="font-mono text-[10px] text-gray-500 uppercase tracking-widest animate-pulse">
                Generating Interactive Calculator... Please hold on...
              </p>
            </div>
          )}

          {error && (
            <div className="p-4 rounded-2xl bg-red-950/25 border border-red-900/30 text-red-400 text-xs flex gap-3 mb-6" id="error-alert">
              <HelpCircle className="w-5 h-5 flex-shrink-0 text-red-500 animate-pulse" />
              <div>{error}</div>
            </div>
          )}
        </div>

        {/* 5. Tool Card Display */}
        <AnimatePresence>
          {activeTool && (
            <motion.div
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="w-full max-w-6xl mx-auto relative z-20"
              id="active-tool-card-wrapper"
            >
              <div className={`${cardBg} rounded-3xl p-6 md:p-8 relative border transition-all duration-200`} id="active-tool-card">
                
                {/* Accent Top Bar */}
                <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-transparent via-[#10B981] to-transparent rounded-t-3xl" />

                {/* Card Title Box & Reset Actions */}
                <div className="mb-6 text-left">
                  <span className="text-[9px] font-mono font-bold uppercase tracking-widest text-[#050508] bg-[#00FF87] px-2.5 py-0.5 rounded-full inline-block shadow-[0_0_8px_rgba(0,255,135,0.2)]">
                    {activeTool.tool_type.replace("_", " ")}
                  </span>
                  <h2 className={`text-xl md:text-2xl font-black tracking-tight ${textTitle} mt-2`}>
                    {activeTool.title}
                  </h2>
                  <p className={`text-xs ${textMuted} mt-1 leading-relaxed`}>
                    {activeTool.description}
                  </p>
                </div>

                {/* Dual Column Bloomberg-Style Layout on Desktop */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  
                  {/* Left Column: Interactive Parameters & Calculated Value */}
                  <div className="lg:col-span-5 flex flex-col gap-6" id="calc-inputs-column">
                    
                    {/* Tool Tip warning bounds */}
                    <div className="p-3.5 rounded-2xl bg-blue-500/5 dark:bg-emerald-500/[0.02] border border-blue-500/10 text-[11px] font-sans text-slate-600 dark:text-gray-400 flex items-center gap-2.5 leading-relaxed">
                      <Info className="w-4 h-4 text-[#10B981] flex-shrink-0 animate-bounce" />
                      <span>
                        Sliders are set to smart ranges. You can direct-type larger values into input boxes if needed.
                      </span>
                    </div>

                    <div className="flex flex-col gap-4 font-sans" id="tool-inputs-grid">
                      
                      {/* Unified Date Group Selectors (Side-By-Side horizontal dropdown arrays) */}
                      {activePrefixes.map((prefix) => {
                        const dayInput = activeTool.inputs.find(i => i.id === `${prefix}_day`)!;
                        const monthInput = activeTool.inputs.find(i => i.id === `${prefix}_month`)!;
                        const yearInput = activeTool.inputs.find(i => i.id === `${prefix}_year`)!;

                        const currentDay = inputsState[`${prefix}_day`] ?? dayInput.default;
                        const currentMonth = inputsState[`${prefix}_month`] ?? monthInput.default;
                        const currentYear = inputsState[`${prefix}_year`] ?? yearInput.default;

                        const labelTitle = prefix === "start" ? "Target/Start Date" : prefix === "end" ? "End Date" : "Birth Date";

                        const daysArray = Array.from({ length: 31 }, (_, i) => i + 1);
                        const yearsArray = [];
                        const minY = yearInput.min ?? 1920;
                        const maxY = yearInput.max ?? 2050;
                        for (let y = minY; y <= maxY; y++) {
                          yearsArray.push(y);
                        }

                        return (
                          <div 
                            key={prefix} 
                            className={`${boxBg} rounded-2xl p-4 flex flex-col border hover:border-neutral-500 dark:hover:border-neutral-850 transition-colors duration-250`}
                          >
                            <label className="text-[10px] uppercase font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold mb-3">
                              📅 {labelTitle}
                            </label>
                            
                            <div className="grid grid-cols-3 gap-3 flex-row">
                              {/* Day Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">DAY</span>
                                <div className="relative">
                                  <select 
                                    value={currentDay}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_day`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                  >
                                    {daysArray.map(d => (
                                      <option key={d} value={d}>{d}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>

                              {/* Month Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">MONTH</span>
                                <div className="relative">
                                  <select 
                                    value={currentMonth}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_month`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-550 focus:outline-none appearance-none border`}
                                  >
                                    {monthsList.map((m, idx) => (
                                      <option key={idx} value={idx + 1}>{m}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>

                              {/* Year Dropdown */}
                              <div className="flex flex-col gap-1 text-left">
                                <span className="text-[9px] font-mono text-gray-400 font-bold uppercase">YEAR</span>
                                <div className="relative">
                                  <select 
                                    value={currentYear}
                                    onChange={(e) => setInputsState(p => ({ ...p, [`${prefix}_year`]: Number(e.target.value) }))}
                                    className={`w-full ${selectBg} rounded-xl px-2.5 py-2 text-xs font-mono focus:ring-1 focus:ring-emerald-555 focus:outline-none appearance-none border`}
                                  >
                                    {yearsArray.map(y => (
                                      <option key={y} value={y}>{y}</option>
                                    ))}
                                  </select>
                                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[9px]">▼</div>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {/* Render Non-Date fields */}
                      {activeTool.inputs.filter(input => !isGroupedInput(input.id)).map((input) => {
                        const currentVal = inputsState[input.id] ?? input.default;
                        
                        // Direct dynamic checking based on user prompt criteria
                        const isPercentSymbol = input.suffix === "%" || (input.prefix && input.prefix.includes("%")) || input.id.includes("rate") || input.id.includes("apr") || input.id.includes("tax") || input.label.toLowerCase().includes("getiri") || input.label.toLowerCase().includes("yield") || input.label.toLowerCase().includes("faiz") || input.label.toLowerCase().includes("oran");
                        const isMonthlyMoney = input.id.includes("monthly") || input.id.includes("payment") || input.id.includes("addition") || input.id.includes("rent") || input.label.toLowerCase().includes("monthly") || input.label.toLowerCase().includes("aylık") || input.label.toLowerCase().includes("kira") || input.label.toLowerCase().includes("para");

                        // Prioritize explicitly specified values from the tool's definition
                        let minSlider = input.min !== undefined ? input.min : 0;
                        let maxSlider = input.max !== undefined ? input.max : 10000;
                        let stepValue = input.step !== undefined ? input.step : 100;

                        // Only apply default fallback overrides if no explicit range was defined
                        if (input.min === undefined || input.max === undefined) {
                          if (isPercentSymbol) {
                            minSlider = 0;
                            maxSlider = 40; // 0% - 40% slidable bounds for normal percentage calculations
                            stepValue = 0.5;
                          } else if (isMonthlyMoney) {
                            minSlider = 0;
                            maxSlider = 10000; // strictly 0 - 10000 limit
                            stepValue = 50;
                          } else if (input.id.includes("years") || input.id.includes("term") || input.label.toLowerCase().includes("yıl") || input.label.toLowerCase().includes("duration")) {
                            minSlider = 1;
                            maxSlider = 55;
                            stepValue = 1;
                          }
                        }

                        // Bound slider visuals while allowing manual entries to exceed bounds intact!
                        const sliderValue = currentVal > maxSlider ? maxSlider : (currentVal < minSlider ? minSlider : currentVal);

                        return (
                          <div 
                            key={input.id} 
                            className={`${boxBg} rounded-2xl p-4 flex flex-col justify-between border hover:border-neutral-500 dark:hover:border-neutral-800 transition-colors duration-250`}
                          >
                            <div className="flex justify-between items-center mb-2">
                              <label className="text-[9px] uppercase font-mono tracking-widest text-neutral-550 dark:text-gray-400 font-extrabold pr-2">
                                {input.label}
                              </label>
                              <span className={`text-[11px] font-black ${textTitle} font-mono bg-neutral-200/50 dark:bg-neutral-850 px-2 py-0.5 rounded-lg`}>
                                {formatValue(currentVal, input.prefix || "", input.suffix || "")}
                              </span>
                            </div>

                            {/* Slider support alongside manual input overrides */}
                            {input.type === "slider" ? (
                              <div className="flex flex-col gap-1.5 mt-1">
                                <div className="flex items-center gap-2.5">
                                  <input
                                    type="range"
                                    min={minSlider}
                                    max={maxSlider}
                                    step={stepValue}
                                    value={sliderValue}
                                    onChange={(e) => {
                                      setInputsState(p => ({ ...p, [input.id]: Number(e.target.value) }));
                                    }}
                                    style={{ accentColor: accentColor }}
                                    className="flex-grow h-1 rounded-lg appearance-none cursor-pointer bg-neutral-250 dark:bg-neutral-850"
                                    id={`input-slider-${input.id}`}
                                  />

                                  {/* Manual Input Box */}
                                  <div className="relative flex-shrink-0">
                                    <input
                                      type="number"
                                      value={currentVal}
                                      onChange={(e) => {
                                        const numInput = e.target.value === "" ? "" : (isNaN(Number(e.target.value)) ? 0 : Number(e.target.value));
                                        setInputsState(p => ({ ...p, [input.id]: numInput }));
                                      }}
                                      className={`w-16 text-center text-xs py-1.5 rounded-lg border font-mono select-all focus:ring-1 focus:ring-emerald-500 ${
                                        isDark 
                                          ? "bg-[#1E1E22] border-[#2C2C35] text-white" 
                                          : "bg-white border-slate-350 text-slate-800"
                                      } focus:outline-none`}
                                    />
                                  </div>
                                </div>
                                <div className="flex justify-between text-[8px] text-gray-500 font-mono">
                                  <span>Min: {formatValue(minSlider, input.prefix, input.suffix)}</span>
                                  <span>Max Bound: {formatValue(maxSlider, input.prefix, input.suffix)}</span>
                                </div>
                              </div>
                            ) : input.type === "select" ? (
                              <div className="relative mt-1">
                                <select
                                  value={currentVal}
                                  onChange={(e) => {
                                    setInputsState(p => ({ ...p, [input.id]: isNaN(Number(e.target.value)) ? e.target.value : Number(e.target.value) }));
                                  }}
                                  className={`w-full ${selectBg} rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none appearance-none border`}
                                  id={`input-select-${input.id}`}
                                >
                                  {(input.options || ["10", "15", "20", "30"]).map((opt) => (
                                    <option key={opt} value={opt}>
                                      {opt} {input.suffix || ""}
                                    </option>
                                  ))}
                                </select>
                                <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-[10px]">▼</div>
                              </div>
                            ) : (
                              // Standard numeric fields
                              <div className={`relative mt-1 flex items-center border rounded-xl px-2.5 ${isDark ? "bg-[#1E1E22] border-[#2C2C35]" : "bg-white border-slate-200 shadow-xs"}`}>
                                {input.prefix && (
                                  <span className="text-xs text-gray-400 font-semibold font-mono pr-0.5">
                                    {input.prefix}
                                  </span>
                                )}
                                <input
                                  type="number"
                                  value={currentVal}
                                  onChange={(e) => {
                                    setInputsState(p => ({ ...p, [input.id]: Number(e.target.value) }));
                                  }}
                                  className={`w-full bg-transparent border-none py-2 text-xs focus:outline-none font-mono ${isDark ? "text-white" : "text-slate-800"}`}
                                  id={`input-num-${input.id}`}
                                />
                                {input.suffix && (
                                  <span className="text-xs text-gray-400 font-mono pl-0.5">
                                    {input.suffix}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Calculated Numerical Result display panel inside Left Column */}
                    {!(
                      activeTool.tool_type === "budget" ||
                      activeTool.title.toLowerCase().includes("50/30/20") ||
                      activeTool.title.toLowerCase().includes("budget") ||
                      activeTool.title.toLowerCase().includes("splitter") ||
                      activeTool.title.toLowerCase().includes("bütçe") ||
                      (activeTool.output_label && activeTool.output_label.toLowerCase().includes("20%"))
                    ) && (
                      <div className={`p-5 ${isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/80"} border rounded-2xl relative overflow-hidden`} id="results-display-pnl">
                        <div className="absolute -bottom-8 -right-8 w-20 h-20 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

                        <div className="text-center md:text-left flex flex-col justify-between relative z-10 gap-3">
                          <div>
                            <span className="text-[9px] tracking-widest uppercase font-mono text-gray-500 font-extrabold block">
                              {activeTool.output_label || "Calculated Balance Outcome"}
                            </span>
                            <div className={`text-lg md:text-2xl font-black ${textTitle} mt-1.5 font-mono flex flex-wrap items-center justify-center md:justify-start tracking-tight leading-snug`}>
                              {activeTool.tool_type === "date_difference"
                                ? getExactTimeDifferenceText(
                                    inputsState["start_day"] ?? 15,
                                    inputsState["start_month"] ?? 6,
                                    inputsState["start_year"] ?? 1994
                                  )
                                : formatValue(calculatedOutput, activeTool.output_prefix || "", activeTool.output_suffix || "")
                              }
                            </div>
                          </div>
                          
                          <div className={`self-start text-[9px] uppercase font-mono font-bold px-2.5 py-1 rounded-lg border flex gap-1.5 items-center tracking-wider ${
                            isDark ? "bg-[#1E1E22] border-[#2C2C35] text-gray-300" : "bg-white border-slate-200 text-slate-700 shadow-xs"
                          }`}>
                            <TrendingUp className="w-3.5 h-3.5 text-emerald-450" />
                            <span>Real-Time Computed</span>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Right Column: Premium Side-by-Side Charts & Actionable AI Insights */}
                  <div className="lg:col-span-7 flex flex-col gap-6" id="calc-charts-column">
                    
                    {/* Live SVGs Chart Panel or Bento Time Statistics Grid */}
                    {activeTool.tool_type === "date_difference" ? (
                      <div className="w-full flex-grow flex flex-col justify-start" id="date-custom-statistics">
                        <span className="text-[10px] font-mono tracking-widest text-[#10B981] dark:text-[#00FF87] font-extrabold block uppercase mb-4">
                          🕒 Time Metric Live Statistics Breakdowns
                        </span>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4" id="date-stats-grid">
                          {projectionsData.map((stat, idx) => (
                            <div 
                              key={idx} 
                              className={`p-5 rounded-2xl border flex flex-col justify-between transition-all duration-350 hover:scale-[1.02] hover:border-emerald-500/40 ${
                                isDark ? "bg-[#18181B] border-[#27272A] hover:bg-[#202024]" : "bg-white border-slate-200/95 hover:bg-slate-50 shadow-xs"
                              }`}
                            >
                              <div>
                                <span className="text-[9px] font-mono tracking-wider text-gray-400 block uppercase mb-1.5">{stat.label}</span>
                                <span className={`text-xl font-mono font-extrabold tracking-tight ${textTitle} block`}>
                                  {stat.value.toLocaleString()}
                                </span>
                              </div>
                              <div className="mt-4 pt-3 border-t border-dashed border-neutral-400/20">
                                <span className="text-[9px] font-mono text-gray-500 block uppercase mb-0.5">{stat.secondaryLabel}</span>
                                <span className="text-xs font-mono font-extrabold text-[#10B981]">
                                  {stat.secondaryValue?.toLocaleString() ?? 0}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : activeTool.chart_type !== "none" ? (
                      <div className="w-full flex-grow flex flex-col justify-between" id="chart-display-container">
                        <CustomChart 
                          data={projectionsData} 
                          chartType={activeTool.chart_type} 
                          theme={theme} 
                          outputPrefix={activeTool.output_prefix}
                          outputSuffix={activeTool.output_suffix}
                        />
                      </div>
                    ) : (
                      activeTool.title.toLowerCase().includes("bmi") || activeTool.tool_type.includes("bmi") ? (
                        <div className="w-full" id="bmi-empty-chart-space" />
                      ) : (
                        <div className={`p-8 border rounded-2xl border-dashed text-center ${
                          isDark ? "bg-[#1E1E22]/30 border-[#2C2C35] text-gray-500" : "bg-slate-50/50 border-slate-200 text-slate-400"
                        }`}>
                          <BarChart2 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                          <p className="text-xs font-mono">Dynamic visualization not available for this custom format.</p>
                        </div>
                      )
                    )}

                    {/* Actionable Insights Panel */}
                    <div className={`p-4 ${isDark ? "bg-[#25252A] border-[#2E2E36]" : "bg-slate-50 border-slate-200/65"} border rounded-2xl text-xs flex gap-3 text-gray-400 font-sans`} id="insight-box-pnl">
                      <div className="w-8 h-8 flex-shrink-0 flex items-center justify-center bg-emerald-500/10 text-emerald-500 rounded-xl self-start">
                        <Sparkles className="w-4 h-4 animate-pulse" />
                      </div>
                      <div>
                        <span className="font-bold font-mono text-[9px] uppercase tracking-wider block mb-0.5 text-emerald-500">
                          Analytical Insight Projection
                        </span>
                        <p className={`leading-relaxed text-xs ${isDark ? "text-gray-300" : "text-slate-700"}`}>
                          {activeTool.insight}
                        </p>
                      </div>
                    </div>

                    {/* Custom Alert warnings (e.g. credit debt traps) */}
                    {activeTool.tool_type === "debt_payoff" && (() => {
                      const ccBal = inputsState["debt_balance"] || inputsState["balance"] || 1000;
                      const ccApr = inputsState["apr"] || inputsState["rate"] || 22;
                      const ccPay = inputsState["payment"] || 50;
                      const monthlyCCRate = ccApr / 100 / 12;
                      const minPossiblePay = ccBal * monthlyCCRate;
                      
                      if (ccPay <= minPossiblePay) {
                        return (
                          <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-500 text-xs text-center font-bold font-mono leading-relaxed animate-pulse">
                            ⚠️ High-Interest Debt Warning: Your monthly payment of {formatValue(ccPay, "$")} is lower than or equal to the accruing monthly interest of {formatValue(minPossiblePay, "$")}. Your balance will escalate indefinitely under this payment yield! Increase your monthly payment.
                          </div>
                        );
                      }
                      return null;
                    })()}

                  </div>

                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 9. Direct Categorized Tree Catalogue View */}
        {!activeTool && (
          <div className="w-full mt-6" id="empty-state-ghost-container">
            <div className="text-center mb-6" id="catalog-title">
              <h3 className="text-xs font-mono font-bold text-slate-500 dark:text-gray-400 uppercase tracking-widest flex items-center justify-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                100+ PREINSTALLED UTILITY & FINANCIAL CALCULATORS
              </h3>
            </div>
            
            {/* Direct catalog with state selection filtering, passing matching search parameters */}
            <GhostPreviews 
              onSelectGhost={handleGhostSelect} 
              searchTerm={query} 
              theme={theme}
            />
          </div>
        )}

      </main>

      {/* 3. Global Footer credits */}
      <footer className={`text-center py-6 border-t ${isDark ? "border-stone-900" : "border-slate-200"} mt-12 px-4`} id="global-footer">
        <p className="text-[10px] text-gray-500 tracking-widest font-mono uppercase">
          © 2026 wlth.app • High-Precision Interactive Calculators & Analytical Visualizers.
        </p>
      </footer>

      {/* 4. Elegant, Soft Backdrop Fade & Blur Theme Transition (60 FPS fluid) */}
      <AnimatePresence>
        {isWaveActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25, ease: "easeInOut" }}
            style={{ willChange: "opacity" }}
            className={`fixed inset-0 z-[999999] pointer-events-none ${
              theme === "dark" ? "bg-black/35" : "bg-white/35"
            } backdrop-blur-xs`}
          />
        )}
      </AnimatePresence>



    </div>
  );
}
