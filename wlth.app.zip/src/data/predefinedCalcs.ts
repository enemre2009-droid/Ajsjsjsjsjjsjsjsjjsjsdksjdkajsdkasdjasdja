import { CalculatorTool } from "../types";
import { generateGenericCalculator, TOOL_DATABASE } from "./calculatorGenerator";

export const PREDEFINED_CALCULATORS: CalculatorTool[] = [
  {
    tool_type: "compound_interest",
    title: "Instant Compound Interest Growth",
    description: "Model savings compounding monthly using normal parameters",
    inputs: [
      {
        id: "principal",
        label: "Starting Capital",
        type: "slider",
        default: 5000,
        prefix: "$",
        min: 100,
        max: 200000,
        step: 500
      },
      {
        id: "rate",
        label: "Annual Yield (APR)",
        type: "slider",
        default: 10,
        suffix: "%",
        min: 0,
        max: 1000,
        step: 0.5
      },
      {
        id: "years",
        label: "Duration Over Years",
        type: "slider",
        default: 10,
        suffix: " yrs",
        min: 1,
        max: 50,
        step: 1
      },
      {
        id: "monthly",
        label: "Monthly Deposit Increment",
        type: "slider",
        default: 200,
        prefix: "$",
        min: 0,
        max: 10000,
        step: 50
      }
    ],
    formula: "principal * pow(1 + (rate/100)/12, years * 12) + (rate === 0 ? monthly * years * 12 : monthly * (pow(1 + (rate/100)/12, years * 12) - 1) / ((rate/100)/12) * (1 + (rate/100)/12))",
    output_label: "Estimated Future Wealth Portfolio",
    output_prefix: "$",
    chart_type: "line",
    insight: "Consistency beats market timing. Small automated monthly deposits compound into monumental futures."
  },
  {
    tool_type: "debt_payoff",
    title: "Credit Card Debt Payoff Planner",
    description: "Shatter compounding interest traps with structured monthly paydowns",
    inputs: [
      {
        id: "debt_balance",
        label: "Remaining Debt Balance",
        type: "slider",
        default: 10000,
        prefix: "$",
        min: 500,
        max: 100000,
        step: 500
      },
      {
        id: "apr",
        label: "Annual rate (CC APR)",
        type: "slider",
        default: 22,
        suffix: "%",
        min: 0,
        max: 1000,
        step: 0.5
      },
      {
        id: "payment",
        label: "Proposed Monthly Payment",
        type: "slider",
        default: 350,
        prefix: "$",
        min: 50,
        max: 10000,
        step: 25
      }
    ],
    formula: "round(log(payment / (payment - debt_balance * (apr / 100 / 12))) / log(1 + (apr / 100 / 12)))",
    output_label: "Months Needed to Be Fully Debt-Free",
    output_suffix: " months",
    chart_type: "none",
    insight: "Squeezing out extra payments above the monthly minimum accelerates freedom and stops interest bloodbaths."
  },
  {
    tool_type: "mortgage",
    title: "Strategic Mortgage Estimator",
    description: "Run monthly payments, down reserves, and interest factors on real property",
    inputs: [
      {
        id: "price",
        label: "Total Home Price",
        type: "slider",
        default: 350000,
        prefix: "$",
        min: 50000,
        max: 2000000,
        step: 5000
      },
      {
        id: "down",
        label: "Down Payment Reserve Portion",
        type: "slider",
        default: 20,
        suffix: "%",
        min: 3,
        max: 80,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Mortgage APY",
        type: "slider",
        default: 6.5,
        suffix: "%",
        min: 1,
        max: 100,
        step: 0.1
      },
      {
        id: "years",
        label: "Repayment Period Duration",
        type: "select",
        default: 30,
        suffix: " yrs",
        options: ["15", "20", "30"]
      }
    ],
    formula: "(price * (1 - down / 100)) * ((rate/100/12) * pow(1 + (rate/100/12), years * 12)) / (pow(1 + (rate/100/12), years * 12) - 1)",
    output_label: "Estimated Monthly Principal & Interest Payment",
    output_prefix: "$",
    chart_type: "line",
    insight: "Every 1% saved on mortgage financing interest rates translates to tens of thousands in unspent wealth over 30 years."
  },
  {
    tool_type: "budget",
    title: "50/30/20 Smart Lifestyle Splitter",
    description: "Secure savings automatically while balancing your wants and needs",
    inputs: [
      {
        id: "income",
        label: "Monthly Net Take-Home Pay",
        type: "slider",
        default: 5000,
        prefix: "$",
        min: 0,
        max: 30000,
        step: 100
      }
    ],
    formula: "income * 0.20",
    output_label: "Target Monthly Automated Future Savings Portion (20%)",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Automate financial transfers to split allocations straight from payday so you never struggle with willpower."
  },
  {
    tool_type: "salary",
    title: "Annual Gross Tax Take-Home Estimator",
    description: "Analyze standard federal and state taxes to see pure monthly money",
    inputs: [
      {
        id: "wage",
        label: "Annual Gross Salary",
        type: "slider",
        default: 75000,
        prefix: "$",
        min: 10000,
        max: 500000,
        step: 2500
      }
    ],
    formula: "(wage - (wage * 0.12 + wage * 0.05 + wage * 0.0765)) / 12",
    output_label: "Your Net Take-Home Payment Each Month",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Maximize your tax write-offs or employer matching 401(k) lines to shield dividends from federal tax rates."
  },
  {
    tool_type: "macronutrient",
    title: "Macro-Nutrient Smart Splitter",
    description: "Convert your target daily calorie intake into balanced grams of Protein, Carbs, and Healthy Fats represented in beautiful interactive slices",
    inputs: [
      {
        id: "calories",
        label: "Daily Target Calorie Intake (kcal)",
        type: "slider",
        default: 2000,
        suffix: " kcal",
        min: 1000,
        max: 6000,
        step: 50
      },
      {
        id: "protein_ratio",
        label: "Protein Target Ratio (%)",
        type: "slider",
        default: 30,
        suffix: "%",
        min: 10,
        max: 60,
        step: 5
      },
      {
        id: "fats_ratio",
        label: "Healthy Fats Ratio (%)",
        type: "slider",
        default: 30,
        suffix: "%",
        min: 10,
        max: 50,
        step: 5
      }
    ],
    formula: "calories * (protein_ratio / 100) / 4",
    output_label: "Protein Daily Target Allowance",
    output_suffix: " g (protein)",
    chart_type: "bar",
    insight: "Proteins and carbohydrates contain 4 calories per gram, while fats are high density containing 9 calories per gram."
  },
  {
    tool_type: "freelancer_allocator",
    title: "Freelancer Income & Revenue Splitter",
    description: "Optimize your freelance payouts by splitting gross invoice business revenues into taxes, expenses, investments, and personal net take-home salary shares represented in interactive slice shares.",
    inputs: [
      {
        id: "monthly_rev",
        label: "Gross Monthly Invoiced Revenue",
        type: "slider",
        default: 8000,
        prefix: "$",
        min: 1000,
        max: 40000,
        step: 250
      },
      {
        id: "tax_ratio",
        label: "Tax Provision Ratio Buffer (%)",
        type: "slider",
        default: 25,
        suffix: "%",
        min: 0,
        max: 50,
        step: 1
      },
      {
        id: "exp_ratio",
        label: "Overheads & Tools Business expense (%)",
        type: "slider",
        default: 15,
        suffix: "%",
        min: 0,
        max: 45,
        step: 1
      },
      {
        id: "inv_ratio",
        label: "Active Wealth Portfolio Investment Rate (%)",
        type: "slider",
        default: 20,
        suffix: "%",
        min: 0,
        max: 50,
        step: 1
      }
    ],
    formula: "monthly_rev * ((100 - tax_ratio - exp_ratio - inv_ratio) / 100)",
    output_label: "Personal Owner Salary Draw",
    output_prefix: "$",
    chart_type: "bar",
    insight: "Allocating 20% to personal wealth investments compounded over years is key to securing developer financial independence."
  },
  {
    tool_type: "freelancer_wealth_multiplying_tracker",
    title: "Freelancer Wealth Compounding Projections",
    description: "See your money grow exponentially month over month! Project compound returns on recurring freelance savings compounded yearly.",
    inputs: [
      {
        id: "init_reserve",
        label: "Initial Reserve Capital Nest Egg",
        type: "slider",
        default: 1000,
        prefix: "$",
        min: 0,
        max: 50000,
        step: 500
      },
      {
        id: "monthly_dep",
        label: "Automated Recurring Monthly Saving",
        type: "slider",
        default: 500,
        prefix: "$",
        min: 50,
        max: 10000,
        step: 50
      },
      {
        id: "annual_return",
        label: "Anticipated Long-term Return (APY %)",
        type: "slider",
        default: 20,
        suffix: "%",
        min: 1,
        max: 40,
        step: 0.5
      },
      {
        id: "growth_years",
        label: "Planning Investment Horizon (Years)",
        type: "slider",
        default: 10,
        suffix: " yrs",
        min: 1,
        max: 30,
        step: 1
      }
    ],
    formula: "init_reserve * pow(1 + (annual_return/100), growth_years) + monthly_dep * 12 * (pow(1 + (annual_return/100), growth_years) - 1) / (annual_return/100 || 0.001)",
    output_label: "Projected Compounded Capital Portfolio",
    output_prefix: "$",
    chart_type: "line",
    insight: "Even small savings like $500 monthly invested at higher annual rates compound heavily over a decade."
  },
  {
    tool_type: "boy_kilo",
    title: "Weight & Metric Conversion Calculator",
    description: "Convert height & weight between Metric and Imperial instantly, showing real-time BMI classification comparison.",
    inputs: [
      {
        id: "weight_kg",
        label: "Kilo / Weight (kg)",
        type: "slider",
        default: 70,
        suffix: " kg",
        min: 0,
        max: 130,
        step: 1
      },
      {
        id: "height_cm",
        label: "Boy / Height (cm)",
        type: "slider",
        default: 175,
        suffix: " cm",
        min: 0,
        max: 210,
        step: 1
      }
    ],
    formula: "height_cm === 0 ? 0 : weight_kg / pow(height_cm / 100, 2)",
    output_label: "Body Mass Index (BMI)",
    output_suffix: " BMI",
    chart_type: "none",
    insight: "Healthy BMI category is between 18.5 and 24.9. Adjust sliders to see equivalents in pounds (lbs) and inches (in) instantly."
  }
];

export function findMatchingPredefinedCalculator(query: string): CalculatorTool | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  // Normalize query for simplified matching (removing non-alphanumeric chars)
  const cleanQ = q.replace(/[^a-z0-9]/g, "");

  // 1. Direct exact or partial match with keys of TOOL_DATABASE
  for (const k of Object.keys(TOOL_DATABASE)) {
    const cleanKey = k.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (cleanQ === cleanKey) {
      return generateGenericCalculator(k);
    }
  }

  // 2. Exact match with the title of items in TOOL_DATABASE
  for (const k of Object.keys(TOOL_DATABASE)) {
    const tool = TOOL_DATABASE[k];
    if (tool.title && tool.title.toLowerCase().replace(/[^a-z0-9]/g, "") === cleanQ) {
      return generateGenericCalculator(k);
    }
  }

  // 3. Exact word match in key or title
  for (const k of Object.keys(TOOL_DATABASE)) {
    const tool = TOOL_DATABASE[k];
    const cleanKeyWords = k.toLowerCase().replace(/_/g, " ").split(" ");
    const cleanTitleWords = tool.title ? tool.title.toLowerCase().split(" ") : [];
    
    if (cleanKeyWords.includes(q) || cleanTitleWords.includes(q)) {
      return generateGenericCalculator(k);
    }
  }

  // 4. Substring matching within key or title
  for (const k of Object.keys(TOOL_DATABASE)) {
    const tool = TOOL_DATABASE[k];
    if (k.toLowerCase().includes(q) || (tool.title && tool.title.toLowerCase().includes(q))) {
      return generateGenericCalculator(k);
    }
  }

  // 5. Hardcoded fallbacks/alias interceptors
  // Weight & height metric tools / BMI
  if (
    q.includes("boy") ||
    q.includes("kilo") ||
    q.includes("weight") ||
    q.includes("height") ||
    q.includes("metric") ||
    q.includes("conversion") ||
    q.includes("converter") ||
    q.includes("bmi") ||
    q === "boy_kilo"
  ) {
    return PREDEFINED_CALCULATORS[8];
  }

  // Freelancer tools
  if (
    q.includes("freelance") ||
    q.includes("remote") ||
    q.includes("contractor") ||
    q.includes("gigger") ||
    q.includes("independent") ||
    q.includes("yazar") ||
    q.includes("coder") ||
    q.includes("developer")
  ) {
    return PREDEFINED_CALCULATORS[PREDEFINED_CALCULATORS.length - 2];
  }

  if (
    q.includes("grow") ||
    q.includes("wealth") ||
    q.includes("savings compounding") ||
    q.includes("freelancer saving") ||
    q.includes("passive") ||
    q.includes("earn")
  ) {
    return PREDEFINED_CALCULATORS[PREDEFINED_CALCULATORS.length - 1];
  }

  // Fitness macro tools
  if (
    q.includes("macro") || 
    q.includes("protein") || 
    q.includes("diyet") || 
    q.includes("beslenme") || 
    q.includes("nutrition") || 
    q.includes("carbohydrate") || 
    q.includes("lipids") || 
    q.includes("bcaa")
  ) {
    return PREDEFINED_CALCULATORS[5];
  }

  // Localized "tarih" or "date" calculators
  if (q.includes("tarih") || q === "date" || q.includes("date calc") || q.includes("date_calc") || q.includes("gün farkı") || q.includes("tarih farkı")) {
    return generateGenericCalculator("date_calculator");
  }

  // Age & day calculators
  if (q === "age" || q.includes("yaş hesap") || q.includes("yas hesap") || q === "yaş" || q === "yas") {
    return generateGenericCalculator("age");
  }

  // Compound Interest
  if (
    q.includes("compound") ||
    q.includes("interest") ||
    q.includes("invest") ||
    q.includes("yield") ||
    q.includes("faiz") ||
    q.includes("bileşik") ||
    q.includes("birikim") ||
    q.includes("annual return")
  ) {
    return PREDEFINED_CALCULATORS[0];
  }

  // Debt Playbook
  if (
    q.includes("debt") ||
    q.includes("payoff") ||
    q.includes("pay off") ||
    q.includes("credit card") ||
    q.includes("apr") ||
    q.includes("borç") ||
    q.includes("kredi ödeme")
  ) {
    return PREDEFINED_CALCULATORS[1];
  }

  // Mortgage
  if (
    q.includes("mortgage") ||
    q.includes("home") ||
    q.includes("house") ||
    q.includes("property") ||
    q.includes("konut") ||
    q.includes("ev kredisi")
  ) {
    return PREDEFINED_CALCULATORS[2];
  }

  // Budget
  if (
    q.includes("budget") ||
    q.includes("50/30/20") ||
    q.includes("splitter") ||
    q.includes("rule") ||
    q.includes("bütçe")
  ) {
    return PREDEFINED_CALCULATORS[3];
  }

  // Salary
  if (
    q.includes("salary") ||
    q.includes("wage") ||
    q.includes("tax") ||
    q.includes("take home") ||
    q.includes("take-home") ||
    q.includes("maaş") ||
    q.includes("vergi")
  ) {
    return PREDEFINED_CALCULATORS[4];
  }

  return null;
}
