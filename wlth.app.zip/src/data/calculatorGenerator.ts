import { CalculatorTool } from "../types";

// Dynamic map of customized calculator definitions (Fully translated to English)
export const TOOL_DATABASE: Record<string, Partial<CalculatorTool>> = {
  // --- FINANCIAL ---
  "mortgage": {
    tool_type: "mortgage",
    title: "Home Mortgage Estimator",
    description: "Analyze monthly mortgage payments, down payment reserves, and interest factors.",
    inputs: [
      { id: "price", label: "Home Value ($)", type: "slider", default: 500000, prefix: "$", min: 50000, max: 5000000, step: 10000 },
      { id: "down", label: "Down Payment (%)", type: "slider", default: 20, suffix: "%", min: 0, max: 80, step: 1 },
      { id: "rate", label: "Annual Interest Rate (%)", type: "slider", default: 6.5, suffix: "%", min: 1, max: 35, step: 0.1 },
      { id: "years", label: "Loan Term (Years)", type: "select", default: 30, options: ["10", "15", "20", "30"], suffix: " Yrs" }
    ],
    formula: "(price * (1 - down / 100)) * ((rate/100/12) * pow(1 + (rate/100/12), years * 12)) / (pow(1 + (rate/100/12), years * 12) - 1)",
    output_label: "Estimated Monthly Principal & Interest",
    output_prefix: "$",
    chart_type: "line",
    insight: "Increasing your down payment to 20% or more avoids costly Private Mortgage Insurance (PMI) and saves tens of thousands in interest."
  },
  "amortization": {
    tool_type: "mortgage",
    title: "Amortization Schedule",
    description: "See how your loan payments split between interest principal versus outstanding balance over time.",
    inputs: [
      { id: "loan", label: "Total Loan Amount", type: "slider", default: 300000, prefix: "$", min: 10000, max: 2000000, step: 5000 },
      { id: "rate", label: "Interest Rate (%)", type: "slider", default: 7.0, suffix: "%", min: 1, max: 40, step: 0.1 },
      { id: "years", label: "Loan Duration (Years)", type: "select", default: 15, options: ["5", "10", "15", "20", "30"], suffix: " Yrs" }
    ],
    formula: "loan * ((rate/100/12) * pow(1 + (rate/100/12), years * 12)) / (pow(1 + (rate/100/12), years * 12) - 1)",
    output_label: "Estimated Monthly Payment",
    output_prefix: "$",
    chart_type: "line",
    insight: "In the early years of a loan, the majority of your payment goes toward interest, while principal paydown accelerates later."
  },
  "mortgage_payoff": {
    tool_type: "debt_payoff",
    title: "Early Mortgage Payoff Planner",
    description: "Determine how much time and interest you save by making extra monthly principal payments.",
    inputs: [
      { id: "balance", label: "Current Balance", type: "slider", default: 250000, prefix: "$", min: 10000, max: 2000000, step: 10000 },
      { id: "rate", label: "Mortgage Rate (%)", type: "slider", default: 6.5, suffix: "%", min: 1, max: 35, step: 0.1 },
      { id: "payment", label: "Normal Monthly Payment", type: "slider", default: 1580, prefix: "$", min: 100, max: 10000, step: 50 },
      { id: "extra", label: "Extra Monthly Payment", type: "slider", default: 250, prefix: "$", min: 0, max: 10000, step: 50 }
    ],
    formula: "round(log(payment / (payment - balance * (rate / 100 / 12))) / log(1 + (rate / 100 / 12))) - round(log((payment + extra) / ((payment + extra) - balance * (rate / 100 / 12))) / log(1 + (rate / 100 / 12)))",
    output_label: "Time Saved (Months Saved)",
    output_suffix: " Months Early",
    chart_type: "none",
    insight: "Adding just $250 extra every single month can cut about 5 to 7 years off a typical 30-year home mortgage."
  },
  "house_affordability": {
    tool_type: "budget",
    title: "Home Affordability Calculator",
    description: "Check your maximum recommended home buying budget based on monthly household income and existing debt.",
    inputs: [
      { id: "income", label: "Monthly Net Income", type: "slider", default: 8000, prefix: "$", min: 1000, max: 100000, step: 100 },
      { id: "debts", label: "Other Monthly Debts", type: "slider", default: 400, prefix: "$", min: 0, max: 10000, step: 50 },
      { id: "down", label: "Available Down Payment", type: "slider", default: 50000, prefix: "$", min: 5000, max: 1000000, step: 2500 }
    ],
    formula: "(income * 0.28) * 150 + down",
    output_label: "Recommended Maximum Home Price",
    output_prefix: "$",
    chart_type: "none",
    insight: "Financial experts recommend keeping total monthly housing expenses under 28% to 36% of your net household income."
  },
  "rent": {
    tool_type: "budget",
    title: "Rent Affordability Estimator",
    description: "Calculate a safe maximum monthly rental budget based on your net earnings.",
    inputs: [
      { id: "income", label: "Your Monthly Net Income", type: "slider", default: 4500, prefix: "$", min: 500, max: 50000, step: 100 }
    ],
    formula: "income * 0.30",
    output_label: "Recommended Max Monthly Rent",
    output_prefix: "$",
    chart_type: "none",
    insight: "The standard 30% rule suggests allocating no more than one-third of net monthly take-home income toward rent."
  },
  "debt-to-income_ratio": {
    tool_type: "budget",
    title: "Debt-to-Income (DTI) Ratio Test",
    description: "Measure your financial leverage and see how your debt obligations stack against your earnings.",
    inputs: [
      { id: "debts", label: "Total Monthly Debt Payments", type: "slider", default: 1200, prefix: "$", min: 0, max: 10000, step: 50 },
      { id: "income", label: "Monthly Gross Income", type: "slider", default: 4000, prefix: "$", min: 500, max: 50000, step: 100 }
    ],
    formula: "(debts / income) * 100",
    output_label: "Debt-to-Income Ratio (DTI)",
    output_suffix: "% DTI",
    chart_type: "none",
    insight: "Lenders look for a DTI ratio under 36%. Anything exceeding 50% indicates heavy financial vulnerability."
  },
  "real_estate": {
    tool_type: "investment",
    title: "Real Estate Capitalization Rate (Cap Rate)",
    description: "Evaluate the profitability and returns of prospective investment properties.",
    inputs: [
      { id: "price", label: "Purchase Price", type: "slider", default: 300000, prefix: "$", min: 10000, max: 5000000, step: 5000 },
      { id: "rent", label: "Monthly Rental Income", type: "slider", default: 1800, prefix: "$", min: 100, max: 20000, step: 50 },
      { id: "expenses", label: "Monthly Property Costs (Tax, Mgmt, etc)", type: "slider", default: 300, prefix: "$", min: 0, max: 5000, step: 20 }
    ],
    formula: "((rent - expenses) * 12 / price) * 100",
    output_label: "Estimated Annual Capitalization Rate (Cap Rate)",
    output_suffix: "% Cap Rate",
    chart_type: "none",
    insight: "A capitalization rate between 5% and 10% is typically considered a healthy yield for commercial or residential property."
  },
  "refinance": {
    tool_type: "mortgage",
    title: "Mortgage Refinance Savings",
    description: "Calculate potential interest savings from refinancing high-interest debt into lower rate loans.",
    inputs: [
      { id: "balance", label: "Remaining Principal", type: "slider", default: 200000, prefix: "$", min: 10000, max: 1000000, step: 5000 },
      { id: "old_rate", label: "Current Rate (%)", type: "slider", default: 7.5, suffix: "%", min: 1, max: 35, step: 0.1 },
      { id: "new_rate", label: "Proposed Refi Rate (%)", type: "slider", default: 5.5, suffix: "%", min: 1, max: 35, step: 0.1 },
      { id: "refi_cost", label: "Refinance Fees & Closing Costs", type: "slider", default: 3000, prefix: "$", min: 0, max: 15000, step: 100 }
    ],
    formula: "((balance * (old_rate/100) - balance * (new_rate/100)))",
    output_label: "Approximate Annual Interest Savings",
    output_prefix: "$",
    chart_type: "none",
    insight: "Aim to recoup your upfront refinance fee costs within 18 to 24 months of locking in a lower monthly rate."
  },
  "rental_property": {
    tool_type: "investment",
    title: "Rental Property Gross Yield",
    description: "Determine the gross yield percentage of real estate to judge return on investment.",
    inputs: [
      { id: "value", label: "Property Purchase Price", type: "slider", default: 250000, prefix: "$", min: 10000, max: 2000000, step: 5000 },
      { id: "income", label: "Gross Monthly Rent", type: "slider", default: 1500, prefix: "$", min: 100, max: 15000, step: 50 }
    ],
    formula: "(income * 12 / value) * 100",
    output_label: "Gross Rental Yield",
    output_suffix: "% Yield",
    chart_type: "none",
    insight: "An annual gross rental yield over 6% is generally viewed as a robust, dividend-generating property."
  },
  "apr": {
    tool_type: "compound_interest",
    title: "True Annual Percentage Rate (APR)",
    description: "Include hidden closing costs, points, and processing fees to uncover the true cost of borrowing.",
    inputs: [
      { id: "loan", label: "Loan Amount", type: "slider", default: 50000, prefix: "$", min: 1000, max: 500000, step: 1000 },
      { id: "rate", label: "Nominal Base Interest Rate (%)", type: "slider", default: 12.5, suffix: "%", min: 1, max: 150, step: 0.1 },
      { id: "fees", label: "Upfront Origination Fees", type: "slider", default: 1500, prefix: "$", min: 0, max: 20000, step: 100 }
    ],
    formula: "((loan * (rate / 100) + fees) / loan) * 100",
    output_label: "True Annual Borrowing Cost (APR)",
    output_suffix: "% APR",
    chart_type: "none",
    insight: "Low interest rate promotions can occasionally be offset by high lender fees. Always evaluate the stated APR."
  },
  "fha_loan": {
    tool_type: "mortgage",
    title: "FHA Down Payment Planner",
    description: "Calculate the minimal down payment required under standard Federal Housing Administration guidelines.",
    inputs: [
      { id: "price", label: "Home Base Cost", type: "slider", default: 200000, prefix: "$", min: 20000, max: 1000000, step: 5000 }
    ],
    formula: "price * 0.035",
    output_label: "Minimum FHA Down Payment (3.5%)",
    output_prefix: "$",
    chart_type: "none",
    insight: "FHA loans permit down payments as low as 3.5%, helping prospective first-time home buyers with restricted capital."
  },
  "va_mortgage": {
    tool_type: "mortgage",
    title: "VA Military Loan Estimator",
    description: "Obtain estimated monthly repayments on premium Veteran Association home financing.",
    inputs: [
      { id: "price", label: "Property Market Value", type: "slider", default: 300000, prefix: "$", min: 10000, max: 1500000, step: 5000 },
      { id: "rate", label: "Annual Interest Rate (%)", type: "slider", default: 6.0, suffix: "%", min: 1, max: 25, step: 0.1 }
    ],
    formula: "price * ((rate/100/12) * pow(1 + (rate/100/12), 360)) / (pow(1 + (rate/100/12), 360) - 1)",
    output_label: "Estimated Monthly Payment (30-Year Zero Down)",
    output_prefix: "$",
    chart_type: "line",
    insight: "VA home loans require zero down payment and waive standard Private Mortgage Insurance (PMI) premiums entirely."
  },
  "home_equity_loan": {
    tool_type: "mortgage",
    title: "Home Equity Borrowing Capacity",
    description: "Identify how much cash equity you can unlock from your primary residence's net worth.",
    inputs: [
      { id: "value", label: "Current Market Value", type: "slider", default: 400000, prefix: "$", min: 20000, max: 2000000, step: 5000 },
      { id: "mortgage", label: "Outstanding Mortgage Debt", type: "slider", default: 180000, prefix: "$", min: 0, max: 1000000, step: 5000 }
    ],
    formula: "value * 0.80 - mortgage",
    output_label: "Maximum Home Equity Loan Output Limit",
    output_prefix: "$",
    chart_type: "none",
    insight: "Financial institutions generally lock maximum loan-to-value limits to 80% to protect against local market corrections."
  },
  "heloc": {
    tool_type: "mortgage",
    title: "HELOC Interest-Only Payment",
    description: "Examine variable rate Home Equity Line of Credit draw costs.",
    inputs: [
      { id: "amount", label: "Drawn Credit Balance", type: "slider", default: 50000, prefix: "$", min: 1000, max: 500000, step: 1000 },
      { id: "rate", label: "HELOC Interest Rate (%)", type: "slider", default: 8.5, suffix: "%", min: 1, max: 30, step: 0.1 }
    ],
    formula: "amount * (rate / 100 / 12)",
    output_label: "Initial Interest-Only Monthly Expense",
    output_prefix: "$",
    chart_type: "none",
    insight: "A HELOC offers revolving access to home equity, but variable rates pose exposure to interest spikes."
  },
  "down_payment": {
    tool_type: "budget",
    title: "Home Down Payment Plan",
    description: "Figure out how long to save at your current clip to reach target earnest reserves.",
    inputs: [
      { id: "price", label: "Target Home Price", type: "slider", default: 350000, prefix: "$", min: 10000, max: 1500000, step: 5000 },
      { id: "percent", label: "Down Payment Goal (%)", type: "slider", default: 20, suffix: "%", min: 3, max: 50, step: 1 },
      { id: "save", label: "Planned Monthly Savings", type: "slider", default: 1000, prefix: "$", min: 50, max: 10000, step: 50 }
    ],
    formula: "(price * (percent / 100)) / save",
    output_label: "Duration Needed to Accumulate Reserves (Months)",
    output_suffix: " Months",
    chart_type: "none",
    insight: "Reaching a 20% down payment threshold bypasses mandatory PMI fees, reducing future monthly debt obligations."
  },
  "rent_vs_buy": {
    tool_type: "custom",
    title: "Rent vs. Buy Evaluation",
    description: "Contrast the long-term net financial performance of homeownership against renting.",
    inputs: [
      { id: "rent", label: "Monthly Rent Rate", type: "slider", default: 1500, prefix: "$", min: 100, max: 10000, step: 50 },
      { id: "price", label: "Purchase Home Value", type: "slider", default: 300000, prefix: "$", min: 10000, max: 2000000, step: 5000 },
      { id: "years", label: "Anticipated Tenure (Years)", type: "slider", default: 10, suffix: " Yrs", min: 1, max: 30, step: 1 }
    ],
    formula: "(rent * 12 * years) - (price * 0.15)",
    output_label: "Net Cost Comparison (Buy Over Rent Net Advantage)",
    output_prefix: "$",
    chart_type: "comparison",
    insight: "Staying in a property over 5 years tips the scale toward buying, as transaction closing fees are amortized."
  },

  // --- AUTOMOTIVE ---
  "auto_loan": {
    tool_type: "mortgage",
    title: "Car Auto Loan Calculator",
    description: "Calculate expected aggregate dealership loan payments based on vehicle values.",
    inputs: [
      { id: "price", label: "Vehicle Cost", type: "slider", default: 35000, prefix: "$", min: 2000, max: 300000, step: 500 },
      { id: "down", label: "Down Payment or Trade-In Value", type: "slider", default: 5000, prefix: "$", min: 0, max: 100000, step: 500 },
      { id: "rate", label: "Annual Loan Rate (%)", type: "slider", default: 5.9, suffix: "%", min: 0, max: 35, step: 0.1 },
      { id: "months", label: "Repayment Period (Months)", type: "select", default: 60, options: ["24", "36", "48", "60", "72", "84"], suffix: " Mo" }
    ],
    formula: "((price - down) * (rate/1200)) / (1 - pow(1 + rate/1200, -months))",
    output_label: "Monthly Auto Repayment Amount",
    output_prefix: "$",
    chart_type: "line",
    insight: "Keeping loan terms below 60 months prevents you from becoming upside-down on a depreciated asset."
  },
  "cash_back_or_low_interest": {
    tool_type: "custom",
    title: "Cash Back vs. Low Interest",
    description: "Decide between upfront discount incentives or low interest annual financing rates.",
    inputs: [
      { id: "price", label: "Vehicle Net Cost", type: "slider", default: 25000, prefix: "$", min: 5000, max: 150000, step: 500 },
      { id: "rebate", label: "Cash Rebate Incentive", type: "slider", default: 2000, prefix: "$", min: 0, max: 10000, step: 100 },
      { id: "rate_with_rebate", label: "Rate Offered with Rebate (%)", type: "slider", default: 6.0, suffix: "%", min: 0, max: 20, step: 0.1 },
      { id: "promo_rate", label: "Promotional Low APR Rate (%)", type: "slider", default: 1.9, suffix: "%", min: 0, max: 10, step: 0.1 }
    ],
    formula: "((price) * (promo_rate/100) * 5) - ((price - rebate) * (rate_with_rebate/100) * 5)",
    output_label: "Aggregate Savings for Promotional APR Rate Option",
    output_prefix: "$",
    chart_type: "comparison",
    insight: "With expensive sports vehicles or large SUVs, promotional 1.9% financing yields higher savings than flat cash rebates."
  },
  "auto_lease": {
    tool_type: "custom",
    title: "Auto Leasing Estimator",
    description: "Determine the baseline monthly depreciation cost under typical car lease agreements.",
    inputs: [
      { id: "msrp", label: "Vehicle MSRP", type: "slider", default: 40000, prefix: "$", min: 10000, max: 200000, step: 1000 },
      { id: "residual", label: "Residual Value Portion (%)", type: "slider", default: 55, suffix: "%", min: 30, max: 80, step: 1 },
      { id: "months", label: "Lease Duration (Months)", type: "select", default: 36, options: ["24", "36", "39", "48"], suffix: " Mo" }
    ],
    formula: "(msrp - (msrp * residual / 100)) / months",
    output_label: "Monthly Depreciation Baseline",
    output_prefix: "$",
    chart_type: "none",
    insight: "Negotiating MSRP discounts and securing high residual guarantees are key to lowering monthly lease bills."
  },

  // --- SAVINGS & INVESTMENT ---
  "interest": {
    tool_type: "compound_interest",
    title: "Simple Interest Income",
    description: "Verify immediate term interest dividends from liquid deposits.",
    inputs: [
      { id: "capital", label: "Initial Deposit Balance", type: "slider", default: 10000, prefix: "$", min: 100, max: 1000000, step: 500 },
      { id: "rate", label: "Annual Percentage Yield (%)", type: "slider", default: 5, suffix: "%", min: 1, max: 150, step: 0.5 },
      { id: "days", label: "Term Length (Days)", type: "slider", default: 30, suffix: " Days", min: 1, max: 365, step: 1 }
    ],
    formula: "(capital * (rate / 100) * days) / 365",
    output_label: "Term Maturity Profit",
    output_prefix: "$",
    chart_type: "none",
    insight: "Ensure you evaluate net returns after accounting for potential banking service commissions and local withholdings."
  },
  "investment": {
    tool_type: "investment",
    title: "Wealth Goal Projector",
    description: "Establish timelines to accumulate target sums with periodic contributions.",
    inputs: [
      { id: "target", label: "Desired Wealth Target", type: "slider", default: 100000, prefix: "$", min: 5000, max: 5000000, step: 5000 },
      { id: "start", label: "Initial Starting Balance", type: "slider", default: 10000, prefix: "$", min: 0, max: 1000000, step: 1000 },
      { id: "monthly", label: "Consistent Monthly Addition", type: "slider", default: 500, prefix: "$", min: 10, max: 10000, step: 50 }
    ],
    formula: "(target - start) / (monthly * 12)",
    output_label: "Timeline (Years) to Reach Target (Zero-Growth Baseline)",
    output_suffix: " Years",
    chart_type: "line",
    insight: "Investing deposits into index portfolios cuts wait times in half over long cycles through compounding gains."
  },
  "compound_interest": {
    tool_type: "compound_interest",
    title: "Compound Interest Engine",
    description: "Unravel the exponential capabilities of compounding, the engine of financial freedom.",
    inputs: [
      { id: "principal", label: "Initial Principal Capital", type: "slider", default: 20000, prefix: "$", min: 100, max: 1000000, step: 1000 },
      { id: "rate", label: "Expected Annual Yield (%)", type: "slider", default: 10, suffix: "%", min: 0, max: 200, step: 0.5 },
      { id: "years", label: "Horizon Duration (Years)", type: "slider", default: 15, suffix: " Yrs", min: 1, max: 50, step: 1 },
      { id: "monthly", label: "Monthly Recurrent Addition", type: "slider", default: 300, prefix: "$", min: 0, max: 10000, step: 50 }
    ],
    formula: "principal * pow(1 + (rate/100)/12, years * 12) + (rate === 0 ? monthly * years * 12 : monthly * (pow(1 + (rate/100)/12, years * 12) - 1) / ((rate/100)/12) * (1 + (rate/100)/12))",
    output_label: "Projected Portfolio Net Worth",
    output_prefix: "$",
    chart_type: "line",
    insight: "As Albert Einstein famously observed, compound interest is the eighth wonder of the world. Those who understand it earn it."
  },
  "interest_rate": {
    tool_type: "compound_interest",
    title: "Annual Percentage Yield (APY) APY Converter",
    description: "Convert nominal interest rates to actual yields accounting for varying compounding compound frequencies.",
    inputs: [
      { id: "nominal", label: "Nominal Annual Stated Rate (%)", type: "slider", default: 5.5, suffix: "%", min: 1, max: 150, step: 0.5 },
      { id: "periods", label: "Compounding Compounding Frequency", type: "select", default: 12, options: ["1", "4", "12", "365"], suffix: " Times/Yr" }
    ],
    formula: "(pow(1 + (nominal / 100) / periods, periods) - 1) * 100",
    output_label: "Effective Annual Percentage Yield (APY)",
    output_suffix: "% APY",
    chart_type: "none",
    insight: "Higher compounding frequency (e.g., daily compounding) naturally raises the real rate above the nominal rate."
  },
  "savings": {
    tool_type: "budget",
    title: "Long-Term Savings Tracker",
    description: "Project visual flat reserves built exclusively through steady deposits.",
    inputs: [
      { id: "monthly", label: "Planned Monthly Savings", type: "slider", default: 400, prefix: "$", min: 10, max: 10000, step: 10 },
      { id: "years", label: "Planned Duration (Years)", type: "slider", default: 10, suffix: " Yrs", min: 1, max: 50, step: 1 }
    ],
    formula: "monthly * 12 * years",
    output_label: "Total Safe Nominal Balance",
    output_prefix: "$",
    chart_type: "line",
    insight: "To prevent inflation from degrading your purchasing power, invest portions of savings into diversified equities."
  },
  "simple_interest": {
    tool_type: "compound_interest",
    title: "Simple Interest Calculator",
    description: "Determine straightforward interest payouts with zero compounding factors.",
    inputs: [
      { id: "principal", label: "Principal Capital", type: "slider", default: 20000, prefix: "$", min: 100, max: 500000, step: 1000 },
      { id: "rate", label: "Stated Annual Rate (%)", type: "slider", default: 8, suffix: "%", min: 1, max: 40, step: 0.5 },
      { id: "years", label: "Aggregation Term (Years)", type: "slider", default: 5, suffix: " Yrs", min: 1, max: 20, step: 1 }
    ],
    formula: "principal * (1 + (rate / 100) * years)",
    output_label: "Terminal Expected Sum",
    output_prefix: "$",
    chart_type: "line",
    insight: "Simple interest only calculates returns based on the original deposit balance, skipping payments on accumulated earnings."
  },
  "cd": {
    tool_type: "investment",
    title: "Certificate of Deposit (CD) Return",
    description: "Calculate expected payouts on secure, time-bound bank CD deposits.",
    inputs: [
      { id: "amount", label: "CD Investment Capital", type: "slider", default: 15000, prefix: "$", min: 500, max: 1000000, step: 1000 },
      { id: "rate", label: "Stated Annual Interest Rate (%)", type: "slider", default: 4.5, suffix: "%", min: 0.5, max: 20, step: 0.1 },
      { id: "months", label: "Maturity Duration (Months)", type: "slider", default: 12, suffix: " Months", min: 1, max: 60, step: 1 }
    ],
    formula: "amount * pow(1 + (rate/100)/12, months)",
    output_label: "Estimated Sum at Maturity",
    output_prefix: "$",
    chart_type: "line",
    insight: "CD certificates provide secure, FDIC-insured returns that outperform typical checking accounts, but lack early liquidity."
  },
  "bond": {
    tool_type: "investment",
    title: "Treasury Bond Coupon Estimator",
    description: "Project cash flow yields from fixed-income sovereign government bonds.",
    inputs: [
      { id: "face", label: "Face Value Maturation", type: "slider", default: 10000, prefix: "$", min: 100, max: 500000, step: 100 },
      { id: "coupon", label: "Annual Coupon Yield (%)", type: "slider", default: 5.5, suffix: "%", min: 0.5, max: 30, step: 0.1 },
      { id: "years", label: "Horizon Years to Mature", type: "slider", default: 10, suffix: " Yrs", min: 1, max: 30, step: 1 }
    ],
    formula: "face * (coupon / 100) * years + face",
    output_label: "Total Coupons + Princial Payback",
    output_prefix: "$",
    chart_type: "line",
    insight: "Backed by government guarantees, bonds serve to stabilize high-volatility stock-heavy portfolios."
  },
  "mutual_fund": {
    tool_type: "investment",
    title: "Mutual Fund Net Expense Impact",
    description: "Examine how advisory expense ratios erode aggregate yields over long periods.",
    inputs: [
      { id: "amount", label: "Base Capital", type: "slider", default: 50000, prefix: "$", min: 100, max: 1000000, step: 1000 },
      { id: "return_pct", label: "Annual Return Expectation (%)", type: "slider", default: 12, suffix: "%", min: 1, max: 100, step: 0.5 },
      { id: "ratio", label: "Advisory Fee Expense Ratio (%)", type: "slider", default: 1.5, suffix: "%", min: 0.05, max: 5, step: 0.05 },
      { id: "years", label: "Investment Duration (Years)", type: "slider", default: 10, suffix: " Yrs", min: 1, max: 50, step: 1 }
    ],
    formula: "amount * pow(1 + (return_pct - ratio)/100, years)",
    output_label: "Net Capital Portfolio Post-Fees",
    output_prefix: "$",
    chart_type: "line",
    insight: "High expense fees appear small but devour massive tranches of profit over 20-35 years. Opt for low-cost passive index funds."
  },
  "average_return": {
    tool_type: "investment",
    title: "Compound Annual Growth Rate (CAGR)",
    description: "Determine actual geometric average annual expansion rates on volatile trades.",
    inputs: [
      { id: "start", label: "Starting Capital", type: "slider", default: 10000, prefix: "$", min: 100, max: 1000000, step: 500 },
      { id: "end", label: "Post Terminal Valuation", type: "slider", default: 25000, prefix: "$", min: 200, max: 5000000, step: 1000 },
      { id: "years", label: "Horizon Span (Years)", type: "slider", default: 5, suffix: " Yrs", min: 1, max: 30, step: 1 }
    ],
    formula: "(pow(end / start, 1 / years) - 1) * 100",
    output_label: "Compound Annual Growth Rate (CAGR)",
    output_suffix: "% CAGR",
    chart_type: "none",
    insight: "Standard averages fail to accurately map volatile shifts. CAGR provides the precise baseline annual compound growth rate."
  },
  "irr": {
    tool_type: "investment",
    title: "Internal Rate of Return (IRR) Approximator",
    description: "Model simple IRR approximations for startups and venture projects.",
    inputs: [
      { id: "outflow", label: "Initial Capital Seeded", type: "slider", default: 50000, prefix: "$", min: 1000, max: 1000000, step: 5000 },
      { id: "inflow", label: "Average Cash Flow Inflows", type: "slider", default: 15000, prefix: "$", min: 100, max: 500000, step: 1000 },
      { id: "years", label: "Expected Horizon (Years)", type: "slider", default: 5, suffix: " Yrs", min: 1, max: 20, step: 1 }
    ],
    formula: "((inflow * years - outflow) / outflow) * 100",
    output_label: "Estimated Project Simple Net Output",
    output_suffix: "% Net Output",
    chart_type: "none",
    insight: "IRR represents the discounted yield break-even rate. Projects are viable when their IRR exceeds initial financing costs."
  },
  "roi": {
    tool_type: "investment",
    title: "Return on Investment (ROI)",
    description: "Calculate standard efficiency values on investments quickly.",
    inputs: [
      { id: "gain", label: "Net Profit Acquired", type: "slider", default: 8000, prefix: "$", min: -50000, max: 1000000, step: 500 },
      { id: "cost", label: "Total Cost Expended", type: "slider", default: 20000, prefix: "$", min: 100, max: 1000000, step: 500 }
    ],
    formula: "(gain / cost) * 100",
    output_label: "Stated ROI Efficiency Ratio",
    output_suffix: "% ROI",
    chart_type: "none",
    insight: "ROI serves as a handy metric to scan investments, but omits important dimensions of risk or time requirements."
  },
  "payback_period": {
    tool_type: "investment",
    title: "Investment Payback Period",
    description: "Determine the duration in years required to fully recover capital outflows.",
    inputs: [
      { id: "cost", label: "Total Capital Cost", type: "slider", default: 45000, prefix: "$", min: 500, max: 2000000, step: 1000 },
      { id: "annual_savings", label: "Expected Annual Inflow Return", type: "slider", default: 9000, prefix: "$", min: 100, max: 500000, step: 500 }
    ],
    formula: "cost / annual_savings",
    output_label: "Duration to Recoup Outlay (Years)",
    output_suffix: " Years",
    chart_type: "none",
    insight: "Shorter payback profiles lower venture exposure. Ideal payback periods range under 3 to 5 years."
  },
  "present_value": {
    tool_type: "investment",
    title: "Net Present Value of Capital",
    description: "Discount future sums to understand their real current purchasing power.",
    inputs: [
      { id: "future_value", label: "Future Expected Value", type: "slider", default: 50000, prefix: "$", min: 100, max: 1000000, step: 1000 },
      { id: "rate", label: "Annual Discount Inflation (%)", type: "slider", default: 7, suffix: "%", min: 1, max: 100, step: 0.5 },
      { id: "years", label: "Accumulation Years", type: "slider", default: 10, suffix: " Yrs", min: 1, max: 40, step: 1 }
    ],
    formula: "future_value / pow(1 + rate/100, years)",
    output_label: "Current Purchasing Value Equivalent",
    output_prefix: "$",
    chart_type: "line",
    insight: "A dollar today is worth more than a dollar tomorrow. Time value of money is the foundational law of finance."
  },
  "future_value": {
    tool_type: "investment",
    title: "Future Value Outlook",
    description: "Examine final valuations of single-sum balances left compounding.",
    inputs: [
      { id: "present_val", label: "Current Initial Principal", type: "slider", default: 25000, prefix: "$", min: 100, max: 1000000, step: 1000 },
      { id: "rate", label: "Expected Annual Value Gain (%)", type: "slider", default: 8, suffix: "%", min: 1, max: 40, step: 0.5 },
      { id: "years", label: "Vesting Scope (Years)", type: "slider", default: 12, suffix: " Yrs", min: 1, max: 50, step: 1 }
    ],
    formula: "present_val * pow(1 + rate/100, years)",
    output_label: "Ultimate Future Balance",
    output_prefix: "$",
    chart_type: "line",
    insight: "Maximize your future value by investing early to utilize long, uninterrupted timeline cycles."
  },

  // --- RETIREMENT ---
  "retirement": {
    tool_type: "investment",
    title: "FIRE Freedom Number Planner",
    description: "Determine your ultimate financial independence targets using standard withdrawal guidelines.",
    inputs: [
      { id: "expenses", label: "Projected Annual Living Costs", type: "slider", default: 48000, prefix: "$", min: 5000, max: 500000, step: 1000 }
    ],
    formula: "expenses * 25",
    output_label: "FIRE Financial Target Portfolio Goal (4% Rule)",
    output_prefix: "$",
    chart_type: "none",
    insight: "Accumulating 25 times your annual living expenses allows you to theoretically draw 4% safely forever and retire early."
  },
  "401k": {
    tool_type: "compound_interest",
    title: "401(k) / Pension Plan Growth",
    description: "Visualize retirement cushions amplified by crucial employer-match contributions.",
    inputs: [
      { id: "salary", label: "Current Salary", type: "slider", default: 80000, prefix: "$", min: 10000, max: 500000, step: 2500 },
      { id: "contribution", label: "Your Contribution Rate (%)", type: "slider", default: 6, suffix: "%", min: 1, max: 30, step: 1 },
      { id: "match", label: "Employer Match Limit (%)", type: "slider", default: 3, suffix: "%", min: 0, max: 15, step: 0.5 },
      { id: "years", label: "Horizon Years to Save", type: "slider", default: 20, suffix: " Yrs", min: 1, max: 45, step: 1 }
    ],
    formula: "((salary * (contribution + match) / 100) * (pow(1 + 0.08, years) - 1) / 0.08)",
    output_label: "Estimated 401(k) Final Portfolio (assuming 8% APY)",
    output_prefix: "$",
    chart_type: "line",
    insight: "An employer match represents free capital. Always contribute enough to secure your firm's maximal match."
  },

  // --- HEALTH & METRIC ---
  "bmi": {
    tool_type: "custom",
    title: "Body Mass Index (BMI)",
    description: "Evaluate your weight status category relative to height measurements.",
    inputs: [
      { id: "weight", label: "Body Weight (kg)", type: "slider", default: 75, suffix: " kg", min: 30, max: 200, step: 1 },
      { id: "height", label: "Height (cm)", type: "slider", default: 175, suffix: " cm", min: 100, max: 220, step: 1 }
    ],
    formula: "weight / pow(height / 100, 2)",
    output_label: "Body Mass Index (BMI Value)",
    output_suffix: " BMI",
    chart_type: "gauge",
    insight: "Underweight is beneath 18.5, healthy is 18.5 to 24.9, overweight scales to 29.9, and obesity exceeds 30."
  },
  "calorie": {
    tool_type: "custom",
    title: "Daily Calorie Requirement",
    description: "Estimate daily energy quotas needed to sustain stable target weight ranges.",
    inputs: [
      { id: "weight", label: "Weight (kg)", type: "slider", default: 70, suffix: " kg", min: 30, max: 180, step: 1 },
      { id: "height", label: "Height (cm)", type: "slider", default: 172, suffix: " cm", min: 100, max: 220, step: 1 },
      { id: "age", label: "Age (Years)", type: "slider", default: 28, suffix: " Yrs", min: 10, max: 100, step: 1 }
    ],
    formula: "(10 * weight + 6.25 * height - 5 * age + 5) * 1.375",
    output_label: "Daily Calories Required",
    output_suffix: " kcal/day",
    chart_type: "none",
    insight: "To trigger safe, consistent weight loss, aim for a minor deficit of 300 to 500 calories below maintenance."
  },
  "body_fat": {
    tool_type: "custom",
    title: "US Navy Body Fat Estimator",
    description: "Approximate biological body fat percentages using circumference measurements.",
    inputs: [
      { id: "waist", label: "Waist Circumference (cm)", type: "slider", default: 85, suffix: " cm", min: 40, max: 180, step: 1 },
      { id: "neck", label: "Neck Circumference (cm)", type: "slider", default: 38, suffix: " cm", min: 25, max: 60, step: 1 },
      { id: "height", label: "Height (cm)", type: "slider", default: 178, suffix: " cm", min: 100, max: 220, step: 1 }
    ],
    formula: "495 / (1.0324 - 0.19077 * log(waist - neck) + 0.15456 * log(height)) - 450",
    output_label: "Body Fat Ratio Recommendation",
    output_suffix: "% Fat",
    chart_type: "none",
    insight: "A healthy range is 10% to 20% flat fat for men, and 20% to 30% for women."
  },
  "bmr": {
    tool_type: "custom",
    title: "Basal Metabolic Rate (BMR)",
    description: "Obtain minimum daily caloric needs required for baseline survival at rest.",
    inputs: [
      { id: "weight", label: "Body Mass (kg)", type: "slider", default: 75, suffix: " kg", min: 30, max: 200, step: 1 },
      { id: "height", label: "Stature (cm)", type: "slider", default: 175, suffix: " cm", min: 100, max: 220, step: 1 },
      { id: "age", label: "Age (Years)", type: "slider", default: 25, suffix: " Yrs", min: 12, max: 100, step: 1 }
    ],
    formula: "10 * weight + 6.25 * height - 5 * age + 5",
    output_label: "Basal Metabolic Rate (BMR Base)",
    output_suffix: " kcal/day",
    chart_type: "none",
    insight: "BMR constitutes up to 70% of flat energy burn. Building muscle mass naturally elevates your baseline BMR rate."
  },

  // --- MATHEMATICAL ---
  "percentage": {
    tool_type: "custom",
    title: "General Percentage Wizard",
    description: "Determine percentage rises, contractions, and ratios instantly.",
    inputs: [
      { id: "value", label: "Stated Baseline Value", type: "slider", default: 1500, prefix: "", min: 0, max: 100000, step: 100 },
      { id: "pct", label: "Target Percentage (%)", type: "slider", default: 18, suffix: "%", min: 0.1, max: 500, step: 1 }
    ],
    formula: "value * (pct / 100)",
    output_label: "Calculated Portion",
    output_prefix: "",
    chart_type: "none",
    insight: "Keep this generic tool handy to quickly compute tax portions, discounts, and tips on the go."
  },

  // --- MISC & AMUSEMENT ---
  "date_calculator": {
    tool_type: "date_difference",
    title: "Age & Precise Time Elapse Tracker",
    description: "Calculate the exact elapsed years, months, and days from any birth date or historical milestone relative to today.",
    inputs: [
      { id: "start_day", label: "Day of Birth", type: "slider", default: 15, min: 1, max: 31, step: 1 },
      { id: "start_month", label: "Month of Birth", type: "slider", default: 6, min: 1, max: 12, step: 1 },
      { id: "start_year", label: "Year of Birth", type: "slider", default: 1994, min: 1900, max: 2026, step: 1 }
    ],
    formula: "2026 - start_year",
    output_label: "Exact Time Elapsed / Milestone Duration",
    output_suffix: "",
    chart_type: "none",
    insight: "Live every second with intention. An average lifespan is roughly 28,000 blocks - make each one count!"
  },
  "date": {
    tool_type: "date_difference",
    title: "Age & Precise Time Elapse Tracker",
    description: "Calculate the exact elapsed years, months, and days from any birth date or historical milestone relative to today.",
    inputs: [
      { id: "start_day", label: "Day of Birth", type: "slider", default: 15, min: 1, max: 31, step: 1 },
      { id: "start_month", label: "Month of Birth", type: "slider", default: 6, min: 1, max: 12, step: 1 },
      { id: "start_year", label: "Year of Birth", type: "slider", default: 1994, min: 1900, max: 2026, step: 1 }
    ],
    formula: "2026 - start_year",
    output_label: "Exact Time Elapsed / Milestone Duration",
    output_suffix: "",
    chart_type: "none",
    insight: "Live every second with intention. An average lifespan is roughly 28,000 blocks - make each one count!"
  },
  "age": {
    tool_type: "date_difference",
    title: "Age & Precise Time Elapse Tracker",
    description: "Calculate the exact elapsed years, months, and days from any birth date or historical milestone relative to today.",
    inputs: [
      { id: "start_day", label: "Day of Birth", type: "slider", default: 15, min: 1, max: 31, step: 1 },
      { id: "start_month", label: "Month of Birth", type: "slider", default: 6, min: 1, max: 12, step: 1 },
      { id: "start_year", label: "Year of Birth", type: "slider", default: 1994, min: 1900, max: 2026, step: 1 }
    ],
    formula: "2026 - start_year",
    output_label: "Exact Time Elapsed / Milestone Duration",
    output_suffix: "",
    chart_type: "none",
    insight: "Live every second with intention. An average lifespan is roughly 28,000 blocks - make each one count!"
  },
  "love_calculator": {
    tool_type: "custom",
    title: "Affection Compatibility ❤️",
    description: "Explore relationship parameters using standard sinusoidal algorithms.",
    inputs: [
      { id: "years_known", label: "Duration Known (Years)", type: "slider", default: 2, suffix: " Yrs", min: 0, max: 50, step: 1 },
      { id: "mutual_interests", label: "Mutual Interests Shared", type: "slider", default: 5, suffix: " Interests", min: 0, max: 20, step: 1 }
    ],
    formula: "min(max(Math.floor(Math.sin(mutual_interests * 30 + years_known * 15) * 40 + 70), 10), 100)",
    output_label: "❤️❤️ Affection & Compatibility Score ❤️❤️",
    output_suffix: "% Compatibility",
    chart_type: "none",
    insight: "Real companionship is forged through respect and empathy, surpassing standard mathematical evaluations!"
  },
  "weight_metric_conversion": {
    tool_type: "boy_kilo",
    title: "Weight & Metric Conversion Calculator",
    description: "Convert height & weight between Metric and Imperial instantly, showing real-time BMI classification comparison.",
    inputs: [
      { id: "weight_kg", label: "Kilo / Weight (kg)", type: "slider", default: 70, suffix: " kg", min: 0, max: 130, step: 1 },
      { id: "height_cm", label: "Boy / Height (cm)", type: "slider", default: 175, suffix: " cm", min: 0, max: 210, step: 1 }
    ],
    formula: "height_cm === 0 ? 0 : weight_kg / pow(height_cm / 100, 2)",
    output_label: "Body Mass Index (BMI)",
    output_suffix: " BMI",
    chart_type: "none",
    insight: "Healthy BMI category is between 18.5 and 24.9. Adjust sliders to see equivalents in pounds (lbs) and inches (in) instantly."
  }
};

// Formats or bounds values safely for user inputs, checking 0 to 10000 range visually
export function generateGenericCalculator(name: string): CalculatorTool {
  let norm = name.toLowerCase().trim();
  if (norm.includes("boy") || norm.includes("kilo") || norm.includes("boy-kilo") || norm.includes("boy_kilo") || norm.includes("vücut kitle") || norm.includes("bmi") || norm.includes("boy ve kilo")) {
    norm = "weight & metric conversion";
  }
  
  // 1. Bulletproof exact match lookup with stripped characters to support dots, dashes and spaces (e.g. "Rent vs. Buy" -> "rent_vs_buy")
  const cleanNormKey = norm.replace(/[^a-z0-9]/g, "");
  for (const k of Object.keys(TOOL_DATABASE)) {
    const cleanDbKey = k.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (cleanNormKey === cleanDbKey) {
      const partial = TOOL_DATABASE[k];
      return {
        tool_type: partial.tool_type || "custom",
        title: partial.title || name,
        description: partial.description || `Custom handy tool related to ${name}.`,
        inputs: partial.inputs || [
          { id: "input_a", label: "Primary Parameter", type: "slider", default: 500, min: 0, max: 10000, step: 50 },
          { id: "input_b", label: "Secondary Parameter", type: "slider", default: 10, min: 0, max: 200, step: 1 }
        ],
        formula: partial.formula || "input_a * (input_b / 100)",
        output_label: partial.output_label || "Analytical Outcome",
        output_prefix: partial.output_prefix || "",
        output_suffix: partial.output_suffix || "",
        chart_type: partial.chart_type || "bar",
        insight: partial.insight || "Calculations process reactively. Edit any field using sliders or manually override numbers."
      };
    }
  }

  // 2. Exact word check fallback to prevent overlapping words (like "age" matching "mortgage")
  for (const k of Object.keys(TOOL_DATABASE)) {
    const cleanWordK = k.toLowerCase().replace(/_/g, " ");
    const cleanWordNorm = norm.replace(/_/g, " ");

    const wordsK = cleanWordK.split(" ");
    const wordsNorm = cleanWordNorm.split(" ");

    const isMatch = wordsK.some(w => wordsNorm.includes(w)) || wordsNorm.some(w => wordsK.includes(w));
    if (isMatch) {
      if (norm === "age" && k !== "age") continue;
      if (norm === "rent" && k !== "rent" && !cleanWordK.split(" ").includes("rent")) continue;

      const partial = TOOL_DATABASE[k];
      return {
        tool_type: partial.tool_type || "custom",
        title: partial.title || name,
        description: partial.description || `Custom handy tool related to ${name}.`,
        inputs: partial.inputs || [
          { id: "input_a", label: "Primary Parameter", type: "slider", default: 500, min: 0, max: 10000, step: 50 },
          { id: "input_b", label: "Secondary Parameter", type: "slider", default: 10, min: 0, max: 200, step: 1 }
        ],
        formula: partial.formula || "input_a * (input_b / 100)",
        output_label: partial.output_label || "Analytical Outcome",
        output_prefix: partial.output_prefix || "",
        output_suffix: partial.output_suffix || "",
        chart_type: partial.chart_type || "bar",
        insight: partial.insight || "Calculations process reactively. Edit any field using sliders or manually override numbers."
      };
    }
  }

  // 3. Smart Generative Custom Definitions based on semantic keywords
  let labelA = "Value A";
  let labelB = "Value B";
  let prefA = "";
  let suffB = "";
  let minA = 0, maxA = 10000;
  let formula = "input_a + input_b";
  let outputLabel = "Aggregate Outcome";
  let chartType: "line" | "bar" | "none" | "gauge" | "comparison" | "distribution" = "bar";

  if (norm.includes("tax") || norm.includes("vergi") || norm.includes("kdv") || norm.includes("vat") || norm.includes("paycheck") || norm.includes("salary") || norm.includes("maaş")) {
    labelA = "Gross Salary / Income Amount";
    labelB = "Tax Rate (%)";
    prefA = "$";
    suffB = "%";
    formula = "input_a * (input_b / 100)";
    outputLabel = "Calculated Tax Deduction Outlay";
    chartType = "bar";
  } else if (norm.includes("fuel") || norm.includes("mileage") || norm.includes("gas") || norm.includes("yakıt") || norm.includes("trip")) {
    labelA = "Total Distance (Miles)";
    labelB = "Fuel Economy (MPG)";
    suffB = " MPG";
    formula = "(input_a / input_b) * 3.5"; // average fuel cost simulation
    outputLabel = "Projected Driving Fuel Cost (Est)";
    prefA = "$";
    chartType = "line";
  } else if (norm.includes("tip") || norm.includes("gratuity") || norm.includes("bahşiş") || norm.includes("commission")) {
    labelA = "Initial Outlay bill ($)";
    labelB = "Fraction / Tip Rate (%)";
    prefA = "$";
    suffB = "%";
    formula = "input_a * (input_b / 100)";
    outputLabel = "Calculated Reward Amount";
    chartType = "bar";
  } else if (norm.includes("scientific") || norm.includes("math") || norm.includes("percent") || norm.includes("percentage") || norm.includes("fraction") || norm.includes("exponent") || norm.includes("ratio")) {
    labelA = "Stated Base (X)";
    labelB = "Scope Variable (Y)";
    formula = "input_a * (input_b / 100)";
    outputLabel = "X Calculated Relative to Y%";
    maxA = 1000;
    chartType = "bar";
  } else if (norm.includes("bmi") || norm.includes("body") || norm.includes("fat") || norm.includes("health") || norm.includes("calorie") || norm.includes("bmr") || norm.includes("macro") || norm.includes("weight") || norm.includes("ideal")) {
    labelA = "Weight of Person (kg)";
    labelB = "Height of Person (cm)";
    formula = "input_a / pow(input_b / 100, 2)";
    outputLabel = "Body Mass Index (BMI)";
    chartType = "gauge";
  } else if (norm.includes("love") || norm.includes("relationship") || norm.includes("fun") || norm.includes("compatibility") || norm.includes("dice")) {
    labelA = "Mutual Interests Shared";
    labelB = "Years Known / Acquainted";
    formula = "min(max(Math.floor(Math.sin(input_a * 35 + input_b * 12) * 35 + 65), 10), 100)";
    outputLabel = "Calculated Affinity Score (%)";
    chartType = "gauge";
    suffB = " Years";
  } else if (norm.includes("loan") || norm.includes("mortgage") || norm.includes("car") || norm.includes("interest") || norm.includes("repayment") || norm.includes("debt")) {
    labelA = "Principal Capital Amount";
    labelB = "Interest Rate (%)";
    prefA = "$";
    suffB = "%";
    formula = "input_a * (input_b / 100) / 12";
    outputLabel = "Initial Monthly Accruing Interest Portion";
    chartType = "line";
  } else if (norm.includes("sleep") || norm.includes("hour") || norm.includes("time") || norm.includes("clock")) {
    labelA = "Average Slumber Duration";
    labelB = "Weekly Recur Cycle (Days)";
    formula = "input_a * input_b";
    outputLabel = "Aggregated Weekly Sleep Hours";
    suffB = " Days";
    chartType = "bar";
  } else {
    // Default generic beautifully designed custom parameters
    labelA = `${name} Primary Metric`;
    labelB = "Coefficient / Multiplier (%)";
    formula = "input_a * (input_b / 100)";
    outputLabel = `Estimated Portfolio of ${name}`;
    prefA = "";
    suffB = "%";
    chartType = "bar";
  }

  return {
    tool_type: "custom",
    title: `${name.charAt(0).toUpperCase() + name.slice(1)} Calculator`,
    description: `Perform easy, instant calculations regarding ${name} with real-time reactive charting.`,
    inputs: [
      { id: "input_a", label: labelA, type: "slider", default: 1000, prefix: prefA, min: minA, max: maxA, step: maxA/100 },
      { id: "input_b", label: labelB, type: "slider", default: 20, suffix: suffB, min: 0, max: 100, step: 1 }
    ],
    formula: formula,
    output_label: outputLabel,
    output_prefix: prefA,
    chart_type: chartType,
    insight: "Calculations process reactively. Drag sliders or change values to instantly plot visual charts."
  };
}
