import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Initialize Gemini if key exists
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const defaultPlaceholder = "AIzaSyBgJLNUzf0hd7DdK7oa0SKxqNl0KoJNlc8";
    const userKey = "AQ.Ab8RN6JsGXqV7eey29BVTM57WzdaijKL68H4szL4ceRzpbEOKg";
    let key = process.env.GEMINI_API_KEY;
    if (!key || key === defaultPlaceholder) {
      key = userKey;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

async function tryAimlApiCall(query: string, systemPrompt: string): Promise<any> {
  const apiKey = "808e1f20c31e4d74e4bc52d057fcb768";
  const modelName = "meta-llama/llama-3-70b-instruct";
  
  const response = await fetch("https://api.aimlapi.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: modelName,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Query: ${query}` }
      ],
      temperature: 0.1,
      max_tokens: 1000
    })
  });
  
  if (!response.ok) {
    throw new Error(`AIML API error status: ${response.status}`);
  }
  
  const data = await response.json();
  const text = data.choices?.[0]?.message?.content || "";
  let jsonStr = text.trim();
  if (jsonStr.includes("```json")) {
    jsonStr = jsonStr.split("```json")[1].split("```")[0].trim();
  } else if (jsonStr.includes("```")) {
    jsonStr = jsonStr.split("```")[1].split("```")[0].trim();
  }
  
  return JSON.parse(jsonStr);
}

const app = express();
const PORT = 3000;

app.use(express.json());

// API route first
app.post("/api/parse-query", async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== "string") {
    return res.status(400).json({ error: "Missing or invalid query parameter" });
  }

  // System instruction / prompt details
  const systemPrompt = `You are a financial calculator engine. The user will ask a financial question or describe a dynamic financial calculation tool.

CRITICAL INSTRUCTIONS:
1. MATCH QUERY LANGUAGE: If the user query is in Turkish (e.g., "temel giderler", "altın borcu", "kalan kira"), you MUST respond in premium, natural, professional Turkish for all human-visible fields: 'title', 'description', 'label' in each input, 'output_label', and 'insight'. If the query is in English, respond in English.
2. MULTI-INPUT DETAILED RELEVANCE: Avoid lazy generic "amount" and "rate" inputs. Generate highly specific, practical, multiple inputs that let the user enter exact variables.
   - For example, if they search "temel giderler" (basic expenses), generate separate input fields for Rent ('kira'), Bills/Invoices ('faturalar'), Groceries ('gida'), Transportation ('ulasim'), and Other ('diger'). Use these IDs in the formula, e.g., "kira + faturalar + gida + ulasim + diger".
   - If they search "altın borcu" (gold debt), generate 'altin_gram' (Gram amount) and 'gram_fiyati' (Price per gram), then formula: "altin_gram * gram_fiyati".
   - If they search "rent tracker" or "kalan kira", generate 'monthly_rent' and 'remaining_months', formula: "monthly_rent * remaining_months".
3. DEFAULT RANGES: For input type "slider" or "number", specify wise 'min', 'max', 'step', and 'default' values. For currency in Turkish, use "₺" as prefix. For gold gram, use "g" as suffix.
4. VALID MATH FORMULAS: Keep formula strings simple and clean math expressions. Only use variables declared in 'inputs'. E.g., 'rent + faturalar + gida' or 'altin_gram * gram_fiyati'.
5. MATCHING RESPONSE STRUCTURE:
{
  "tool_type": "compound_interest" | "debt_payoff" | "mortgage" | "budget" | "salary" | "investment" | "custom",
  "title": "Tool title",
  "description": "One line description",
  "inputs": [
    { 
      "id": "field_id", 
      "label": "Input Label", 
      "type": "number" | "select" | "slider", 
      "default": value, 
      "min": value, 
      "max": value, 
      "step": value, 
      "prefix": "₺|$|%|", 
      "suffix": "yr|mo|g|",
      "options": ["opt1","opt2"] (only if type is select) 
    }
  ],
  "formula": "javascript formula using input ids as variables",
  "output_label": "Result label",
  "output_prefix": "₺|$|%|",
  "chart_type": "line|bar|none|gauge|comparison|distribution",
  "insight": "A helpful insight about the result"
}`;

  // 1. Try Anthropic if key exists
  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-5-sonnet-20241022", // Use standard Sonnet as modern fallbacks instead of old identifiers
          max_tokens: 1000,
          system: systemPrompt,
          messages: [{ role: "user", content: query }],
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.content?.[0]?.text || "";
        // Extract JSON block if enclosed in markdown
        let jsonStr = text.trim();
        if (jsonStr.includes("```json")) {
          jsonStr = jsonStr.split("```json")[1].split("```")[0].trim();
        } else if (jsonStr.includes("```")) {
          jsonStr = jsonStr.split("```")[1].split("```")[0].trim();
        }
        const parsed = JSON.parse(jsonStr);
        return res.json(parsed);
      } else {
        const errText = await response.text();
        console.warn("Anthropic API returned error, falling back to Gemini:", errText);
      }
    } catch (err) {
      console.error("Failed call to Anthropic, falling back to Gemini:", err);
    }
  }

  // 2. Defaulting to Gemini with schema enforcement
  try {
    const ai = getGeminiClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Query: ${query}`,
      config: {
        systemInstruction: systemPrompt + "\nGenerate realistic, useful default inputs and prefixes/suffixes relevant to the user query.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tool_type: {
              type: Type.STRING,
              enum: ["compound_interest", "debt_payoff", "mortgage", "budget", "salary", "investment", "custom"],
            },
            title: { type: Type.STRING },
            description: { type: Type.STRING },
            inputs: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  label: { type: Type.STRING },
                  type: { type: Type.STRING, enum: ["number", "select", "slider"] },
                  default: { type: Type.NUMBER },
                  prefix: { type: Type.STRING },
                  suffix: { type: Type.STRING },
                  options: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                  },
                },
                required: ["id", "label", "type", "default"],
              },
            },
            formula: { type: Type.STRING },
            output_label: { type: Type.STRING },
            output_prefix: { type: Type.STRING },
            chart_type: { type: Type.STRING, enum: ["line", "bar", "none", "gauge", "comparison", "distribution"] },
            insight: { type: Type.STRING },
          },
          required: [
            "tool_type",
            "title",
            "description",
            "inputs",
            "formula",
            "output_label",
            "chart_type",
            "insight",
          ],
        },
      },
    });

    if (response.text) {
      const parsed = JSON.parse(response.text.trim());
      return res.json(parsed);
    } else {
      throw new Error("Empty text returned from Gemini API");
    }
  } catch (err: any) {
    console.warn("Gemini API Error, falling back to AIML API:", err);
    try {
      const parsed = await tryAimlApiCall(query, systemPrompt);
      if (parsed) {
        return res.json(parsed);
      }
    } catch (aimlErr) {
      console.error("AIML API Fallback failed:", aimlErr);
    }

    // Dynamic heuristic fallback generator to ensure a valid customized tool is ALWAYS returned
    console.log("Both AI models failed or keys not ready. Generating customized tool via server-side pattern match database...");
    const q = query.toLowerCase().trim();
    
    // Default config values
    let tool_type = "custom";
    let title = `${query.charAt(0).toUpperCase() + query.slice(1)} Calculator`;
    let description = `Interactive custom utility dynamically generated around "${query}"`;
    let inputs: any[] = [
      { id: "amount", label: "Amount / Value", type: "slider", default: 1000, prefix: "$", min: 10, max: 500000, step: 10 },
      { id: "rate", label: "Annual Rate / Factor (%)", type: "slider", default: 8, suffix: "%", min: 1, max: 100, step: 0.1 }
    ];
    let formula = "amount * (rate / 100)";
    let output_label = "Calculated Value Outcome";
    let output_prefix = "$";
    let chart_type = "line";
    let insight = "Regular automated planning is the key to mastering your targeted metric successfully.";

    if (q.includes("temel gider") || q.includes("giderler") || q.includes("gider") || q.includes("harcama") || q.includes("masraf") || q.includes("expenses") || q.includes("monthly expenses") || q.includes("fatura")) {
      tool_type = "custom";
      title = "Aylık Temel Gider & Masraf Takipçisi";
      description = "Kira, faturalar, mutfak ve diğer harcamalarınıza göre kalan aylık tasarrufunuzu görün.";
      inputs = [
        { id: "aylik_gelir", label: "Aylık Net Gelir (TL)", type: "number", default: 35000, prefix: "₺" },
        { id: "kira", label: "Kira Gideri", type: "number", default: 12000, prefix: "₺" },
        { id: "faturalar", label: "Faturalar ve Aidatlar", type: "number", default: 3000, prefix: "₺" },
        { id: "gida", label: "Mutfak / Gıda Harcaması", type: "number", default: 5000, prefix: "₺" },
        { id: "ulasim", label: "Ulaşım ve Yakıt", type: "number", default: 2000, prefix: "₺" },
        { id: "diger", label: "Diğer Masraflar", type: "number", default: 3000, prefix: "₺" }
      ];
      formula = "aylik_gelir - (kira + faturalar + gida + ulasim + diger)";
      output_label = "Kalan Aylık Net Birikim / Tasarruf";
      output_prefix = "₺";
      chart_type = "none";
      insight = "Giderlerinizi gelirinize oranlayarak tasarruf miktarınızı artırmak, finansal özgürlüğün en temel adımıdır.";
    } else if (q.includes("altin") || q.includes("altın") || q.includes("gold") || q.includes("bilezik") || q.includes("çeyrek")) {
      tool_type = "custom";
      title = "Altın Borcu ve TL Karşılığı Hesaplayıcı";
      description = "Borç aldığınız veya biriktirdiğiniz altın miktarını ve anlık gram altın fiyatını girerek toplam TL karşılığını görün.";
      inputs = [
        { id: "altin_gram", label: "Altın Miktarı (Gram)", type: "slider", default: 10, min: 1, max: 1000, step: 1, suffix: " g" },
        { id: "gram_fiyati", label: "Güncel Gram Altın Fiyatı (TL)", type: "slider", default: 2500, min: 500, max: 5000, step: 10, prefix: "₺" }
      ];
      formula = "altin_gram * gram_fiyati";
      output_label = "Toplam Altın Borcu TL Değeri";
      output_prefix = "₺";
      chart_type = "gauge";
      insight = "Altın borcu piyasa dalgalanmalarına duyarlıdır. Güncel gram altın fiyatını düzenli güncelleyerek anlık takibi yapabilirsiniz.";
    } else if (q.includes("kalan kira") || q.includes("kira borcu") || q.includes("kira takibi") || q.includes("rent leftover")) {
      tool_type = "custom";
      title = "Sözleşmeli Kalan Kira Borcu Takibi";
      description = "Aylık kira bedelinizi ve sözleşme sonuna kadar kalan ödenmemiş ay sayısını girerek toplam borcunuzu hesaplayın.";
      inputs = [
        { id: "aylik_kira", label: "Aylık Kira Bedeli", type: "number", default: 15000, prefix: "₺" },
        { id: "kalan_ay", label: "Kalan Ödenecek Ay Sayısı", type: "slider", default: 6, min: 1, max: 24, step: 1, suffix: " Ay" }
      ];
      formula = "aylik_kira * kalan_ay";
      output_label = "Gelecek Toplam Kira Borcu Yükümlülüğü";
      output_prefix = "₺";
      chart_type = "none";
      insight = "Gelecek nakit akışınızı doğru planlamak ve kira ödemelerini önceden güvence altına almak için mükemmel bir araçtır.";
    } else if (q.includes("bmi") || q.includes("boy") || q.includes("kilo") || q.includes("weight") || q.includes("height") || q.includes("vücut")) {
      tool_type = "custom";
      title = "Body Mass Index & Weight Bracket Evaluator";
      description = "Evaluate body mass ratios and find associated weight brackets instantly.";
      inputs = [
        { id: "weight", label: "Weight (kg)", type: "slider", default: 70, min: 20, max: 200, step: 1 },
        { id: "height", label: "Height (cm)", type: "slider", default: 175, min: 100, max: 240, step: 1 }
      ];
      formula = "weight / pow(height / 100, 2)";
      output_label = "Calculated Body Mass Index (BMI)";
      output_prefix = "";
      chart_type = "none";
      insight = "Healthy BMI brackets fall between 18.5 and 24.9. Proper diet and exercises keep this metric stable.";
    } else if (q.includes("compound") || q.includes("interest") || q.includes("faiz") || q.includes("bileşik") || q.includes("birikim") || q.includes("savings") || q.includes("invest")) {
      tool_type = "compound_interest";
      title = "Dynamic Investment Compounding Planner";
      description = "Simulate capital compounds across compound interest matrices over time.";
      inputs = [
        { id: "principal", label: "Starting Capital", type: "slider", default: 5000, prefix: "$", min: 100, max: 250000, step: 500 },
        { id: "rate", label: "Annual Compound Rate (%)", type: "slider", default: 10, suffix: "%", min: 0.5, max: 100, step: 0.5 },
        { id: "years", label: "Repayment Period (Years)", type: "slider", default: 10, suffix: " yrs", min: 1, max: 40, step: 1 },
        { id: "monthly", label: "Monthly Deposit Increment", type: "slider", default: 200, prefix: "$", min: 0, max: 10000, step: 50 }
      ];
      formula = "principal * pow(1 + (rate/100)/12, years * 12) + (rate === 0 ? monthly * years * 12 : monthly * (pow(1 + (rate/100)/12, years * 12) - 1) / ((rate/100)/12) * (1 + (rate/100)/12))";
      output_label = "Estimated Cumulative Worth Portfolio";
      output_prefix = "$";
      chart_type = "line";
      insight = "Consistency beats timing. Continuous auto-deposits generate spectacular compound returns over decades.";
    } else if (q.includes("borç") || q.includes("debt") || q.includes("payoff") || q.includes("kredi") || q.includes("cc") || q.includes("apr")) {
      tool_type = "debt_payoff";
      title = "Debt Paydown Strategic Scheduler";
      description = "Shatter rotating liabilities and accelerate your path to debt freedom.";
      inputs = [
        { id: "balance", label: "Current Balance", type: "slider", default: 10000, prefix: "$", min: 100, max: 100000, step: 500 },
        { id: "apr", label: "Card/Loan Interest APR (%)", type: "slider", default: 18, suffix: "%", min: 1, max: 80, step: 0.5 },
        { id: "payment", label: "Proposed Monthly Payment", type: "slider", default: 350, prefix: "$", min: 20, max: 10000, step: 10 }
      ];
      formula = "round(log(payment / (payment - balance * (apr / 100 / 12))) / log(1 + (apr / 100 / 12)))";
      output_label = "Months to Reach Complete Freedom";
      output_prefix = "";
      chart_type = "none";
      insight = "Squeezing extra monthly dollars above the minimum payoff shortens the payment lifespan dramatically.";
    } else if (q.includes("bütçe") || q.includes("budget") || q.includes("splitter") || q.includes("salary") || q.includes("take home") || q.includes("maaş")) {
      tool_type = "budget";
      title = "Salary Net Take-Home & 50/30/20 Budgeting Rules";
      description = "Split your monthly earnings into Needs, Wants, and Savings automatically.";
      inputs = [
        { id: "income", label: "Your Net Income", type: "slider", default: 5000, prefix: "$", min: 500, max: 50000, step: 100 }
      ];
      formula = "income";
      output_label = "Disposable Net Income";
      output_prefix = "$";
      chart_type = "none";
      insight = "The 50/30/20 guideline suggests allocating 50% for vital needs, 30% for styling/wants, and 20% for continuous saving.";
    }

    return res.json({
      tool_type,
      title,
      description,
      inputs,
      formula,
      output_label,
      output_prefix,
      chart_type,
      insight
    });
  }
});

// Serve frontend assets and hook dev environment
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`wlth.app server running on port ${PORT}`);
  });
}

start();
