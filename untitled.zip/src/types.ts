export type ToolType =
  | "compound_interest"
  | "debt_payoff"
  | "mortgage"
  | "budget"
  | "salary"
  | "investment"
  | "age"
  | "macronutrient"
  | "date_difference"
  | "freelancer_allocator"
  | "freelancer_wealth_multiplying_tracker"
  | "boy_kilo"
  | "loan_calculator"
  | "custom";

export interface CalculatorInput {
  id: string;
  label: string;
  type: "number" | "select" | "slider";
  default: number | string;
  prefix?: string;
  suffix?: string;
  options?: string[];
  min?: number;
  max?: number;
  step?: number;
}

export interface CalculatorTool {
  id?: string;
  tool_type: ToolType;
  title: string;
  description: string;
  inputs: CalculatorInput[];
  formula: string;
  output_label: string;
  output_prefix?: string;
  output_suffix?: string;
  chart_type: "line" | "bar" | "none" | "gauge" | "comparison" | "distribution" | "countdown";
  insight: string;
}

export interface ProjectionData {
  label: string;
  value: number;
  secondaryValue?: number; // e.g. principal vs interest paid, category portions
  secondaryLabel?: string;
}
