import { CalculatorTool } from "../types";

export const PREDEFINED_CALCULATORS: CalculatorTool[] = [
  {
    tool_type: "mortgage",
    title: "Comprehensive Mortgage & Cost Analyzer",
    description: "Analyze monthly mortgage payments, property taxes, home insurance premiums, and lifetime amortization breakdowns.",
    inputs: [
      {
        id: "price",
        label: "Home Price",
        type: "slider",
        default: 400000,
        prefix: "$",
        min: 50000,
        max: 2000000,
        step: 5000
      },
      {
        id: "down",
        label: "Down Payment",
        type: "slider",
        default: 20,
        suffix: "%",
        min: 0,
        max: 80,
        step: 1
      },
      {
        id: "years",
        label: "Loan Term",
        type: "slider",
        default: 30,
        suffix: " years",
        min: 5,
        max: 40,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Rate",
        type: "slider",
        default: 6.576,
        suffix: "%",
        min: 0.1,
        max: 20,
        step: 0.001
      },
      {
        id: "include_costs",
        label: "Include Taxes & Costs Below",
        type: "slider",
        default: 0, // Starts off / closed
        min: 0,
        max: 1,
        step: 1,
        suffix: ""
      },
      {
        id: "property_taxes",
        label: "Property Taxes",
        type: "slider",
        default: 1.2,
        suffix: "%",
        min: 0,
        max: 5,
        step: 0.05
      },
      {
        id: "home_insurance",
        label: "Home Insurance (Annual)",
        type: "slider",
        default: 1500,
        prefix: "$",
        min: 0,
        max: 10000,
        step: 100
      },
      {
        id: "pmi_insurance",
        label: "PMI Insurance (Annual)",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 5000,
        step: 50
      },
      {
        id: "hoa_fee",
        label: "HOA Fee (Monthly)",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 2000,
        step: 10
      },
      {
        id: "other_costs",
        label: "Other Costs (Annual)",
        type: "slider",
        default: 4000,
        prefix: "$",
        min: 0,
        max: 20000,
        step: 100
      }
    ],
    formula: "price * (1 - down / 100) * ((rate/100/12) * pow(1 + (rate/100/12), years * 12)) / (pow(1 + (rate/100/12), years * 12) - 1)",
    output_label: "Estimated Monthly Principal & Interest Payment",
    output_prefix: "$",
    chart_type: "distribution", // Defaults to dynamic Donut Chart breakdown!
    insight: "Your property tax, home insurance, and recurring expenses add up to your total out-of-pocket obligation. Consider making a 20% down payment to avoid extra borrowing costs."
  },
  {
    tool_type: "budget", // Matches budget layout or custom loss tracking
    id: "loss_tracker",
    title: "Daily Loss & Recurring Cumulative Tracker",
    description: "Analyze daily financial leaks or trading losses and visualize cumulative impacts over weeks, months, and years in a single unified donut view.",
    inputs: [
      {
        id: "daily_loss",
        label: "Daily Financial Loss / Leakage",
        type: "slider",
        default: 400,
        prefix: "$",
        min: 1,
        max: 10000,
        step: 10
      },
      {
        id: "active_days",
        label: "Trading/Loss Days per Year",
        type: "slider",
        default: 365,
        suffix: " days",
        min: 1,
        max: 365,
        step: 1
      },
      {
        id: "other_loss",
        label: "Other Monthly Leakages",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 5000,
        step: 50
      }
    ],
    formula: "daily_loss * 30 + other_loss",
    output_label: "Total Collective Monthly Leakage",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Evaluating daily financial drains helps identify recurring leaks. Compounding daily losses over a year uncovers the substantial long-term cumulative impact."
  },
  {
    id: "amortized_loan",
    tool_type: "loan_calculator",
    title: "Amortized Loan",
    description: "Calculate basic calculations of common loan types, such as mortgages, auto loans, student loans, and view amortization for each.",
    inputs: [
      {
        id: "loan_amount",
        label: "Loan Amount",
        type: "slider",
        default: 100000,
        prefix: "$",
        min: 1000,
        max: 1000000,
        step: 5000
      },
      {
        id: "years",
        label: "Loan Term (Years)",
        type: "slider",
        default: 10,
        suffix: " years",
        min: 1,
        max: 40,
        step: 1
      },
      {
        id: "months",
        label: "Loan Term (Months)",
        type: "slider",
        default: 0,
        suffix: " months",
        min: 0,
        max: 11,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Rate",
        type: "slider",
        default: 6,
        suffix: "%",
        min: 0.1,
        max: 30,
        step: 0.1
      },
      {
        id: "compound",
        label: "Compound",
        type: "select",
        default: "Monthly (APR)",
        options: ["Monthly (APR)", "Annually (APY)"]
      },
      {
        id: "pay_back",
        label: "Pay Back",
        type: "select",
        default: "Every Month",
        options: ["Every Month", "Every Year"]
      }
    ],
    formula: "loan_amount * ((rate/100/12) * pow(1 + (rate/100/12), (years * 12) + months)) / (pow(1 + (rate/100/12), (years * 12) + months) - 1)",
    output_label: "Payment Every Month",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Amortized loans require regular payments over time that cover both principal and accruing interest, steadily reducing your outstanding debt."
  },
  {
    id: "deferred_loan",
    tool_type: "loan_calculator",
    title: "Deferred Payment Loan",
    description: "Paying Back a Lump Sum Due at Maturity. No periodic payments are made until the loan term fully completes.",
    inputs: [
      {
        id: "loan_amount",
        label: "Loan Amount",
        type: "slider",
        default: 100000,
        prefix: "$",
        min: 1000,
        max: 1000000,
        step: 5000
      },
      {
        id: "years",
        label: "Loan Term (Years)",
        type: "slider",
        default: 10,
        suffix: " years",
        min: 1,
        max: 40,
        step: 1
      },
      {
        id: "months",
        label: "Loan Term (Months)",
        type: "slider",
        default: 0,
        suffix: " months",
        min: 0,
        max: 11,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Rate",
        type: "slider",
        default: 6,
        suffix: "%",
        min: 0.1,
        max: 30,
        step: 0.1
      },
      {
        id: "compound",
        label: "Compound",
        type: "select",
        default: "Annually (APY)",
        options: ["Annually (APY)", "Monthly (APR)"]
      }
    ],
    formula: "loan_amount * pow(1 + (rate/100), (years * 12 + months) / 12)",
    output_label: "Amount Due at Loan Maturity",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "Deferred payment loans do not require interim payments, but interest compounds silently, culminating in a larger lump-sum repayment obligation at maturity."
  },
  {
    id: "bond_loan",
    tool_type: "loan_calculator",
    title: "Bond Calculator",
    description: "Paying Back a Predetermined Amount Due at Loan Maturity. Determine starting cash yields based on present value discounting.",
    inputs: [
      {
        id: "predetermined_amount",
        label: "Predetermined Due Amount (Face Value)",
        type: "slider",
        default: 100000,
        prefix: "$",
        min: 1000,
        max: 1000000,
        step: 5000
      },
      {
        id: "years",
        label: "Loan Term (Years)",
        type: "slider",
        default: 10,
        suffix: " years",
        min: 1,
        max: 40,
        step: 1
      },
      {
        id: "months",
        label: "Loan Term (Months)",
        type: "slider",
        default: 0,
        suffix: " months",
        min: 0,
        max: 11,
        step: 1
      },
      {
        id: "rate",
        label: "Interest Rate",
        type: "slider",
        default: 6,
        suffix: "%",
        min: 0.1,
        max: 30,
        step: 0.1
      },
      {
        id: "compound",
        label: "Compound",
        type: "select",
        default: "Annually (APY)",
        options: ["Annually (APY)", "Monthly (APR)"]
      }
    ],
    formula: "predetermined_amount / pow(1 + (rate/100), (years * 12 + months) / 12)",
    output_label: "Amount Received When Loan Starts",
    output_prefix: "$",
    chart_type: "distribution",
    insight: "A bond's present value represents the total discounted cash proceeds received upfront, reflecting the time value of money."
  },
  {
    id: "interest_calculator",
    tool_type: "compound_interest",
    title: "Interest Calculator",
    description: "Calculate compound interest for an initial investment, annual contributions, and monthly contributions with custom compound frequency, inflation, and tax adjustments.",
    inputs: [
      {
        id: "initial_investment",
        label: "Initial Investment",
        type: "slider",
        default: 20000,
        prefix: "$",
        min: 0,
        max: 1000000,
        step: 1000
      },
      {
        id: "annual_contribution",
        label: "Annual Contribution",
        type: "slider",
        default: 5000,
        prefix: "$",
        min: 0,
        max: 100000,
        step: 1000
      },
      {
        id: "monthly_contribution",
        label: "Monthly Contribution",
        type: "slider",
        default: 0,
        prefix: "$",
        min: 0,
        max: 50000,
        step: 100
      },
      {
        id: "contribution_timing",
        label: "Contribution Timing",
        type: "select",
        default: "Beginning of period",
        options: ["Beginning of period", "End of period"]
      },
      {
        id: "interest_rate",
        label: "Interest Rate",
        type: "slider",
        default: 5.0,
        suffix: "%",
        min: 0,
        max: 100,
        step: 0.1
      },
      {
        id: "compound_frequency",
        label: "Compound Frequency",
        type: "select",
        default: "Annually",
        options: ["Daily", "Monthly", "Quarterly", "Semi-annually", "Annually"]
      },
      {
        id: "years",
        label: "Years",
        type: "slider",
        default: 5,
        suffix: " years",
        min: 1,
        max: 100,
        step: 1
      },
      {
        id: "months",
        label: "Months",
        type: "slider",
        default: 0,
        suffix: " months",
        min: 0,
        max: 11,
        step: 1
      },
      {
        id: "tax_rate",
        label: "Tax Rate",
        type: "slider",
        default: 0,
        suffix: "%",
        min: 0,
        max: 100,
        step: 0.1
      },
      {
        id: "inflation_rate",
        label: "Inflation Rate",
        type: "slider",
        default: 3.0,
        suffix: "%",
        min: 0,
        max: 100,
        step: 0.1
      }
    ],
    formula: "initial_investment * pow(1 + (interest_rate*(1 - tax_rate/100)/100)/1, years)",
    output_label: "Ending Interest Balance",
    output_prefix: "$",
    chart_type: "line",
    insight: "The dynamic interplay of compounding frequency, continuous monthly and annual contributions, and inflation can dramatically shape your purchasing power over time."
  }
];

export function findMatchingPredefinedCalculator(query: string): CalculatorTool | null {
  const q = query.toLowerCase().trim();
  if (!q) return null;

  // Detect compound interest / investment
  if (
    q.includes("interest") ||
    q.includes("compound") ||
    q.includes("invest") ||
    q.includes("saving") ||
    q.includes("deposit") ||
    q.includes("faiz") ||
    q.includes("birikim") ||
    q.includes("yatirim") ||
    q.includes("vadeli")
  ) {
    return PREDEFINED_CALCULATORS[5];
  }

  // Detect loss / leakage / spending questions
  if (
    q.includes("lose") ||
    q.includes("lost") ||
    q.includes("spend") ||
    q.includes("cost") ||
    q.includes("waste") ||
    q.includes("leak") ||
    q.includes("kayıp") ||
    q.includes("kayip") ||
    q.includes("zarar") ||
    q.includes("harcama") ||
    q.includes("gider")
  ) {
    // Try to extract numerical values from the prompt to inject custom starting default values
    const numMatch = q.match(/\b\d+(\.\d+)?\b/);
    if (numMatch) {
      const parsedVal = Number(numMatch[0]);
      if (parsedVal > 0) {
        // We override the default input value of daily_loss inside PREDEFINED_CALCULATORS[1] dynamically
        PREDEFINED_CALCULATORS[1].inputs[0].default = parsedVal;
      }
    }
    return PREDEFINED_CALCULATORS[1];
  }

  // Detect specific loan subclasses
  if (q.includes("deferred") || q.includes("maturity") || q.includes("lump sum")) {
    return PREDEFINED_CALCULATORS[3];
  }
  if (q.includes("bond") || q.includes("discount note") || q.includes("predetermined")) {
    return PREDEFINED_CALCULATORS[4];
  }
  if (q.includes("amortized") || q.includes("amortization loan")) {
    return PREDEFINED_CALCULATORS[2];
  }

  // Detect mortgage / home / property calculations
  if (
    q.includes("mortgage") ||
    q.includes("home") ||
    q.includes("house") ||
    q.includes("property") ||
    q.includes("loan") ||
    q.includes("ev") ||
    q.includes("konut") ||
    q.includes("kredi") ||
    q.includes("mülk")
  ) {
    return PREDEFINED_CALCULATORS[0];
  }

  // Default fallback
  return PREDEFINED_CALCULATORS[0];
}
