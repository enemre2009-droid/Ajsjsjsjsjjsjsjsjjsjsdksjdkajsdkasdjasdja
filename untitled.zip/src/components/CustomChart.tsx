import React, { useEffect, useRef, useState } from "react";
import { Download, FileSpreadsheet, Sliders, Info, LineChart, BarChart2, PieChart } from "lucide-react";
import { ProjectionData } from "../types";
import { formatValue } from "../utils";

const BUDGET_EXPLANATIONS: Record<string, string> = {
  // 50/30/20 Budgeting allocations
  "fixed needs": "Essential fixed expenses like home rent, utility bills, core groceries, and primary transit costs.",
  "flexible wants": "Discretionary lifestyle choices such as dining out, personal travel, digital subscriptions, and hobbies.",
  "growth savings": "Automated future preparation, including emergency reserves, structural savings, and investment portfolios.",
  
  // Macronutrients
  "protein grams": "Daily dietary protein requirements essential for lean muscle preservation, cellular repair, and satiety.",
  "carbohydrates grams": "Your body's primary clean energy source for fueling daily routines, physical activities, and workouts.",
  "healthy fats grams": "Vitamins fat-absorption support, clean hormone regulation, and cell health support.",
  
  // Freelancer allocators
  "net owner salary draw": "Your net personal monthly salary draw out of business income, free of any remaining tax burdens.",
  "tax buffer reserves": "A protective tax provision set in reserve to ensure you never run into end-of-year tax surprises.",
  "business overheads & saas": "Necessary monthly operational tools, SaaS subscriptions, hardware amortization, and office overheads.",
  "compound wealth investments": "Future index fund or stock market equities earmarked to generate compound wealth and lasting freedom."
};

interface CustomChartProps {
  data: ProjectionData[];
  chartType: "line" | "bar" | "none" | "gauge" | "comparison" | "distribution" | "countdown";
  theme: "light" | "dark";
  outputPrefix?: string;
  outputSuffix?: string;
}

export default function CustomChart({ 
  data, 
  chartType: rawChartType, 
  theme, 
  outputPrefix = "", 
  outputSuffix = "" 
}: CustomChartProps) {
  // Gracefully normalize chartType to ensure custom calculators always render the designated premium visualizer
  const getNormalizedType = (t: string) => {
    if (!t || t === "none") {
      return "distribution";
    }
    if (["line", "bar", "gauge", "comparison", "distribution", "countdown"].includes(t)) {
      return t as any;
    }
    return "distribution"; // Fallback representation
  };

  const [selectedType, setSelectedType] = useState<"line" | "bar" | "none" | "gauge" | "comparison" | "distribution" | "countdown">(() => {
    return getNormalizedType(rawChartType);
  });

  useEffect(() => {
    if (rawChartType && rawChartType !== "none") {
      setSelectedType(getNormalizedType(rawChartType));
    }
  }, [rawChartType]);

  const chartType = selectedType;

  const containerRef = useRef<HTMLDivElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: 500, height: 260 });
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const [hoveredSlice, setHoveredSlice] = useState<number | null>(null);

  // Interactive Filter States
  const [dataPointsCount, setDataPointsCount] = useState<number>(data.length);
  const [showSecondaryLine, setShowSecondaryLine] = useState<boolean>(true);

  // Sync timeline points count whenever new data is loaded
  useEffect(() => {
    setDataPointsCount(data.length);
  }, [data]);

  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const { width } = entries[0].contentRect;
      setDimensions({
        width: Math.max(width, 280),
        height: 250,
      });
    });
    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  if (rawChartType === "none" || !data || data.length === 0) {
    return null;
  }

  const { width, height } = dimensions;
  const isDark = theme === "dark";

  // COLOR THEME OPTIMIZATION
  const textMuted = isDark ? "text-gray-400" : "text-slate-500";
  const textTitle = isDark ? "text-white" : "text-slate-800";
  const borderCol = isDark ? "border-[#212124]" : "border-slate-200";
  const gridStroke = isDark ? "rgba(209, 213, 219, 0.55)" : "#E2E8F0";
  const labelFill = isDark ? "#A1A1AA" : "#64748B";
  const primaryAccent = isDark ? "#00FF87" : "#10B981"; // Vibrant hypergreen vs clean emerald

  // Apply timeline interactive filters on data array
  const activePointsCount = Math.min(dataPointsCount, data.length) || data.length;
  const filteredData = data.slice(0, activePointsCount);
  
  // Conditionally strip or include secondary metrics inside the dataset based on active filters
  const processedData = filteredData.map(d => ({
    ...d,
    secondaryValue: showSecondaryLine ? d.secondaryValue : undefined
  }));

  // Define canvas spacing variables
  const paddingLeft = 55;
  const paddingRight = 15;
  const paddingTop = 25;
  const paddingBottom = 40;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  // Extract values and calculate optimal high-grade intervals
  const values = processedData.map((d) => d.value);
  const secValues = processedData.map((d) => d.secondaryValue || 0);
  const allValues = [...values, ...(showSecondaryLine ? secValues : [])];
  
  const rawMax = Math.max(...allValues, 10);
  const minVal = 0; 

  // Robust step sizing algorithm for mathematically elegant grid intervals
  const numYGridLines = 4;
  const rawStep = rawMax / numYGridLines;
  const magnitude = Math.pow(10, Math.floor(Math.log10(rawStep || 1)));
  const normalizedStep = rawStep / magnitude;

  // Multiples that split gracefully into 4 intervals
  let roundedNormalizedStep = 1;
  if (normalizedStep <= 1) roundedNormalizedStep = 1;
  else if (normalizedStep <= 1.25) roundedNormalizedStep = 1.25;
  else if (normalizedStep <= 1.5) roundedNormalizedStep = 1.5;
  else if (normalizedStep <= 2) roundedNormalizedStep = 2;
  else if (normalizedStep <= 2.5) roundedNormalizedStep = 2.5;
  else if (normalizedStep <= 3) roundedNormalizedStep = 3;
  else if (normalizedStep <= 4) roundedNormalizedStep = 4;
  else if (normalizedStep <= 5) roundedNormalizedStep = 5;
  else if (normalizedStep <= 6) roundedNormalizedStep = 6;
  else if (normalizedStep <= 7.5) roundedNormalizedStep = 7.5;
  else if (normalizedStep <= 8) roundedNormalizedStep = 8;
  else roundedNormalizedStep = 10;

  const stepSize = roundedNormalizedStep * magnitude;
  const maxVal = stepSize * numYGridLines;

  const getX = (index: number) => {
    if (processedData.length <= 1) return paddingLeft + chartWidth / 2;
    return paddingLeft + (index / (processedData.length - 1)) * chartWidth;
  };

  const getY = (val: number) => {
    const ratio = maxVal === minVal ? 0 : (val - minVal) / (maxVal - minVal);
    return height - paddingBottom - ratio * chartHeight;
  };

  // Safe Blob-based Export to CSV Report
  const downloadCSV = () => {
    try {
      const headers = ["Period Label", "Primary Estimate", "Baseline/Scenario", "Baseline Value"];
      const rows = processedData.map(d => [
        d.label,
        d.value,
        d.secondaryLabel || "Base",
        d.secondaryValue !== undefined ? d.secondaryValue : ""
      ]);
      const csvStr = [
        headers.join(","), 
        ...rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(","))
      ].join("\n");
      
      const blob = new Blob([csvStr], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "wlth_calculations_report.csv";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (e) {
      console.error("CSV Download error:", e);
    }
  };

  // High-Grade vector SVG download
  const downloadSVG = () => {
    if (!svgRef.current) return;
    try {
      const serializer = new XMLSerializer();
      let source = serializer.serializeToString(svgRef.current);
      if (!source.match(/^<svg[^>]+xmlns="http:\/\/www\.w3\.org\/2000\/svg"/)) {
        source = source.replace(/^<svg/, '<svg xmlns="http://www.w3.org/2000/svg"');
      }
      if (!source.match(/^<svg[^>]+xmlns:xlink="http:\/\/www\.w3\.org\/1999\/xlink"/)) {
        source = source.replace(/^<svg/, '<svg xmlns:xlink="http://www.w3.org/1999/xlink"');
      }
      
      // Inject theme background variables so downloaded vector card doesn't appear blank/white
      const bgStyle = isDark ? "background-color: #121214; color: #fff;" : "background-color: #fff; color: #1e1e1e;";
      source = source.replace(/^<svg/, `<svg style="${bgStyle}"`);

      const svgBlob = new Blob([source], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(svgBlob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "wlth_chart_vector.svg";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error("Vector SVG download failed:", err);
    }
  };

  // Vertical line helper
  const handlePointer = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;

    let closestIndex = 0;
    let minDistance = Infinity;

    for (let i = 0; i < processedData.length; i++) {
      const pX = getX(i);
      const dist = Math.abs(x - pX);
      if (dist < minDistance) {
        minDistance = dist;
        closestIndex = i;
      }
    }

    setHoverIndex(closestIndex);
    setTooltipPos({ x: getX(closestIndex), y: getY(processedData[closestIndex].value) });
  };

  const handleLeave = () => {
    setHoverIndex(null);
  };

  const activeNode = hoverIndex !== null ? processedData[hoverIndex] : null;
  const hasAnySecondary = data.some(d => d.secondaryValue !== undefined);
  const isContinuous = chartType === "line" || chartType === "bar";

  // Unified Interactive Filters Header is disabled to keep styling minimal and clean
  const renderControls = () => {
    return null;
  };

  // 1. CHOSEN TYPE: GAUGE CHART (e.g. BMI, Health parameters)
  if (chartType === "gauge") {
    const displayValue = data[0]?.value || 0;
    const minRange = 15;
    const maxRange = 35;
    const clampedVal = Math.min(Math.max(displayValue, minRange), maxRange);
    const pct = (clampedVal - minRange) / (maxRange - minRange);
    
    const cx = width / 2;
    const cy = height - 50;
    const r = Math.min(width * 0.28, 90);

    let category = "Normal Range";
    let categoryColor = "text-emerald-400";
    if (displayValue < 18.5) {
      category = "Underweight";
      categoryColor = "text-emerald-300";
    } else if (displayValue >= 18.5 && displayValue < 25) {
      category = "Healthy Weight";
      categoryColor = "text-emerald-500";
    } else if (displayValue >= 25 && displayValue < 30) {
      category = "Overweight";
      categoryColor = "text-teal-400";
    } else {
      category = "Obese Range";
      categoryColor = "text-emerald-800";
    }

    const needleAngle = Math.PI + pct * Math.PI;
    const needleX = cx + (r - 15) * Math.cos(needleAngle);
    const needleY = cy + (r - 15) * Math.sin(needleAngle);

    return (
      <div className="w-full">
        {renderControls()}
        <div className={`w-full border rounded-3xl p-5 select-none ${isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-sm"}`} ref={containerRef}>
          <div className="flex justify-between items-center mb-4">
            <span className={`text-[11px] font-bold uppercase tracking-wider font-mono ${textMuted}`}>Diagnostic Scale Index Gauge</span>
            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full bg-slate-500/10 ${categoryColor}`}>
              {category}
            </span>
          </div>

          <div className="relative flex flex-col items-center">
            <svg ref={svgRef} width={width} height={height - 20} className="overflow-visible">
              <defs>
                <linearGradient id="gaugeGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#10B981" stopOpacity="0.4" />
                  <stop offset="50%" stopColor="#10B981" />
                  <stop offset="100%" stopColor="#00FF87" />
                </linearGradient>
              </defs>

              <path
                d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
                fill="none"
                stroke={isDark ? "#222" : "#F1F5F9"}
                strokeWidth="22"
                strokeLinecap="round"
              />
              <path
                d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
                fill="none"
                stroke="url(#gaugeGrad)"
                strokeWidth="16"
                strokeLinecap="round"
                opacity="0.85"
              />

              <line x1={cx - r - 2} y1={cy} x2={cx - r + 8} y2={cy} stroke={isDark ? "#555" : "#AAA"} strokeWidth="2" />
              <line x1={cx} y1={cy - r - 2} x2={cx} y2={cy - r + 8} stroke={isDark ? "#555" : "#AAA"} strokeWidth="2" />
              <line x1={cx + r - 8} y1={cy} x2={cx + r + 2} y2={cy} stroke={isDark ? "#555" : "#AAA"} strokeWidth="2" />

              <line
                x1={cx}
                y1={cy}
                x2={needleX}
                y2={needleY}
                stroke={isDark ? "#FFF" : "#1E293B"}
                strokeWidth="4.5"
                strokeLinecap="round"
              />
              
              <circle cx={cx} cy={cy} r="9" fill={isDark ? "#FFF" : "#1E293B"} />
              <circle cx={cx} cy={cy} r="4" fill={primaryAccent} />

              <text x={cx - r - 15} y={cy + 18} textAnchor="middle" fill={labelFill} className="text-[10px] font-mono">15.0</text>
              <text x={cx} y={cy - r - 12} textAnchor="middle" fill={labelFill} className="text-[10px] font-mono">25.0</text>
              <text x={cx + r + 15} y={cy + 18} textAnchor="middle" fill={labelFill} className="text-[10px] font-mono">35.0</text>
            </svg>

            <div className="absolute bottom-6 flex flex-col items-center">
              <span className={`text-4xl font-extrabold tracking-tight font-mono ${textTitle}`}>
                {displayValue.toFixed(1)}
              </span>
              <span className="text-[10px] uppercase tracking-widest font-semibold text-gray-500 font-mono mt-0.5">
                Current Index Value
              </span>
            </div>
          </div>

          {/* Real-time Physical BMI Ruler Slide Measuring Tape */}
          <div className="w-full mt-8 border-t border-dashed border-neutral-200 dark:border-neutral-800 pt-6">
            <div className="flex justify-between items-center mb-3">
              <span className="text-[9px] uppercase font-mono font-bold tracking-widest text-neutral-500">
                Physical Measurement Ruler Scale (BMI Scale Slider)
              </span>
              <span className="text-[10px] font-mono font-bold text-emerald-500 animate-pulse bg-emerald-500/15 px-2 py-0.5 rounded-full">
                Interactive Tape
              </span>
            </div>
            
            <div className="relative w-full pt-6 pb-8 px-1">
              {/* Slidable Indicator Needle pointing to the ruler below */}
              <div 
                className="absolute top-0 flex flex-col items-center -translate-x-1/2 transition-all duration-300 ease-out z-20"
                style={{ left: `${pct * 100}%` }}
              >
                {/* Floating bubble value */}
                <span className={`px-2 py-1 rounded-lg text-[10px] font-mono font-black border tracking-tighter ${
                  displayValue < 18.5 
                    ? "bg-blue-500/10 text-blue-500 border-blue-500/30" 
                    : displayValue < 25 
                      ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/30" 
                      : displayValue < 30 
                        ? "bg-amber-500/10 text-amber-500 border-amber-500/30" 
                        : "bg-rose-500/10 text-rose-500 border-rose-500/30"
                }`}>
                  {displayValue.toFixed(1)}
                </span>
                {/* Small downward triangle pointer */}
                <div className={`w-0 h-0 border-l-[4px] border-r-[4px] border-t-[5px] border-l-transparent border-r-transparent ${
                  displayValue < 18.5 ? "border-t-blue-500" : displayValue < 25 ? "border-t-emerald-500" : displayValue < 30 ? "border-t-amber-500" : "border-t-rose-500"
                } mt-0.5`} />
              </div>

              {/* Ruler colored segments track bar (combines Underweight, Healthy, Overweight, Obese) */}
              <div className="h-4.5 w-full rounded-full flex overflow-hidden shadow-inner relative border border-black/10 dark:border-white/5">
                <div className="bg-blue-500 h-full flex items-center justify-center text-[8px] text-white font-black font-mono tracking-tighter" style={{ width: "17.5%" }}>
                  15-18.5
                </div>
                <div className="bg-emerald-500 h-full flex items-center justify-center text-[8px] text-white font-black font-mono tracking-tighter" style={{ width: "32.5%" }}>
                  18.5-25
                </div>
                <div className="bg-amber-500 h-full flex items-center justify-center text-[8px] text-white font-black font-mono tracking-tighter" style={{ width: "25%" }}>
                  25-30
                </div>
                <div className="bg-rose-500 h-full flex items-center justify-center text-[8px] text-white font-black font-mono tracking-tighter" style={{ width: "25%" }}>
                  30-35
                </div>
              </div>

              {/* Vertical Ruler tick marks (every 1.0 is major, every 0.1 is minor) */}
              <div className="relative w-full h-8 mt-2 select-none" id="ruler-tape-ticks">
                {Array.from({ length: 21 }).map((_, i) => {
                  const unitValue = 15 + i;
                  const positionPct = (i / 20) * 100;
                  return (
                    <div 
                      key={i} 
                      className="absolute top-0 flex flex-col items-center -translate-x-1/2" 
                      style={{ left: `${positionPct}%` }}
                    >
                      {/* Major tick lines */}
                      <div className={`w-[1.5px] ${isDark ? "bg-[#333336]" : "bg-slate-300"} h-2.5`} />
                      {/* Major tick label */}
                      {unitValue % 5 === 0 ? (
                        <span className={`text-[9px] font-mono font-bold mt-1.5 ${isDark ? "text-gray-400" : "text-slate-500"}`}>
                          {unitValue}
                        </span>
                      ) : unitValue === 18 ? (
                        <span className="text-[8px] font-mono font-bold mt-1 text-emerald-500">18.5</span>
                      ) : null}
                    </div>
                  );
                })}
              </div>
            </div>
            
            {/* Category Range explanation box */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-2">
              <div className={`p-2 rounded-xl border text-center ${isDark ? "bg-[#141416]" : "bg-slate-50"}`}>
                <span className="block text-[8px] uppercase tracking-wider font-mono text-emerald-300 font-bold">Underweight</span>
                <span className={`text-xs font-bold font-mono ${textTitle}`}>&lt; 18.5</span>
              </div>
              <div className={`p-2 rounded-xl border text-center ${isDark ? "bg-[#141416]/90" : "bg-slate-50"}`}>
                <span className="block text-[8px] uppercase tracking-wider font-mono text-emerald-500 font-bold">Healthy</span>
                <span className={`text-xs font-bold font-mono ${textTitle}`}>18.5 - 25</span>
              </div>
              <div className={`p-2 rounded-xl border text-center ${isDark ? "bg-[#141416]/90" : "bg-slate-50"}`}>
                <span className="block text-[8px] uppercase tracking-wider font-mono text-teal-400 font-bold">Overweight</span>
                <span className={`text-xs font-bold font-mono ${textTitle}`}>25 - 30</span>
              </div>
              <div className={`p-2 rounded-xl border text-center ${isDark ? "bg-[#141416]/90" : "bg-slate-50"}`}>
                <span className="block text-[8px] uppercase tracking-wider font-mono text-emerald-800 font-bold">Obese Range</span>
                <span className={`text-xs font-bold font-mono ${textTitle}`}>&gt; 30</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // countdown: AGE & BIRTHDAY COUNTDOWN CHART
  if (chartType === "countdown") {
    const daysLived = data[0]?.value || 0;
    const pctYear = data[0]?.secondaryValue || 0; // Year Progress %
    const daysToBday = data[1]?.value || 0;
    const currentAge = data[1]?.secondaryValue || 0;
    const daysToDecade = data[2]?.value || 0;
    const nextDecade = data[2]?.secondaryValue || 0;
    const hoursSlept = data[3]?.value || 0;
    const mealsConsumed = data[3]?.secondaryValue || 0;

    // Outer circle bounds
    const size = 180;
    const cx = size / 2;
    const cy = size / 2;
    const r = 62;
    const strokeWidth = 14;
    const circumference = 2 * Math.PI * r;
    // Stroke offset represents percentage countdown left to the birthday (100 - pctYear)
    const strokeOffset = circumference - (pctYear / 100) * circumference;

    const displayYearProgress = pctYear;

    return (
      <div className="w-full">
        {renderControls()}
        <div className={`w-full border rounded-3xl p-6 select-none flex flex-col md:flex-row items-center justify-between gap-8 ${
          isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-sm"
        }`} ref={containerRef}>
          
          {/* Left Column: Radial Birthday Countdown progress meter */}
          <div className="flex-shrink-0 flex flex-col items-center justify-center relative bg-gradient-to-b from-neutral-500/5 to-transparent p-4 rounded-3xl border border-neutral-500/10" style={{ width: size + 40 }}>
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold text-gray-500 mb-2 truncate">
              Year Progress Ring
            </span>

            <div className="relative" style={{ width: size, height: size }}>
              <svg width={size} height={size} className="transform -rotate-90">
                {/* Background track circle */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={r}
                  fill="none"
                  stroke={isDark ? "#1C1C1F" : "#F1F5F9"}
                  strokeWidth={strokeWidth}
                />
                
                {/* Animated active gradient track */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={r}
                  fill="none"
                  stroke={daysToBday <= 30 ? "#00FF87" : "#059669"} // Vibrant green when close, medium green normally
                  strokeWidth={strokeWidth}
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeOffset}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-in-out"
                />
              </svg>

              {/* Inside details */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
                <span className="text-2xl font-black font-mono tracking-tighter text-emerald-500">
                  {daysToBday}
                </span>
                <span className="text-[10px] uppercase font-bold font-mono tracking-wide text-neutral-400">
                  Days Left
                </span>
                <div className={`mt-0.5 text-[8px] font-mono font-medium px-2 py-0.5 rounded-full ${
                  daysToBday <= 30 ? "bg-emerald-500/20 text-emerald-400 animate-pulse" : "bg-emerald-500/15 text-emerald-500"
                }`}>
                  To Age {currentAge + 1}
                </div>
              </div>
            </div>

            <div className="mt-3 text-center">
              <span className={`text-[11px] font-mono font-bold ${textTitle}`}>
                Year {currentAge} is {displayYearProgress}% Complete
              </span>
            </div>
          </div>

          {/* Right Column: Custom stats panel */}
          <div className="flex-grow w-full flex flex-col gap-3">
            <span className="text-[10px] uppercase tracking-widest font-mono font-bold text-neutral-500">
              Personal Age Milestones & Projections
            </span>

            {/* Grid of details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className={`p-3 rounded-2xl border ${isDark ? "bg-[#131316] border-neutral-850" : "bg-slate-50 border-slate-100"}`}>
                <span className="block text-[8px] uppercase font-semibold font-mono text-gray-400">
                  Days Traveled in Life
                </span>
                <span className={`text-lg font-black font-mono tracking-tight leading-none mt-1 block ${textTitle}`}>
                  {daysLived.toLocaleString()}
                </span>
                <span className="text-[9px] text-gray-500 font-medium block mt-0.5 leading-tight">
                  Days accumulated on Planet Earth
                </span>
              </div>

              <div className={`p-3 rounded-2xl border ${isDark ? "bg-[#131316] border-neutral-850" : "bg-slate-50 border-slate-100"}`}>
                <span className="block text-[8px] uppercase font-semibold font-mono text-gray-400">
                  Major Decade Milestone
                </span>
                <span className="text-lg font-black font-mono tracking-tight leading-none mt-1 block text-emerald-500">
                  {daysToDecade.toLocaleString()} <span className="text-[10px] font-black uppercase text-emerald-400">Days</span>
                </span>
                <span className="text-[9px] text-gray-500 font-medium block mt-0.5 leading-tight">
                  Left until entering your {nextDecade}s
                </span>
              </div>

              <div className={`p-3 rounded-2xl border ${isDark ? "bg-[#131316] border-neutral-850" : "bg-slate-50 border-slate-100"}`}>
                <span className="block text-[8px] uppercase font-semibold font-mono text-gray-400">
                  Estimated Slumber Sleep Portion
                </span>
                <span className={`text-base font-bold font-mono tracking-tight leading-none mt-1 block ${textTitle}`}>
                  {hoursSlept.toLocaleString()} Hrs
                </span>
                <span className="text-[9px] text-gray-500 font-mono block mt-0.5 leading-none">
                  Spent replenishing cells (approx)
                </span>
              </div>

              <div className={`p-3 rounded-2xl border ${isDark ? "bg-[#131316] border-neutral-850" : "bg-slate-50 border-slate-100"}`}>
                <span className="block text-[8px] uppercase font-semibold font-mono text-gray-400">
                  Nutrition Meals Consumed
                </span>
                <span className={`text-base font-bold font-mono tracking-tight leading-none mt-1 block ${textTitle}`}>
                  {mealsConsumed.toLocaleString()} Meals
                </span>
                <span className="text-[9px] text-gray-500 font-mono block mt-0.5 leading-none">
                  Eaten since your birthday origin
                </span>
              </div>
            </div>

            {/* Motivational personalized memo box */}
            <div className={`p-3 rounded-xl border text-xs font-medium ${
              daysToBday <= 30
                ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-450"
                : "bg-emerald-500/10 border-emerald-500/20 text-emerald-500"
            }`}>
              {daysToBday <= 30 ? (
                <span>
                  <strong>Your birthday is just around the corner!</strong> Only <strong>{daysToBday} days</strong> left to welcome your new year milestone. Feel the positive vibe and celebrate details!
                </span>
              ) : daysToBday <= 120 ? (
                <span>
                  You are stepping into your next life year in about <strong>{Math.round(daysToBday / 30)} months</strong>! Aging is another word for acquiring wisdom. Live every single block to the fullest!
                </span>
              ) : (
                <span>
                  Age is just a relative index! Celebrate your lived journey, and enjoy every single day. Remember, an average life consists of roughly 28,000 blocks. Make today count!
                </span>
              )}
            </div>
          </div>

        </div>
      </div>
    );
  }

  // 2. DISTRIBUTION SPLIT BLOCK (e.g. Budgets & Macros)
  if (chartType === "distribution") {
    const actualSum = data.reduce((acc, d) => acc + d.value, 0);
    const isAllZero = actualSum === 0;
    const totalSum = isAllZero ? 1 : actualSum;
    
    // Aesthetic flat green colors matching the gradients perfectly
    const colorsList = ["#10B981", "#34D399", "#00FF87", "#A7F3D0", "#86EFAC", "#059669"];
    const gradientsList = [
      "url(#barLime)",
      "url(#barBlue)",
      "url(#barYellow)",
      "url(#barPurple)",
      "url(#barRose)",
      "url(#barEmerald)"
    ];
    
    const size = 280;
    const cx = size / 2;
    const cy = size / 2;
    const rOut = 88;
    const rIn = 62;

    const activeSlice = hoveredSlice !== null ? hoveredSlice : -1;

    // Helper function to produce premium flat donut segments
    const getAnnularSectorPath = (
      xCenter: number,
      yCenter: number,
      innerRadius: number,
      outerRadius: number,
      startDegrees: number,
      endDegrees: number
    ) => {
      const sweep = endDegrees - startDegrees;
      let actualEndDegrees = endDegrees;
      if (sweep >= 359.99) {
        actualEndDegrees = startDegrees + 359.99;
      }

      const startRad = ((startDegrees - 90) * Math.PI) / 180;
      const endRad = ((actualEndDegrees - 90) * Math.PI) / 180;

      const x1_out = xCenter + outerRadius * Math.cos(startRad);
      const y1_out = yCenter + outerRadius * Math.sin(startRad);
      const x2_out = xCenter + outerRadius * Math.cos(endRad);
      const y2_out = yCenter + outerRadius * Math.sin(endRad);

      const x1_in = xCenter + innerRadius * Math.cos(startRad);
      const y1_in = yCenter + innerRadius * Math.sin(startRad);
      const x2_in = xCenter + innerRadius * Math.cos(endRad);
      const y2_in = yCenter + innerRadius * Math.sin(endRad);

      const largeArc = sweep > 180 ? 1 : 0;

      return `
        M ${x1_out} ${y1_out}
        A ${outerRadius} ${outerRadius} 0 ${largeArc} 1 ${x2_out} ${y2_out}
        L ${x2_in} ${y2_in}
        A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${x1_in} ${y1_in}
        Z
      `.trim();
    };

    let accumulatedAngle = 0;

    // Center circular summary details
    const activeItem = activeSlice !== -1 ? data[activeSlice] : null;
    const centerTitleText = activeItem ? activeItem.label : "Target Value";
    const centerValueText = activeItem 
      ? formatValue(activeItem.value, outputPrefix, outputSuffix)
      : formatValue(actualSum, outputPrefix, outputSuffix);
    const centerPctText = activeItem
      ? `%${isAllZero ? "0" : ((activeItem.value / totalSum) * 100).toFixed(0)}`
      : "%100";

    return (
      <div className="w-full">
        {renderControls()}
        <div className={`w-full border rounded-3xl p-6 select-none flex flex-col md:flex-row items-center justify-center gap-8 md:gap-12 ${
          isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-xs"
        }`} ref={containerRef}>
          
          {/* Left: Interactive Donut Stage with Centered Dynamic Info */}
          <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
            <svg width={size} height={size} className="overflow-visible filter drop-shadow-md">
              <defs>
                <linearGradient id="barLime" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" stopOpacity="1" />
                  <stop offset="100%" stopColor="#047857" stopOpacity="1" />
                </linearGradient>
                <linearGradient id="barBlue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34d399" stopOpacity="1" />
                  <stop offset="100%" stopColor="#059669" stopOpacity="1" />
                </linearGradient>
                <linearGradient id="barYellow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00ff87" stopOpacity="1" />
                  <stop offset="100%" stopColor="#059669" stopOpacity="1" />
                </linearGradient>
                <linearGradient id="barPurple" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a7f3d0" stopOpacity="1" />
                  <stop offset="100%" stopColor="#10b981" stopOpacity="1" />
                </linearGradient>
                <linearGradient id="barRose" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#86efac" stopOpacity="1" />
                  <stop offset="100%" stopColor="#15803d" stopOpacity="1" />
                </linearGradient>
                <linearGradient id="barEmerald" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#059669" stopOpacity="1" />
                  <stop offset="100%" stopColor="#064e3b" stopOpacity="1" />
                </linearGradient>
              </defs>
              <g>
                {isAllZero ? (
                  <path
                    d={getAnnularSectorPath(cx, cy, rIn, rOut, 0, 359.99)}
                    fill={isDark ? "#212124" : "#F1F5F9"}
                    stroke={isDark ? "#09090B" : "#ffffff"}
                    strokeWidth="2.5"
                  />
                ) : (
                  data.map((item, idx) => {
                    const percentage = (item.value / totalSum) * 100;
                    if (percentage <= 0) return null;

                    const sweepAngle = (percentage / 100) * 360;
                    const startAngle = accumulatedAngle;
                    const endAngle = accumulatedAngle + sweepAngle;
                    accumulatedAngle += sweepAngle;

                    const isHovered = activeSlice === idx;
                    const sliceColor = gradientsList[idx % gradientsList.length];

                    // Trigonometric shift offset for nice smooth zoom-out hover focus
                    const midAngleRad = (((startAngle + sweepAngle / 2) - 90) * Math.PI) / 180;
                    const shiftDist = isHovered ? 5 : 0;
                    const shiftX = shiftDist * Math.cos(midAngleRad);
                    const shiftY = shiftDist * Math.sin(midAngleRad);

                    return (
                      <path
                        key={idx}
                        d={getAnnularSectorPath(cx, cy, rIn, rOut, startAngle, endAngle)}
                        fill={sliceColor}
                        stroke={isDark ? "#09090B" : "#ffffff"}
                        strokeWidth="2.5"
                        className="transition-all duration-300 ease-out cursor-pointer"
                        style={{
                          transform: `translate(${shiftX}px, ${shiftY}px)`,
                          filter: isHovered ? "brightness(1.08) drop-shadow(0 4px 12px rgba(16,185,129,0.3))" : "none",
                        }}
                        onMouseEnter={() => setHoveredSlice(idx)}
                        onMouseLeave={() => setHoveredSlice(null)}
                      />
                    );
                  })
                )}
              </g>
            </svg>

            {/* Absolute Centered Ring Overlay for pristine text rendering */}
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none p-4" style={{ width: size, height: size }}>
              <span className={`text-2xl font-black tracking-tight leading-none ${isDark ? "text-emerald-400" : "text-slate-800"}`}>
                {centerValueText}
              </span>
              <span className={`text-[10px] font-semibold font-mono tracking-wider uppercase opacity-85 mt-1 truncate max-w-[110px] ${isDark ? "text-gray-400" : "text-slate-500"}`}>
                {centerTitleText}
              </span>
              <span className="text-xs font-black font-mono text-emerald-500 mt-1">
                {centerPctText}
              </span>
            </div>
          </div>

          {/* Right: Legend Breakdown stacked gracefully below on mobile */}
          <div className="flex-grow w-full flex flex-col gap-3 max-w-sm">
            {data.map((item, idx) => {
              const percentage = isAllZero ? 0 : (item.value / totalSum) * 100;
              const isHovered = activeSlice === idx;
              const sliceColor = colorsList[idx % colorsList.length];
              
              return (
                <div 
                  key={idx} 
                  onMouseEnter={() => setHoveredSlice(idx)}
                  onMouseLeave={() => setHoveredSlice(null)}
                  className={`p-3.5 rounded-2xl border transition-all duration-200 flex justify-between items-center cursor-pointer ${
                    isHovered
                      ? isDark 
                        ? "bg-[#141416] border-neutral-700 translate-x-1.5 shadow-[0_4px_20px_rgba(16,185,129,0.15)]" 
                        : "bg-emerald-500/5 border-emerald-500/30 translate-x-1.5 shadow-[0_4px_16px_rgba(16,185,129,0.08)]"
                      : isDark 
                        ? "bg-[#121215]/60 border-neutral-850 hover:bg-[#1C1C1F]/40" 
                        : "bg-slate-50/50 border-slate-250/20 hover:bg-slate-50"
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span 
                      className="w-3.5 h-3.5 rounded-full flex-shrink-0 border border-black/5 dark:border-white/5" 
                      style={{ backgroundColor: sliceColor }} 
                    />
                    <div className="flex flex-col min-w-0">
                      <span className={`text-xs font-black font-mono tracking-wide truncate ${isDark ? "text-gray-300" : "text-slate-700"}`}>
                        {item.label}
                      </span>
                      <span className={`text-[10px] font-mono tracking-normal leading-tight font-medium ${isDark ? "text-slate-500" : "text-slate-400"}`}>
                        {item.secondaryLabel || "Segment Portion"}: %{percentage.toFixed(0)}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-baseline gap-2.5 flex-shrink-0 text-right">
                    <span className={`text-sm font-black font-mono ${isDark ? "text-emerald-450" : "text-emerald-650"}`}>
                      {formatValue(item.value, outputPrefix, outputSuffix)}
                    </span>
                    <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded-md ${
                      isDark ? "bg-emerald-500/10 text-emerald-400" : "bg-emerald-555/15 text-emerald-650"
                    }`}>
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* Real-time Hover Explanation / Premium Analytical Insight Box, styled extremely clean */}
        {activeSlice !== -1 && (
          <div className={`mt-3 p-4 rounded-3xl border text-xs leading-relaxed animate-fade-in flex gap-3.5 items-start select-none w-full ${
            isDark ? "bg-[#10B981]/[0.03] border-[#10B981]/15 text-gray-300" : "bg-[#10B981]/5 border-emerald-500/10 text-slate-700 shadow-xs"
          }`}>
            <Info className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
            <div className="flex-grow">
              <span className="font-extrabold font-mono tracking-wider block text-[10px] text-emerald-500 uppercase mb-1">
                ANALYTICAL INSIGHT ({data[activeSlice].label})
              </span>
              <span className="opacity-95 text-[11px] leading-relaxed">
                {BUDGET_EXPLANATIONS[data[activeSlice].label.toLowerCase()] || "This segment represents the planned allocation dynamic and target funding structure within the calculated budget."}
              </span>
            </div>
          </div>
        )}
      </div>
    );
  }

  // 3. PAIRWISE COMPARISON (e.g. Rent vs Buy, Refinancing savings)
  if (chartType === "comparison") {
    const item1 = data[0];
    const item2 = data[1] || { label: "Alternate", value: 0 };
    const maxCompVal = Math.max(item1.value, item2.value, 1);
    
    return (
      <div className="w-full">
        {renderControls()}
        <div className={`w-full border rounded-3xl p-5 select-none ${isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-sm"}`} ref={containerRef}>
          <span className={`text-[11px] font-bold uppercase tracking-wider font-mono block mb-5 ${textMuted}`}>Double scenario cost matchup</span>
          
          <div className="flex flex-col gap-5">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1.5 font-mono">
                <span className={textTitle}>{item1.label}</span>
                <span className="text-emerald-500">{formatValue(item1.value, outputPrefix, outputSuffix)}</span>
              </div>
              <div className={`w-full h-4 rounded-full overflow-hidden ${isDark ? "bg-neutral-850" : "bg-slate-100"}`}>
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${(item1.value / maxCompVal) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold mb-1.5 font-mono">
                <span className={textTitle}>{item2.label}</span>
                <span className="text-teal-400">{formatValue(item2.value, outputPrefix, outputSuffix)}</span>
              </div>
              <div className={`w-full h-4 rounded-full overflow-hidden ${isDark ? "bg-[#141416]" : "bg-slate-100"}`}>
                <div 
                  className="bg-teal-500 h-full rounded-full transition-all duration-300"
                  style={{ width: `${(item2.value / maxCompVal) * 100}%` }}
                />
              </div>
            </div>
          </div>

          <div className={`mt-5 p-3.5 rounded-xl border border-dashed text-stone-500 text-[11px] flex justify-between items-center ${isDark ? "bg-[#141415] border-neutral-800" : "bg-slate-50 border-slate-200"}`}>
            <span className="font-medium">Direct Financial Delta Margin:</span>
            <span className="font-black text-xs font-mono text-emerald-500">
              {formatValue(Math.abs(item1.value - item2.value), outputPrefix, outputSuffix)}
            </span>
          </div>
        </div>
      </div>
    );
  }

  // Compute boundaries for continuous charts using the clean optimized step sizes
  const yGridTicks = Array.from({ length: numYGridLines + 1 }, (_, i) => minVal + i * stepSize);

  // SVG Paths for continuous growth area lines
  let linePath = "";
  let areaPath = "";

  if (chartType === "line") {
    const points = processedData.map((d, i) => ({ x: getX(i), y: getY(d.value) }));
    if (points.length > 0) {
      linePath = `M ${points[0].x} ${points[0].y} ` + 
        points.slice(1).map((p) => `L ${p.x} ${p.y}`).join(" ");
      areaPath = `${linePath} L ${points[points.length - 1].x} ${height - paddingBottom} L ${points[0].x} ${height - paddingBottom} Z`;
    }
  }

  const isSplitLayout = chartType === "bar" && processedData.length <= 5;
  const barColorsList = ["url(#barLime)", "url(#barBlue)", "url(#barYellow)", "url(#barPurple)", "url(#barRose)", "url(#barEmerald)"];
  const barRawColors = ["#10b981", "#34d399", "#00ff87", "#059669", "#86efac", "#15803d"];

  return (
    <div className="w-full">
      {renderControls()}
      <div className={`w-full border rounded-3xl p-5 relative select-none ${isDark ? "bg-[#09090B] border-[#1F1F22]" : "bg-white border-slate-200 shadow-sm"}`} ref={containerRef}>
        <div className="flex justify-between items-center mb-4">
          <span className={`text-[11.5px] font-bold uppercase tracking-wider font-mono ${textMuted}`}>
            {isSplitLayout ? "Proportions & Resource Allocation" : "Projections & Breakdown Timeline"}
          </span>
          <div className="flex gap-4 font-mono text-[10px]">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_6px_#10B981]" />
              <span className={textMuted}>Target Value</span>
            </div>
            {showSecondaryLine && data.some((d) => d.secondaryValue !== undefined) && (
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-neutral-500" />
                <span className={textMuted}>
                  {data.find((d) => d.secondaryLabel !== undefined)?.secondaryLabel || "Base"}
                </span>
              </div>
            )}
          </div>
        </div>

        <div className={isSplitLayout ? "flex flex-col md:flex-row items-center gap-6" : "relative"}>
          {/* Chart Graphic Area */}
          <div className={isSplitLayout ? "w-full md:w-[58%] relative" : "relative"}>
            <svg
              ref={svgRef}
              width="100%"
              height={height}
              onPointerMove={handlePointer}
              onPointerLeave={handleLeave}
              className="overflow-visible touch-none cursor-crosshair"
            >
              <defs>
                <linearGradient id="chartGradientAccent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={primaryAccent} stopOpacity="0.25" />
                  <stop offset="100%" stopColor={primaryAccent} stopOpacity="0.0" />
                </linearGradient>

                {/* High-fidelity bar gradients matching our design framework */}
                <linearGradient id="barLime" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="100%" stopColor="#047857" />
                </linearGradient>
                <linearGradient id="barBlue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#34d399" />
                  <stop offset="100%" stopColor="#059669" />
                </linearGradient>
                <linearGradient id="barYellow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#00ff87" />
                  <stop offset="100%" stopColor="#059669" />
                </linearGradient>
                <linearGradient id="barPurple" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#a7f3d0" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
                <linearGradient id="barRose" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#86efac" />
                  <stop offset="100%" stopColor="#15803d" />
                </linearGradient>
                <linearGradient id="barEmerald" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#059669" />
                  <stop offset="100%" stopColor="#064e3b" />
                </linearGradient>
                
                <filter id="cleanGlow">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur" />
                  <feMerge>
                    <feMergeNode in="coloredBlur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Grid lines & horizontal scale coordinates */}
              {yGridTicks.map((val, idx) => {
                const y = getY(val);
                return (
                  <g key={`grid-${idx}`}>
                    <line
                      x1={paddingLeft}
                      y1={y}
                      x2={width * (isSplitLayout ? 0.58 : 1) - paddingRight}
                      stroke={gridStroke}
                      strokeWidth="1"
                      strokeDasharray="3,3"
                    />
                    <text
                      x={paddingLeft - 8}
                      y={y + 4}
                      textAnchor="end"
                      fill={labelFill}
                      className="text-[10px] font-mono font-medium"
                    >
                      {formatValue(val, outputPrefix, outputSuffix)}
                    </text>
                  </g>
                );
              })}

              {/* Line Chart Draw */}
              {chartType === "line" && (
                <>
                  <path d={areaPath} fill="url(#chartGradientAccent)" />
                  <path
                    d={linePath}
                    fill="none"
                    stroke={primaryAccent}
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    filter="url(#cleanGlow)"
                  />

                  {processedData.map((_, idx) => {
                    const x = getX(idx);
                    const y = getY(processedData[idx].value);
                    const isHovered = hoverIndex === idx;
                    return (
                      <circle
                        key={`dot-${idx}`}
                        cx={x}
                        cy={y}
                        r={isHovered ? 5.5 : 2}
                        fill={isHovered ? (isDark ? "#FFFFFF" : "#1E293B") : primaryAccent}
                        stroke={primaryAccent}
                        strokeWidth={isHovered ? 2 : 0}
                        className="transition-all duration-150 animate-fade-in"
                      />
                    );
                  })}
                </>
              )}

              {/* Bar Chart Draw */}
              {chartType === "bar" && (() => {
                const numBars = processedData.length;
                const renderWidth = width * (isSplitLayout ? 0.58 : 1);
                // Adjust horizontal distribution based on split layout constraints
                const availableWidth = renderWidth - paddingLeft - paddingRight;
                const gap = availableWidth / numBars;
                const getAdjustedX = (index: number) => {
                  if (numBars <= 1) return paddingLeft + availableWidth / 2;
                  return paddingLeft + (index + 0.5) * gap;
                };

                const groupWidth = availableWidth / numBars;
                const barWidth = Math.max(Math.min(groupWidth * 0.45, 45), 14);

                return processedData.map((d, idx) => {
                  const cx = getAdjustedX(idx);
                  const yVal = getY(d.value);
                  const barHeight = Math.max(height - paddingBottom - yVal, 4);
                  const xPos = cx - barWidth / 2;

                  const isHovered = hoverIndex === idx;

                  const hasSec = d.secondaryValue !== undefined;
                  const secVal = d.secondaryValue || 0;
                  const ySec = getY(secVal);
                  const secHeight = Math.max(height - paddingBottom - ySec, 0);

                  if (hasSec) {
                    const subBarWidth = barWidth / 2 - 1.5;
                    const xPos1 = cx - subBarWidth - 0.75;
                    const xPos2 = cx + 0.75;

                    return (
                      <g 
                        key={`bar-group-${idx}`} 
                        className="cursor-pointer"
                        onMouseEnter={() => {
                          setHoverIndex(idx);
                          setTooltipPos({ x: getAdjustedX(idx), y: getY(d.value) });
                        }}
                        onMouseLeave={() => setHoverIndex(null)}
                      >
                        <rect
                          x={xPos1}
                          y={ySec}
                          width={subBarWidth}
                          height={secHeight}
                          rx="3"
                          fill={isDark ? "#2A2A2E" : "#D1D5DB"}
                          className="transition-all duration-300"
                          opacity={hoverIndex === null || isHovered ? 0.9 : 0.5}
                        />
                        <rect
                          x={xPos2}
                          y={yVal}
                          width={subBarWidth}
                          height={barHeight}
                          rx="3"
                          fill={isHovered ? barColorsList[idx % barColorsList.length] : (isDark ? "url(#chartGradientAccent)" : "#10B981")}
                          stroke={isHovered ? (isDark ? "#ffffff" : "#1e293b") : "transparent"}
                          strokeWidth={isHovered ? "1.5" : "0"}
                          opacity={hoverIndex === null || isHovered ? 1 : 0.65}
                          className="transition-all duration-300"
                          filter={isHovered ? "url(#cleanGlow)" : "none"}
                        />
                      </g>
                    );
                  }

                  return (
                    <rect
                      key={`bar-${idx}`}
                      x={xPos}
                      y={yVal}
                      width={barWidth}
                      height={barHeight}
                      rx="6"
                      fill={barColorsList[idx % barColorsList.length]}
                      stroke={isHovered ? (isDark ? "#ffffff" : "#1E293B") : "transparent"}
                      strokeWidth={isHovered ? "1.5" : "0"}
                      opacity={hoverIndex === null || isHovered ? 1 : 0.6}
                      className="transition-all duration-300 cursor-pointer"
                      filter={isHovered ? "url(#cleanGlow)" : "none"}
                      onMouseEnter={() => {
                        setHoverIndex(idx);
                        setTooltipPos({ x: getAdjustedX(idx), y: getY(d.value) });
                      }}
                      onMouseLeave={() => setHoverIndex(null)}
                    />
                  );
                });
              })()}

              {/* Interactive Mouse Guide line */}
              {hoverIndex !== null && (
                <line
                  x1={tooltipPos.x}
                  y1={paddingTop}
                  x2={tooltipPos.x}
                  y2={height - paddingBottom}
                  stroke={isDark ? "rgba(255, 255, 255, 0.45)" : "#CBD5E1"}
                  strokeWidth="1.5"
                  strokeDasharray="4,4"
                  className="pointer-events-none"
                />
              )}

              {/* X-Axis scale labels */}
              {processedData.map((d, idx) => {
                const isMobile = width < 480;
                const totalBars = processedData.length;
                
                // Adaptive label skipping filters for mobile devices to prevent crowding
                let isLabelHidden = totalBars > 10 && idx % 2 !== 0 && idx !== totalBars - 1;
                if (isMobile) {
                  if (totalBars > 4) {
                    isLabelHidden = idx % 2 !== 0 && idx !== totalBars - 1;
                  }
                  if (totalBars > 7) {
                    isLabelHidden = idx % 3 !== 0 && idx !== totalBars - 1;
                  }
                }
                if (isLabelHidden) return null;

                const renderWidth = width * (isSplitLayout ? 0.58 : 1);
                const availableWidth = renderWidth - paddingLeft - paddingRight;
                const gap = availableWidth / totalBars;
                const getAdjustedX = (index: number) => {
                  if (totalBars <= 1) return paddingLeft + availableWidth / 2;
                  return paddingLeft + (index + 0.5) * gap;
                };

                const xCoord = getAdjustedX(idx);
                const yCoord = isMobile ? height - 12 : height - 15;
                
                // Truncate labels on narrow viewports if they exceed safety bounds
                let displayLabel = d.label;
                if (isMobile && d.label.length > 8) {
                  displayLabel = d.label.substring(0, 6) + "..";
                }

                return (
                  <text
                    key={`label-${idx}`}
                    x={xCoord}
                    y={yCoord}
                    textAnchor={isMobile ? "end" : "middle"}
                    transform={isMobile ? `rotate(-24, ${xCoord}, ${yCoord})` : undefined}
                    textRendering="geometricPrecision"
                    fill={labelFill}
                    className="text-[9px] font-mono font-medium transition-all"
                  >
                    {displayLabel}
                  </text>
                );
              })}
            </svg>

            {/* Hover overlay tooltip */}
            {activeNode && (
              <div
                className={`absolute z-30 pointer-events-none border shadow-xl rounded-xl p-3 text-xs flex flex-col gap-1 ${
                  isDark ? "bg-[#18181B] border-[#2C2C30] text-gray-200" : "bg-white border-slate-200 text-slate-800"
                }`}
                style={{
                  left: `${Math.max(10, Math.min(width * (isSplitLayout ? 0.58 : 1) - 150, tooltipPos.x - 70))}px`,
                  top: `${Math.max(5, tooltipPos.y - 82)}px`,
                }}
              >
                <div className="font-bold">{activeNode.label}</div>
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: barRawColors[hoverIndex !== null ? hoverIndex % barRawColors.length : 0] }} />
                  <span>
                    Amount: <span className="font-bold underline">{formatValue(activeNode.value, outputPrefix, outputSuffix)}</span>
                  </span>
                </div>
                {activeNode.secondaryValue !== undefined && (
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-neutral-500" />
                    <span className="opacity-80">
                      {activeNode.secondaryLabel || "Base"}:{" "}
                      <span className="font-bold font-mono">
                        {formatValue(activeNode.secondaryValue, activeNode.secondaryLabel?.toLowerCase().includes("percent") || activeNode.secondaryLabel?.includes("%") ? "" : outputPrefix, activeNode.secondaryLabel?.toLowerCase().includes("percent") || activeNode.secondaryLabel?.includes("%") ? "%" : outputSuffix)}
                      </span>
                    </span>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Right Column: Breakdown cards list with custom hover actions (for split layouts) */}
          {isSplitLayout && (() => {
            const totalSum = processedData.reduce((acc, d) => acc + d.value, 0) || 1;
            return (
              <div className="w-full md:w-[42%] flex flex-col gap-2.5 mt-2 md:mt-0">
                {processedData.map((item, idx) => {
                  const percentage = (item.value / totalSum) * 100;
                  const isHovered = hoverIndex === idx;
                  const rawColor = barRawColors[idx % barRawColors.length];
                  
                  // Compute horizontal position for the tooltip relative to this item
                  const renderWidth = width * 0.58;
                  const availableWidth = renderWidth - paddingLeft - paddingRight;
                  const gap = availableWidth / processedData.length;
                  const getAdjustedX = (index: number) => {
                    if (processedData.length <= 1) return paddingLeft + availableWidth / 2;
                    return paddingLeft + (index + 0.5) * gap;
                  };

                  return (
                    <div 
                      key={idx} 
                      onMouseEnter={() => {
                        setHoverIndex(idx);
                        setTooltipPos({ x: getAdjustedX(idx), y: getY(item.value) });
                      }}
                      onMouseLeave={() => setHoverIndex(null)}
                      className={`p-3.5 rounded-2xl border transition-all duration-250 flex justify-between items-center cursor-pointer ${
                        isHovered
                          ? isDark 
                            ? "bg-[#1C1C1F] border-neutral-700 translate-x-1" 
                            : "bg-slate-50 border-slate-350 translate-x-1 shadow-xs"
                          : isDark 
                            ? "bg-[#121215]/60 border-neutral-850" 
                            : "bg-slate-50/50 border-slate-250/20"
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className="w-2.5 h-2.5 rounded-full flex-shrink-0 animate-pulse" style={{ backgroundColor: rawColor }} />
                        <span className={`text-xs font-semibold font-mono tracking-wide truncate ${isDark ? "text-gray-300" : "text-slate-700"}`}>
                          {item.label}
                        </span>
                      </div>
                      <div className="flex items-baseline gap-3">
                        <span className={`text-xs font-black font-mono ${textTitle}`}>
                          {formatValue(item.value, outputPrefix, outputSuffix)}
                        </span>
                        <span className="text-[10px] font-black font-mono" style={{ color: rawColor }}>
                          {percentage.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>

        {/* Main chart download container removed */}
      </div>
    </div>
  );
}
